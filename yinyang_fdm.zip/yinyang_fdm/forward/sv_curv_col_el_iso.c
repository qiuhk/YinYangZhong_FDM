/*******************************************************************************
 * solver of isotropic elastic 1st-order eqn using curv grid and collocated scheme
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mpi.h>

#include "fdlib_mem.h"
#include "fdlib_math.h"
#include "sv_curv_col_el_iso.h"

//#define SV_CURV_COLGRD_ISO_DEBUG

/*******************************************************************************
 * perform one stage calculation of rhs
 ******************************************************************************/

void
sv_curv_col_el_iso_onestage(
  float *restrict w_cur,
  float *restrict rhs, 
  float *restrict w_cur_n,
  float *restrict rhs_n, 
  float *restrict w_cur_car,
  float *restrict rhs_car, 
  wav_t  *wav,
  wav_t  *wav_n,
  wav_t  *wav_car,
  gd_t      *gd,
  gd_t      *gd_n,
  gd_t      *gd_car,
  gdinfo_t *gdinfo, 
  gdinfo_t *gdinfo_n,
  gdinfo_t *gdinfo_car, 
  gdcurv_metric_t  *metric,
  gdcurv_metric_t *metric_n,
  md_t      *md,
  md_t      *md_n,
  md_t      *md_car,
  bdryfree_t *bdryfree,
  bdryfree_t *bdryfree_n,
  bdrypml_t  *bdrypml,
  src_t *src,
  // include different order/stentil
  int num_of_fdx_op, fd_op_t *fdx_op,
  int num_of_fdy_op, fd_op_t *fdy_op,
  int num_of_fdz_op, fd_op_t *fdz_op,
  int fdz_max_len, 
  const int myid, const int verbose)
{
  // local pointer get each vars
  float *restrict Vx    = w_cur + wav->Vx_pos ;
  float *restrict Vy    = w_cur + wav->Vy_pos ;
  float *restrict Vz    = w_cur + wav->Vz_pos ;
  float *restrict Txx   = w_cur + wav->Txx_pos;
  float *restrict Tyy   = w_cur + wav->Tyy_pos;
  float *restrict Tzz   = w_cur + wav->Tzz_pos;
  float *restrict Txz   = w_cur + wav->Txz_pos;
  float *restrict Tyz   = w_cur + wav->Tyz_pos;
  float *restrict Txy   = w_cur + wav->Txy_pos;
  float *restrict hVx   = rhs   + wav->Vx_pos ; 
  float *restrict hVy   = rhs   + wav->Vy_pos ; 
  float *restrict hVz   = rhs   + wav->Vz_pos ; 
  float *restrict hTxx  = rhs   + wav->Txx_pos; 
  float *restrict hTyy  = rhs   + wav->Tyy_pos; 
  float *restrict hTzz  = rhs   + wav->Tzz_pos; 
  float *restrict hTxz  = rhs   + wav->Txz_pos; 
  float *restrict hTyz  = rhs   + wav->Tyz_pos; 
  float *restrict hTxy  = rhs   + wav->Txy_pos; 

  float *restrict xi_x  = metric->xi_x;
  float *restrict xi_y  = metric->xi_y;
  float *restrict xi_z  = metric->xi_z;
  float *restrict et_x  = metric->eta_x;
  float *restrict et_y  = metric->eta_y;
  float *restrict et_z  = metric->eta_z;
  float *restrict zt_x  = metric->zeta_x;
  float *restrict zt_y  = metric->zeta_y;
  float *restrict zt_z  = metric->zeta_z;
  float *restrict jac3d = metric->jac;

  float *restrict lam3d = md->lambda;
  float *restrict  mu3d = md->mu;
  float *restrict slw3d = md->rho;
 
  float *restrict x3d  = gd->x3d;
  float *restrict y3d  = gd->y3d;
  float *restrict z3d  = gd->z3d;
  float *restrict z_zt  = gd->z_zeta;

  //yang
  // local pointer get each vars
  float *restrict Vxn    = w_cur_n + wav->Vx_pos ;
  float *restrict Vyn    = w_cur_n + wav->Vy_pos ;
  float *restrict Vzn    = w_cur_n + wav->Vz_pos ;
  float *restrict Txxn   = w_cur_n + wav->Txx_pos;
  float *restrict Tyyn   = w_cur_n + wav->Tyy_pos;
  float *restrict Tzzn   = w_cur_n + wav->Tzz_pos;
  float *restrict Txzn   = w_cur_n + wav->Txz_pos;
  float *restrict Tyzn   = w_cur_n + wav->Tyz_pos;
  float *restrict Txyn   = w_cur_n + wav->Txy_pos;
  float *restrict hVxn   = rhs_n   + wav->Vx_pos ; 
  float *restrict hVyn   = rhs_n   + wav->Vy_pos ; 
  float *restrict hVzn   = rhs_n   + wav->Vz_pos ; 
  float *restrict hTxxn  = rhs_n   + wav->Txx_pos; 
  float *restrict hTyyn  = rhs_n   + wav->Tyy_pos; 
  float *restrict hTzzn  = rhs_n   + wav->Tzz_pos; 
  float *restrict hTxzn  = rhs_n   + wav->Txz_pos; 
  float *restrict hTyzn  = rhs_n   + wav->Tyz_pos; 
  float *restrict hTxyn  = rhs_n   + wav->Txy_pos; 

  float *restrict xi_xn  = metric_n->xi_x;
  float *restrict xi_yn  = metric_n->xi_y;
  float *restrict xi_zn  = metric_n->xi_z;
  float *restrict et_xn  = metric_n->eta_x;
  float *restrict et_yn  = metric_n->eta_y;
  float *restrict et_zn  = metric_n->eta_z;
  float *restrict zt_xn  = metric_n->zeta_x;
  float *restrict zt_yn  = metric_n->zeta_y;
  float *restrict zt_zn  = metric_n->zeta_z;
  float *restrict jac3dn = metric_n->jac;

  float *restrict lam3dn = md_n->lambda;
  float *restrict  mu3dn = md_n->mu;
  float *restrict slw3dn = md_n->rho;
 
  float *restrict x3dn  = gd_n->x3d;
  float *restrict y3dn  = gd_n->y3d;
  float *restrict z3dn  = gd_n->z3d;
  float *restrict z_ztn  = gd_n->z_zeta;

  //car
  float *restrict Vx_car    = w_cur_car + wav_car->Vx_pos ;
  float *restrict Vy_car    = w_cur_car + wav_car->Vy_pos ;
  float *restrict Vz_car    = w_cur_car + wav_car->Vz_pos ;
  float *restrict Txx_car   = w_cur_car + wav_car->Txx_pos;
  float *restrict Tyy_car   = w_cur_car + wav_car->Tyy_pos;
  float *restrict Tzz_car   = w_cur_car + wav_car->Tzz_pos;
  float *restrict Txz_car   = w_cur_car + wav_car->Txz_pos;
  float *restrict Tyz_car   = w_cur_car + wav_car->Tyz_pos;
  float *restrict Txy_car   = w_cur_car + wav_car->Txy_pos;
  float *restrict hVx_car   = rhs_car   + wav_car->Vx_pos ; 
  float *restrict hVy_car   = rhs_car   + wav_car->Vy_pos ; 
  float *restrict hVz_car   = rhs_car   + wav_car->Vz_pos ; 
  float *restrict hTxx_car  = rhs_car   + wav_car->Txx_pos; 
  float *restrict hTyy_car  = rhs_car   + wav_car->Tyy_pos; 
  float *restrict hTzz_car  = rhs_car   + wav_car->Tzz_pos; 
  float *restrict hTxz_car  = rhs_car   + wav_car->Txz_pos; 
  float *restrict hTyz_car  = rhs_car   + wav_car->Tyz_pos; 
  float *restrict hTxy_car  = rhs_car   + wav_car->Txy_pos; 

  float *restrict lam3d_car = md_car->lambda;
  float *restrict  mu3d_car = md_car->mu;
  float *restrict slw3d_car = md_car->rho;
 
  float *restrict xx3d  = gd_car->x3d;
  float *restrict yy3d  = gd_car->y3d;
  float *restrict zz3d  = gd_car->z3d;

  // grid size
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;

  int ni1n = gdinfo_n->ni1;
  int ni2n = gdinfo_n->ni2;
  int nj1n = gdinfo_n->nj1;
  int nj2n = gdinfo_n->nj2;
  int nk1n = gdinfo_n->nk1;
  int nk2n = gdinfo_n->nk2;

  int nii1 = gdinfo_car->ni1;
  int nii2 = gdinfo_car->ni2;
  int njj1 = gdinfo_car->nj1;
  int njj2 = gdinfo_car->nj2;
  int nkk1 = gdinfo_car->nk1;
  int nkk2 = gdinfo_car->nk2;

  int ni  = gdinfo->ni;
  int nj  = gdinfo->nj;
  int nk  = gdinfo->nk;
  int nin  = gdinfo_n->ni;
  int njn  = gdinfo_n->nj;
  int nkn  = gdinfo_n->nk;
  int nii  = gdinfo_car->ni;
  int njj  = gdinfo_car->nj;
  int nkk  = gdinfo_car->nk;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  int nxn  = gdinfo_n->nx;
  int nyn  = gdinfo_n->ny;
  int nzn  = gdinfo_n->nz;
  int nxx = gdinfo_car->nx;
  int nyy = gdinfo_car->ny;
  int nzz = gdinfo_car->nz;
  float dxyz = gdinfo_car->dxyz;

  size_t siz_line   = gdinfo->siz_line;
  size_t siz_slice  = gdinfo->siz_slice;
  size_t siz_volume = gdinfo->siz_volume;
  size_t siz_linen   = gdinfo_n->siz_line;
  size_t siz_slicen  = gdinfo_n->siz_slice;
  size_t siz_volumen = gdinfo_n->siz_volume;
  size_t siz_line_car   = gdinfo_car->siz_line;
  size_t siz_slice_car  = gdinfo_car->siz_slice;
  size_t siz_volume_car = gdinfo_car->siz_volume;

  float *matVx2Vz = bdryfree->matVx2Vz2;
  float *matVy2Vz = bdryfree->matVy2Vz2;
  float *matV2Vz = bdryfree->matV2Vz2;

  float *matVx2Vzn = bdryfree_n->matVx2Vz2;
  float *matVy2Vzn = bdryfree_n->matVy2Vz2;
  float *matV2Vzn = bdryfree_n->matV2Vz2;

  // local fd op
  int              fdx_inn_len;
  int    *restrict fdx_inn_indx;
  float  *restrict fdx_inn_coef;
  int              fdy_inn_len;
  int    *restrict fdy_inn_indx;
  float  *restrict fdy_inn_coef;
  int              fdz_inn_len;
  int    *restrict fdz_inn_indx;
  float  *restrict fdz_inn_coef;

  // for get a op from 1d array, currently use num_of_fdz_op as index
  // length, index, coef of a op
  fdx_inn_len  = fdx_op[num_of_fdx_op-1].total_len;
  fdx_inn_indx = fdx_op[num_of_fdx_op-1].indx;
  fdx_inn_coef = fdx_op[num_of_fdx_op-1].coef;

  fdy_inn_len  = fdy_op[num_of_fdy_op-1].total_len;
  fdy_inn_indx = fdy_op[num_of_fdy_op-1].indx;
  fdy_inn_coef = fdy_op[num_of_fdy_op-1].coef;

  fdz_inn_len  = fdz_op[num_of_fdz_op-1].total_len;
  fdz_inn_indx = fdz_op[num_of_fdz_op-1].indx;
  fdz_inn_coef = fdz_op[num_of_fdz_op-1].coef;

  // inner points
  sv_curv_col_el_iso_rhs_inner(Vx,Vy,Vz,Txx,Tyy,Tzz,Txz,Tyz,Txy,
                                hVx,hVy,hVz,hTxx,hTyy,hTzz,hTxz,hTyz,hTxy,
                                xi_x, xi_y, xi_z, et_x, et_y, et_z, zt_x, zt_y, zt_z,
                                lam3d, mu3d, slw3d, y3d, z3d,
                                ni1,ni2,nj1,nj2,nk1,nk2,siz_line,siz_slice,
                                fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                fdz_inn_len, fdz_inn_indx, fdz_inn_coef,
                                myid, verbose);
  sv_curv_col_el_iso_rhs_inner(Vxn,Vyn,Vzn,Txxn,Tyyn,Tzzn,Txzn,Tyzn,Txyn,
                                hVxn,hVyn,hVzn,hTxxn,hTyyn,hTzzn,hTxzn,hTyzn,hTxyn,
                                xi_xn, xi_yn, xi_zn, et_xn, et_yn, et_zn, zt_xn, zt_yn, zt_zn,
                                lam3dn, mu3dn, slw3dn, y3d, z3dn,
                                ni1n,ni2n,nj1n,nj2n,nk1n,nk2n,siz_linen,siz_slicen,
                                fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                fdz_inn_len, fdz_inn_indx, fdz_inn_coef,
                                myid, verbose);
  sv_curv_col_el_iso_rhs_inner_car(Vx_car,Vy_car,Vz_car,Txx_car,Tyy_car,Tzz_car,Txz_car,Tyz_car,Txy_car,
                                    hVx_car,hVy_car,hVz_car,hTxx_car,hTyy_car,hTzz_car,hTxz_car,hTyz_car,hTxy_car,
                                    lam3d_car, mu3d_car, slw3d_car,
                                    nii1,nii2,njj1,njj2,nkk1,nkk2,dxyz,siz_line_car,siz_slice_car,
                                    fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                    fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                    fdz_inn_len, fdz_inn_indx, fdz_inn_coef,
                                    myid, verbose);

  // free, abs, source in turn

  // free surface at z2
  
  if (bdryfree->is_at_sides[2][1] == 1)
  {
   
    // tractiong
    sv_curv_col_el_iso_rhs_timg_z2(Txx,Tyy,Tzz,Txz,Tyz,Txy,hVx,hVy,hVz,
                                        xi_x, xi_y, xi_z, et_x, et_y, et_z, zt_x, zt_y, zt_z,
                                        jac3d, slw3d, y3d, z3d, z_zt,
                                        ni1,ni2,nj1,nj2,nk1,nk2,siz_line,siz_slice,
                                        fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                        fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                        fdz_inn_len, fdz_inn_indx, fdz_inn_coef,
                                        fdz_op,fdz_max_len,myid, verbose);
   sv_curv_col_el_iso_rhs_timg_z2(Txxn,Tyyn,Tzzn,Txzn,Tyzn,Txyn,hVxn,hVyn,hVzn,
                                        xi_xn, xi_yn, xi_zn, et_xn, et_yn, et_zn, zt_xn, zt_yn, zt_zn,
                                        jac3dn, slw3dn, y3d, z3dn, z_ztn,
                                        ni1n,ni2n,nj1n,nj2n,nk1n,nk2n,siz_linen,siz_slicen,
                                        fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                        fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                        fdz_inn_len, fdz_inn_indx, fdz_inn_coef,
                                        fdz_op,fdz_max_len,myid, verbose);                                     

    // velocity: vlow
    sv_curv_col_el_iso_rhs_vlow_z2(Vx,Vy,Vz,hTxx,hTyy,hTzz,hTxz,hTyz,hTxy,
                                        xi_x, xi_y, xi_z, et_x, et_y, et_z, zt_x, zt_y, zt_z,
                                        lam3d, mu3d, slw3d, y3d, z3d,
                                        matVx2Vz,matVy2Vz,matV2Vz,
                                        ni1,ni2,nj1,nj2,nk1,nk2,siz_line,siz_slice,
                                        fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                        fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                        num_of_fdz_op,fdz_op,fdz_max_len,
                                        myid, verbose);   
    sv_curv_col_el_iso_rhs_vlow_z2(Vxn,Vyn,Vzn,hTxxn,hTyyn,hTzzn,hTxzn,hTyzn,hTxyn,
                                        xi_xn, xi_yn, xi_zn, et_xn, et_yn, et_zn, zt_xn, zt_yn, zt_zn,
                                        lam3dn, mu3dn, slw3dn, y3d, z3dn,
                                        matVx2Vzn,matVy2Vzn,matV2Vzn,
                                        ni1n,ni2n,nj1n,nj2n,nk1n,nk2n,siz_linen,siz_slicen,
                                        fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                        fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                        num_of_fdz_op,fdz_op,fdz_max_len,
                                        myid, verbose);                                       
  }

  // cfs-pml, loop face inside

  if (bdrypml->is_enable == 1)
  {
    sv_curv_col_el_iso_rhs_cfspml(Vx,Vy,Vz,Txx,Tyy,Tzz,Txz,Tyz,Txy,
                                       hVx,hVy,hVz,hTxx,hTyy,hTzz,hTxz,hTyz,hTxy,
                                       xi_x, xi_y, xi_z, et_x, et_y, et_z, zt_x, zt_y, zt_z,
                                       lam3d, mu3d, slw3d,
                                       nk2, siz_line,siz_slice,
                                       fdx_inn_len, fdx_inn_indx, fdx_inn_coef,
                                       fdy_inn_len, fdy_inn_indx, fdy_inn_coef,
                                       fdz_inn_len, fdz_inn_indx, fdz_inn_coef,
                                       bdrypml, bdryfree,
                                       myid, verbose);
    
  }

  // add source term
  if (src->total_number > 0)
  {
    if (src->source_region == 0){
         sv_curv_col_el_iso_rhs_src(hVx,hVy,hVz,hTxx,hTyy,hTzz,hTxz,hTyz,hTxy,
                                    jac3d, slw3d, z3d, dxyz,
                                    src,
                                    myid, verbose);  
    }
    if (src->source_region == 1){
         sv_curv_col_el_iso_rhs_src(hVxn,hVyn,hVzn,hTxxn,hTyyn,hTzzn,hTxzn,hTyzn,hTxyn,
                                    jac3dn, slw3dn, z3dn, dxyz,
                                    src,
                                    myid, verbose);  
    }
    if (src->source_region == 2){
         sv_curv_col_el_iso_rhs_src_car(hVx_car,hVy_car,hVz_car,hTxx_car,hTyy_car,hTzz_car,hTxz_car,hTyz_car,hTxy_car,
                                    slw3d_car, dxyz,
                                    src,
                                    myid, verbose);  
    }
  }
  // end func 
}

/*******************************************************************************
 * calculate all points without boundaries treatment
 ******************************************************************************/

void
sv_curv_col_el_iso_rhs_inner(
    float *restrict  Vx , float *restrict  Vy , float *restrict  Vz ,
    float *restrict  Txx, float *restrict  Tyy, float *restrict  Tzz,
    float *restrict  Txz, float *restrict  Tyz, float *restrict  Txy,
    float *restrict hVx , float *restrict hVy , float *restrict hVz ,
    float *restrict hTxx, float *restrict hTyy, float *restrict hTzz,
    float *restrict hTxz, float *restrict hTyz, float *restrict hTxy,
    float *restrict xi_x, float *restrict xi_y, float *restrict xi_z,
    float *restrict et_x, float *restrict et_y, float *restrict et_z,
    float *restrict zt_x, float *restrict zt_y, float *restrict zt_z,
    float *restrict lam3d, float *restrict mu3d, float *restrict slw3d,
    float *restrict y3d, float *restrict z3d,
    int ni1, int ni2, int nj1, int nj2, int nk1, int nk2,
    size_t siz_line, size_t siz_slice,
    int fdx_len, int *restrict fdx_indx, float *restrict fdx_coef,
    int fdy_len, int *restrict fdy_indx, float *restrict fdy_coef,
    int fdz_len, int *restrict fdz_indx, float *restrict fdz_coef,
    const int myid, const int verbose)
{
  // use local stack array for speedup
  float  lfdx_coef [fdx_len];
  int    lfdx_shift[fdx_len];
  float  lfdy_coef [fdy_len];
  int    lfdy_shift[fdy_len];
  float  lfdz_coef [fdz_len];
  int    lfdz_shift[fdz_len];

  // loop var for fd
  int n_fd; // loop var for fd

  // local var
  float DxTxx,DxTyy,DxTzz,DxTxy,DxTxz,DxTyz,DxVx,DxVy,DxVz;
  float DyTxx,DyTyy,DyTzz,DyTxy,DyTxz,DyTyz,DyVx,DyVy,DyVz;
  float DzTxx,DzTyy,DzTzz,DzTxy,DzTxz,DzTyz,DzVx,DzVy,DzVz;
  float lam,mu,lam2mu,slw;
  float xix,xiy,xiz,etx,ety,etz,ztx,zty,ztz;
  float c,r;

  float *restrict Vx_ptr;
  float *restrict Vy_ptr;
  float *restrict Vz_ptr;
  float *restrict Txx_ptr;
  float *restrict Txy_ptr;
  float *restrict Txz_ptr;
  float *restrict Tyy_ptr;
  float *restrict Tzz_ptr;
  float *restrict Tyz_ptr;

  // put fd op into local array
  for (int i=0; i < fdx_len; i++) {
    lfdx_coef [i] = fdx_coef[i];
    lfdx_shift[i] = fdx_indx[i];
  }
  for (int j=0; j < fdy_len; j++) {
    lfdy_coef [j] = fdy_coef[j];
    lfdy_shift[j] = fdy_indx[j] * siz_line;
  }
  for (int k=0; k < fdz_len; k++) {
    lfdz_coef [k] = fdz_coef[k];
    lfdz_shift[k] = fdz_indx[k] * siz_slice;
  }


  // loop all points of sphere
  for (size_t k=nk1; k<=nk2; k++)
  {
    size_t iptr_k = k * siz_slice;

    for (size_t j=nj1; j<=nj2; j++)
    {
      size_t iptr_j = iptr_k + j * siz_line;

      size_t iptr = iptr_j + ni1;

      for (size_t i=ni1; i<=ni2; i++)
      {

        Vx_ptr = Vx + iptr;
        Vy_ptr = Vy + iptr;
        Vz_ptr = Vz + iptr;
        Txx_ptr = Txx + iptr;
        Tyy_ptr = Tyy + iptr;
        Tzz_ptr = Tzz + iptr;
        Txz_ptr = Txz + iptr;
        Tyz_ptr = Tyz + iptr;
        Txy_ptr = Txy + iptr;
        c = y3d[iptr];
        r = z3d[iptr];


        // Vx derivatives
        M_FD_SHIFT_PTR_MACDRP(DxVx, Vx_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyVx, Vx_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzVx, Vx_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Vy derivatives
        M_FD_SHIFT_PTR_MACDRP(DxVy, Vy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyVy, Vy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzVy, Vy_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Vz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxVz, Vz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyVz, Vz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzVz, Vz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Txx derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTxx, Txx_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTxx, Txx_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTxx, Txx_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Tyy derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTyy, Tyy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTyy, Tyy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTyy, Tyy_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Tzz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTzz, Tzz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTzz, Tzz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTzz, Tzz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Txz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTxz, Txz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTxz, Txz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTxz, Txz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Tyz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTyz, Tyz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTyz, Tyz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTyz, Tyz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Txy derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTxy, Txy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTxy, Txy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTxy, Txy_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // metric
        xix = xi_x[iptr];
        xiy = xi_y[iptr];
        xiz = xi_z[iptr];
        etx = et_x[iptr];
        ety = et_y[iptr];
        etz = et_z[iptr];
        ztx = zt_x[iptr];
        zty = zt_y[iptr];
        ztz = zt_z[iptr];

        // medium
        lam = lam3d[iptr];
        mu  =  mu3d[iptr];
        slw = slw3d[iptr];
        lam2mu = lam + 2.0 * mu;

        // moment equation
        hVx[iptr] = slw*( (xiy*DxTxy + ety*DyTxy + zty*DzTxy )/r 
                        + (xix*DxTxx + etx*DyTxx + ztx*DzTxx )/r*recip_sin(c)
                        + xiz*DxTxz + etz*DyTxz  + ztz*DzTxz
                        + (3**Txz_ptr + 2**Txy_ptr *cos(c)*recip_sin(c) )/r);

        hVy[iptr] = slw*( (xiy*DxTyy + ety*DyTyy + zty*DzTyy)/r 
                        + (xix*DxTxy + etx*DyTxy + ztx*DzTxy)/r*recip_sin(c)
                        + xiz*DxTyz + etz*DyTyz  + ztz*DzTyz 
                        + (3**Tyz_ptr + (*Tyy_ptr - *Txx_ptr)*cos(c)*recip_sin(c) )/r );


        hVz[iptr] = slw*( (xiy*DxTyz + ety*DyTyz + zty*DzTyz )/r 
                        + (xix*DxTxz + etx*DyTxz + ztx*DzTxz)/r*recip_sin(c)
                        + xiz*DxTzz + etz*DyTzz  + ztz*DzTzz
                        + (2**Tzz_ptr + *Tyz_ptr *cos(c)*recip_sin(c) - *Txx_ptr - *Tyy_ptr )/r);

        // Hooke's equatoin
        hTxx[iptr] =  lam *    ( xiy*DxVy  +ety*DyVy + zty*DzVy + *Vz_ptr)/r
                    +lam2mu  * (( xix*DxVx + etx*DyVx + ztx*DzVx) * recip_sin(c) + *Vz_ptr 
                                + *Vy_ptr*cos(c)*recip_sin(c))/r
                    + lam    * (xiz*DxVz + etz*DyVz + ztz*DzVz);

        hTyy[iptr] =  lam2mu * ( xiy*DxVy  +ety*DyVy + zty*DzVy + *Vz_ptr)/r
                    + lam    * (( xix*DxVx + etx*DyVx + ztx*DzVx) * recip_sin(c) + *Vz_ptr 
                                + *Vy_ptr*cos(c)*recip_sin(c))/r
                    + lam    * (xiz*DxVz + etz*DyVz + ztz*DzVz);


        hTzz[iptr] =  lam *    ( xiy*DxVy  +ety*DyVy + zty*DzVy + *Vz_ptr)/r
                    + lam    * (( xix*DxVx + etx*DyVx + ztx*DzVx) * recip_sin(c) + *Vz_ptr 
                                + *Vy_ptr*cos(c)*recip_sin(c))/r
                    + lam2mu * (xiz*DxVz + etz*DyVz + ztz*DzVz);


        hTxy[iptr] = mu *( xiy*DxVx + ety*DyVx + zty*DzVx
                        + (xix*DxVy + etx*DyVy + ztx*DzVy)*recip_sin(c)
                        - *Vx_ptr*cos(c)*recip_sin(c)) /r;
        
        hTxz[iptr] = mu *( (xix*DxVz + etx*DyVz + ztx*DzVz)*recip_sin(c)/r
                          + xiz*DxVx + etz*DyVx + ztz*DzVx
                          - *Vx_ptr/r);

        hTyz[iptr] = mu *( (xiy*DxVz + ety*DyVz + zty*DzVz)/r
                          + xiz*DxVy + etz*DyVy + ztz*DzVy
                          - *Vy_ptr/r);
 /*       if (hVx[iptr] + hVy[iptr] + hVz[iptr] != 0.0)
        {
          fprintf(stdout,"i,j,k=%d,%d,%d's hv_value equals %f,%f,%f\n",
                      i,j,k, hVx[iptr], hVy[iptr], hVz[iptr]);
          fprintf(stdout,"metric equals %f,%f,%f,%f,%f,%f,%f,%f,%f\n",
                    xix,xiy,xiz,etx,ety,etz,ztx,zty,ztz);
          fprintf(stdout,"cos(c) and recip_sin(c) equals %f,%f\n",
                    cos(c),recip_sin(c));          
        }
*/
        iptr += 1;
      }
    }
  }
}

void
sv_curv_col_el_iso_rhs_inner_car(
    float *restrict  Vx , float *restrict  Vy , float *restrict  Vz ,
    float *restrict  Txx, float *restrict  Tyy, float *restrict  Tzz,
    float *restrict  Txz, float *restrict  Tyz, float *restrict  Txy,
    float *restrict hVx , float *restrict hVy , float *restrict hVz ,
    float *restrict hTxx, float *restrict hTyy, float *restrict hTzz,
    float *restrict hTxz, float *restrict hTyz, float *restrict hTxy,
    float *restrict lam3d, float *restrict mu3d, float *restrict slw3d,
    int nii1, int nii2, int njj1, int njj2, int nkk1, int nkk2, float dxyz,
    size_t siz_line_car, size_t siz_slice_car,
    int fdx_len, int *restrict fdx_indx, float *restrict fdx_coef,
    int fdy_len, int *restrict fdy_indx, float *restrict fdy_coef,
    int fdz_len, int *restrict fdz_indx, float *restrict fdz_coef,
    const int myid, const int verbose)
{
  // use local stack array for speedup
  float  lfdx_coef [fdx_len];
  int    lfdx_shift[fdx_len];
  float  lfdy_coef [fdy_len];
  int    lfdy_shift[fdy_len];
  float  lfdz_coef [fdz_len];
  int    lfdz_shift[fdz_len];

  // loop var for fd
  int n_fd; // loop var for fd

  // local var
  float DxTxx,DxTyy,DxTzz,DxTxy,DxTxz,DxTyz,DxVx,DxVy,DxVz;
  float DyTxx,DyTyy,DyTzz,DyTxy,DyTxz,DyTyz,DyVx,DyVy,DyVz;
  float DzTxx,DzTyy,DzTzz,DzTxy,DzTxz,DzTyz,DzVx,DzVy,DzVz;
  float lam,mu,lam2mu,slw;

  float *restrict Vx_ptr;
  float *restrict Vy_ptr;
  float *restrict Vz_ptr;
  float *restrict Txx_ptr;
  float *restrict Txy_ptr;
  float *restrict Txz_ptr;
  float *restrict Tyy_ptr;
  float *restrict Tzz_ptr;
  float *restrict Tyz_ptr;

  for (int i=0; i < fdx_len; i++) {
    lfdx_coef [i] = fdx_coef[i];
    lfdx_shift[i] = fdx_indx[i];
  }

  for (int j=0; j < fdy_len; j++) {
    lfdy_coef [j] = fdy_coef[j];
    lfdy_shift[j] = fdy_indx[j] * siz_line_car;
  }
  for (int k=0; k < fdz_len; k++) {
    lfdz_coef [k] = fdz_coef[k];
    lfdz_shift[k] = fdz_indx[k] * siz_slice_car;
  }

  for (size_t k=nkk1; k<= nkk2; k++)
  {
    size_t iptr_k = k * siz_slice_car;

    for (size_t j=njj1 ; j<= njj2; j++)
    {
      size_t iptr_j = iptr_k + j * siz_line_car;

      size_t iptr = iptr_j + nii1;

      for (size_t i=nii1; i<= nii2; i++)
      {
        Vx_ptr = Vx + iptr;
        Vy_ptr = Vy + iptr;
        Vz_ptr = Vz + iptr;
        Txx_ptr = Txx + iptr;
        Tyy_ptr = Tyy + iptr;
        Tzz_ptr = Tzz + iptr;
        Txz_ptr = Txz + iptr;
        Tyz_ptr = Tyz + iptr;
        Txy_ptr = Txy + iptr;

        // Vx derivatives
        M_FD_SHIFT_PTR_MACDRP(DxVx, Vx_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyVx, Vx_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzVx, Vx_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Vy derivatives
        M_FD_SHIFT_PTR_MACDRP(DxVy, Vy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyVy, Vy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzVy, Vy_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Vz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxVz, Vz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyVz, Vz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzVz, Vz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Txx derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTxx, Txx_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTxx, Txx_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTxx, Txx_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Tyy derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTyy, Tyy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTyy, Tyy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTyy, Tyy_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Tzz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTzz, Tzz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTzz, Tzz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTzz, Tzz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Txz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTxz, Txz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTxz, Txz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTxz, Txz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Tyz derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTyz, Tyz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTyz, Tyz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTyz, Tyz_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

        // Txy derivatives
        M_FD_SHIFT_PTR_MACDRP(DxTxy, Txy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DyTxy, Txy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
        M_FD_SHIFT_PTR_MACDRP(DzTxy, Txy_ptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);


        // medium
        lam = lam3d[iptr];
        mu  =  mu3d[iptr];
        slw = slw3d[iptr];
        lam2mu = lam + 2.0 * mu;

        // moment equation
        hVx[iptr] = slw*( DxTxx + DyTxy + DzTxz )/dxyz;
        hVy[iptr] = slw*( DxTxy + DyTyy + DzTyz )/dxyz;
        hVz[iptr] = slw*( DxTxz + DyTyz + DzTzz )/dxyz;

        // Hooke's equatoin
        hTxx[iptr] =  lam2mu*DxVx /dxyz + lam * (DyVy + DzVz)/dxyz;

        hTyy[iptr] =  lam2mu*DyVy /dxyz + lam * (DxVx + DzVz)/dxyz;

        hTzz[iptr] =  lam2mu*DzVz /dxyz + lam * (DxVx + DyVy)/dxyz;

        hTxy[iptr] = mu *(DxVy + DyVx)/dxyz;
        hTxz[iptr] = mu *(DzVx + DxVz)/dxyz;
        hTyz[iptr] = mu *(DzVy + DyVz)/dxyz;  

        iptr += 1;
      }
    }
  }
}

/*******************************************************************************
 * free surface boundary
 ******************************************************************************/

/*
 * implement traction image boundary 
 */

void
sv_curv_col_el_iso_rhs_timg_z2(
    float *restrict  Txx, float *restrict  Tyy, float *restrict  Tzz,
    float *restrict  Txz, float *restrict  Tyz, float *restrict  Txy,
    float *restrict hVx , float *restrict hVy , float *restrict hVz ,
    float *restrict xi_x, float *restrict xi_y, float *restrict xi_z,
    float *restrict et_x, float *restrict et_y, float *restrict et_z,
    float *restrict zt_x, float *restrict zt_y, float *restrict zt_z,
    float *restrict jac3d, float *restrict slw3d,float *restrict y3d, float *restrict z3d, float *restrict z_zt,
    int ni1, int ni2, int nj1, int nj2, int nk1, int nk2,
    size_t siz_line, size_t siz_slice,
    int fdx_len, int *restrict fdx_indx, float *restrict fdx_coef,
    int fdy_len, int *restrict fdy_indx, float *restrict fdy_coef,
    int fdz_len, int *restrict fdz_indx, float *restrict fdz_coef,
    fd_op_t *fdz_op, int fdz_max_len, const int myid, const int verbose)
{
  // use local stack array for speedup
  float  lfdx_coef [fdx_len];
  int lfdx_shift[fdx_len];
  float  lfdy_coef [fdy_len];
  int lfdy_shift[fdy_len];
  float  lfdz_coef [fdz_len];
  int lfdz_shift[fdz_len];

  float  jzfdz_coef [fdz_max_len];//used for compact differ
  int    jzfdz_shift[fdz_max_len];

  // put fd op into local array
  for (int i=0; i < fdx_len; i++) {
    lfdx_coef [i] = fdx_coef[i];
    lfdx_shift[i] = fdx_indx[i];
  }
  for (int j=0; j < fdy_len; j++) {
    lfdy_coef [j] = fdy_coef[j];
    lfdy_shift[j] = fdy_indx[j] * siz_line;
  }
  for (int k=0; k < fdz_len; k++) {
    lfdz_coef [k] = fdz_coef[k];
    lfdz_shift[k] = fdz_indx[k] * siz_slice;
  }

  int n_fd; // loop var for fd

  // local var
  float DcTz,DfTz,DrTz;
  float xi_c,xi_f,xi_r,et_c,et_f,et_r,zt_c,zt_f,zt_r;
  float c,r,zzt;
  float *restrict Txx_ptr;
  float *restrict Tyy_ptr;
  float *restrict Tzz_ptr;
  float *restrict Txy_ptr;
  float *restrict Txz_ptr;
  float *restrict Tyz_ptr;
  float DxTxx,DxTyy,DxTzz,DxTxy,DxTxz,DxTyz;
  float DyTxx,DyTyy,DyTzz,DyTxy,DyTxz,DyTyz;
  float DzTxx,DzTyy,DzTzz,DzTxy,DzTxz,DzTyz;
  // n for loop of 5 ; iptr4vec for near points
  int n, iptr4vec;
  float jac,slw;


  // last indx, free surface force Tx/Ty/Tz to 0 in cal
  int k_min = nk2 - fdz_indx[fdz_len-1];
  // point affected by timg
  for (size_t k=k_min+1; k <= nk2; k++)
  {
    if (k==nk2)//nk2 need image
    {
      int n_free =  - fdz_indx[0]; // nk2 in fd indx
      float vecTc[fdz_len];
      float vecTf[fdz_len];
      float vecTr[fdz_len];//traction
      float vecABS[fdz_len];//abs
      float tmpc[fdz_len];
      float tmpf[fdz_len];
      float tmpr[fdz_len];

      size_t iptr_k = k * siz_slice;
      for (size_t j=nj1; j<=nj2; j++)
      {
        size_t iptr_j = iptr_k + j * siz_line;
        size_t iptr = iptr_j + ni1;

        for (size_t i=ni1; i<=ni2; i++)
        {
            // metric
            et_f = xi_x[iptr];
            et_c = xi_y[iptr];
            et_r = xi_z[iptr];
            xi_f = et_x[iptr];
            xi_c = et_y[iptr];
            xi_r = et_z[iptr];
            zt_f = zt_x[iptr];
            zt_c = zt_y[iptr];
            zt_r = zt_z[iptr];

            c = y3d[iptr];
            r = z3d[iptr];
            slw = slw3d[iptr];
            zzt = z_zt[iptr];

            //under surface
            for (n=0; n<n_free; n++) {
              iptr4vec = iptr + fdz_indx[n] * siz_slice;//nk2-1 layer
              //vecT is traction
              vecTc[n] =  zt_z[iptr4vec] * Tyz[iptr4vec]
                        + zt_y[iptr4vec] * Tyy[iptr4vec] /z3d[iptr4vec]
                        + zt_x[iptr4vec] * Txy[iptr4vec] /z3d[iptr4vec] * recip_sin(y3d[iptr4vec]);
              vecTf[n] =  zt_z[iptr4vec] * Txz[iptr4vec]
                        + zt_y[iptr4vec] * Txy[iptr4vec] /z3d[iptr4vec]
                        + zt_x[iptr4vec] * Txx[iptr4vec] /z3d[iptr4vec] * recip_sin(y3d[iptr4vec]);
              vecTr[n] =  zt_z[iptr4vec] * Tzz[iptr4vec]
                        + zt_y[iptr4vec] * Tyz[iptr4vec] /z3d[iptr4vec]
                        + zt_x[iptr4vec] * Txz[iptr4vec] /z3d[iptr4vec] * recip_sin(y3d[iptr4vec]);
            vecABS[n]  =  sqrt(zt_z[iptr4vec]*zt_z[iptr4vec] + zt_y[iptr4vec]/z3d[iptr4vec] *zt_y[iptr4vec]/z3d[iptr4vec]
                               + zt_x[iptr4vec]/z3d[iptr4vec]* recip_sin(y3d[iptr4vec]) 
                               * zt_x[iptr4vec]/z3d[iptr4vec]* recip_sin(y3d[iptr4vec]) );                    
            }


            vecTc[n_free] =0;
            vecTf[n_free] =0;
            vecTr[n_free] =0;
            vecABS[n_free]  =sqrt(zt_r*zt_r + zt_c/r *zt_c/r 
                                + zt_f/r *recip_sin(c) * zt_f/r *recip_sin(c) );

            //image layer
            for (n=n_free+1; n<fdz_len; n++)
            {
              int n_img = fdz_indx[n] - 2*(n-n_free);
              int iptrout =iptr + fdz_indx[n] * siz_slice; //used for cal vecABS only

              iptr4vec = iptr + n_img * siz_slice; 
              vecTc[n] = - zt_z[iptr4vec] * Tyz[iptr4vec]
                        - zt_y[iptr4vec] * Tyy[iptr4vec] /z3d[iptr4vec]
                        - zt_x[iptr4vec] * Txy[iptr4vec] /z3d[iptr4vec]  * recip_sin(y3d[iptr4vec]);
              vecTf[n] = - zt_z[iptr4vec] * Txz[iptr4vec]
                        - zt_y[iptr4vec] * Txy[iptr4vec] /z3d[iptr4vec]
                        - zt_x[iptr4vec] * Txx[iptr4vec] /z3d[iptr4vec]  * recip_sin(y3d[iptr4vec]);
              vecTr[n] = - zt_z[iptr4vec] * Tzz[iptr4vec]
                        - zt_y[iptr4vec] * Tyz[iptr4vec] /z3d[iptr4vec]
                        - zt_x[iptr4vec] * Txz[iptr4vec] /z3d[iptr4vec]  * recip_sin(y3d[iptr4vec]);
            vecABS[n]  =  sqrt(zt_z[iptrout]*zt_z[iptrout] + zt_y[iptrout]/z3d[iptrout] *zt_y[iptrout]/z3d[iptrout]
                               + zt_x[iptrout]/z3d[iptrout]*recip_sin(y3d[iptrout])
                               *zt_x[iptrout]/z3d[iptrout]*recip_sin(y3d[iptrout])); 
            }
            
            //cal vecTc/vecABS
            for (int i=0; i < fdz_len; i++) {
               tmpc[i] = vecTc[i]/vecABS[i];
               tmpf[i] = vecTf[i]/vecABS[i];
               tmpr[i] = vecTr[i]/vecABS[i];
            }
            M_FD_NOINDX(DcTz, tmpc , fdz_len, lfdz_coef, n_fd);
            M_FD_NOINDX(DfTz, tmpf , fdz_len, lfdz_coef, n_fd);
            M_FD_NOINDX(DrTz, tmpr , fdz_len, lfdz_coef, n_fd);

            Txx_ptr = Txx + iptr;
            Tyy_ptr = Tyy + iptr;
            Tzz_ptr = Tzz + iptr;
            Txy_ptr = Txy + iptr;
            Txz_ptr = Txz + iptr;
            Tyz_ptr = Tyz + iptr;
            
            M_FD_SHIFT_PTR_MACDRP(DxTxx, Txx_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTyy, Tyy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTzz, Tzz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTxy, Txy_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTxz, Txz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DxTyz, Tyz_ptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);

            M_FD_SHIFT_PTR_MACDRP(DyTxx, Txx_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DyTyy, Tyy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DyTzz, Tzz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DyTxy, Txy_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DyTxz, Txz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
            M_FD_SHIFT_PTR_MACDRP(DyTyz, Tyz_ptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);

            float absT =sqrt(zt_r*zt_r + zt_c/r *zt_c/r 
                           + zt_f/r*recip_sin(c)*zt_f/r*recip_sin(c) );

            hVx[iptr] = slw*( (xi_c*DyTxy + et_c*DxTxy )/r + (xi_f*DyTxx + et_f*DxTxx )/r*recip_sin(c)
                              + xi_r*DyTxz + et_r*DxTxz 
                              + (3**Txz_ptr + 2**Txy_ptr *cos(c)*recip_sin(c) )/r
                              + DfTz*absT - (zt_c*zt_c*zzt + zt_f*zt_f*zzt*recip_sin(c)*recip_sin(c))/r/r/r
                              /absT/absT*(zt_r**Txz_ptr +zt_c**Txy_ptr/r +zt_f**Txx_ptr/r *recip_sin(c))
                              + zzt*zt_c/r/r**Txy_ptr + zzt*zt_f/r/r*recip_sin(c)**Txx_ptr );

            hVy[iptr] = slw*( (xi_c*DyTyy + et_c*DxTyy )/r + (xi_f*DyTxy + et_f*DxTxy )/r*recip_sin(c)
                              + xi_r*DyTyz + et_r*DxTyz 
                              + (3**Tyz_ptr + (*Tyy_ptr - *Txx_ptr)*cos(c)*recip_sin(c) )/r
                              + DcTz*absT - (zt_c*zt_c*zzt + zt_f*zt_f*zzt*recip_sin(c)*recip_sin(c))/r/r/r
                              /absT/absT*(zt_r**Tyz_ptr +zt_c**Tyy_ptr/r +zt_f**Txy_ptr/r *recip_sin(c))
                              + zzt*zt_c/r/r**Tyy_ptr + zzt*zt_f/r/r*recip_sin(c)**Txy_ptr );
    
            hVz[iptr] = slw*( (xi_c*DyTyz + et_c*DxTyz )/r + (xi_f*DyTxz + et_f*DxTxz )/r*recip_sin(c)
                              + xi_r*DyTzz + et_r*DxTzz 
                              + (2**Tzz_ptr + *Tyz_ptr *cos(c)*recip_sin(c) - *Tyy_ptr - *Txx_ptr )/r
                              + DrTz*absT - (zt_c*zt_c*zzt + zt_f*zt_f*zzt*recip_sin(c)*recip_sin(c))/r/r/r
                              /absT/absT*(zt_r**Tzz_ptr +zt_c**Tyz_ptr/r +zt_f**Txz_ptr/r *recip_sin(c))
                              + zzt*zt_c/r/r**Tyz_ptr + zzt*zt_f/r/r*recip_sin(c)**Txz_ptr );
            // next
            iptr += 1;   
        }
      }
    }//end k==nk2
    else
    {

      n = nk2 - k;//indx of layer under surface , to get fd sheme

      int  lfdz_len  = fdz_op[n].total_len;//len is 2 or 3
      // point to indx/coef for this point
      int   *p_fdz_indx  = fdz_op[n].indx;
      float *p_fdz_coef  = fdz_op[n].coef;
      for (n_fd = 0; n_fd < lfdz_len ; n_fd++) {
        jzfdz_shift[n_fd] = p_fdz_indx[n_fd] * siz_slice;
        jzfdz_coef[n_fd]  = p_fdz_coef[n_fd];
      }

      size_t iptr_k = k * siz_slice;
      for (size_t j=nj1; j<=nj2; j++)
        {
          size_t iptr_j = iptr_k + j * siz_line;
          size_t iptr = iptr_j + ni1;

          for (size_t i=ni1; i<=ni2; i++)//each column
            {
              // metric
              et_f = xi_x[iptr];
              et_c = xi_y[iptr];
              et_r = xi_z[iptr];
              xi_f = et_x[iptr];
              xi_c = et_y[iptr];
              xi_r = et_z[iptr];
              zt_f = zt_x[iptr];
              zt_c = zt_y[iptr];
              zt_r = zt_z[iptr];

              c = y3d [iptr];
              r = z3d [iptr];
              slw = slw3d[iptr];

              M_FD_SHIFT(DxTxx, Txx, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTyy, Tyy, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTzz, Tzz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTxy, Txy, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTxz, Txz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTyz, Tyz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);

              M_FD_SHIFT(DyTxx, Txx, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTyy, Tyy, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTzz, Tzz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTxy, Txy, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTxz, Txz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTyz, Tyz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);

              M_FD_SHIFT(DzTxx, Txx, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
              M_FD_SHIFT(DzTyy, Tyy, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
              M_FD_SHIFT(DzTzz, Tzz, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
              M_FD_SHIFT(DzTxy, Txy, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
              M_FD_SHIFT(DzTxz, Txz, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);
              M_FD_SHIFT(DzTyz, Tyz, iptr, lfdz_len, jzfdz_shift, jzfdz_coef, n_fd);

              hVx[iptr] = slw*( (xi_c*DyTxy + et_c*DxTxy + zt_c*DzTxy )/r 
                              + (xi_f*DyTxx + et_f*DxTxx + zt_f*DzTxx )/r*recip_sin(c)
                              + xi_r*DyTxz + et_r*DxTxz  + zt_r*DzTxz
                              + (3*Txz[iptr] + 2*Txy[iptr] *cos(c)*recip_sin(c) )/r);

              hVy[iptr] = slw*( (xi_c*DyTyy + et_c*DxTyy + zt_c*DzTyy)/r 
                              + (xi_f*DyTxy + et_f*DxTxy + zt_f*DzTxy)/r*recip_sin(c)
                              + xi_r*DyTyz + et_r*DxTyz  + zt_r*DzTyz 
                              + (3*Tyz[iptr] + (Tyy[iptr] - Txx[iptr])*cos(c)*recip_sin(c) )/r );


              hVz[iptr] = slw*( (xi_c*DyTyz + et_c*DxTyz + zt_c*DzTyz )/r 
                              + (xi_f*DyTxz + et_f*DxTxz + zt_f*DzTxz)/r*recip_sin(c)
                              + xi_r*DyTzz + et_r*DxTzz  + zt_r*DzTzz
                              + (2*Tzz[iptr] + Tyz[iptr] *cos(c)*recip_sin(c) - Txx[iptr] - Tyy[iptr] )/r);

              iptr += 1;
            }
        }
    }
  }
}

/*
 * implement vlow boundary
 */

void
sv_curv_col_el_iso_rhs_vlow_z2(
    float *restrict  Vx , float *restrict  Vy , float *restrict  Vz ,
    float *restrict hTxx, float *restrict hTyy, float *restrict hTzz,
    float *restrict hTxz, float *restrict hTyz, float *restrict hTxy,
    float *restrict xi_x, float *restrict xi_y, float *restrict xi_z,
    float *restrict et_x, float *restrict et_y, float *restrict et_z,
    float *restrict zt_x, float *restrict zt_y, float *restrict zt_z,
    float *restrict lam3d, float *restrict mu3d, float *restrict slw3d,
    float *restrict y3d, float *restrict z3d,
    float *restrict matVx2Vz, float *restrict matVy2Vz, float *restrict matV2Vz,
    int ni1, int ni2, int nj1, int nj2, int nk1, int nk2,
    size_t siz_line, size_t siz_slice,
    int fdx_len, int *restrict fdx_indx, float *restrict fdx_coef,
    int fdy_len, int *restrict fdy_indx, float *restrict fdy_coef,
    int num_of_fdz_op, fd_op_t *fdz_op, int fdz_max_len,
    const int myid, const int verbose)
{
  // use local stack array for speedup
  float  lfdx_coef [fdx_len];
  int    lfdx_shift[fdx_len];
  float  lfdy_coef [fdy_len];
  int    lfdy_shift[fdy_len];

  // allocate max_len because fdz may have different lens
  float  lfdz_coef [fdz_max_len];
  int    lfdz_shift[fdz_max_len];

  // local var
  int i,j,k;
  int n_fd; // loop var for fd
  int fdz_len;

  // local var
  float DxVx,DxVy,DxVz;
  float DyVx,DyVy,DyVz;
  float DzVx,DzVy,DzVz;
  float lam,mu,lam2mu,slw;
  float xi_c,xi_f,xi_r,et_c,et_f,et_r,zt_c,zt_f,zt_r;
  float c,r;

  // put fd op into local array
  for (i=0; i < fdx_len; i++) {
    lfdx_coef [i] = fdx_coef[i];
    lfdx_shift[i] = fdx_indx[i];
  }
  for (j=0; j < fdy_len; j++) {
    lfdy_coef [j] = fdy_coef[j];
    lfdy_shift[j] = fdy_indx[j] * siz_line;
  }

  // loop near surface layers
  //for (size_t n=0; n < 1; n++)
  for (size_t n=0; n < num_of_fdz_op-1; n++)
  {
    // conver to k index, from surface to inner
    k = nk2 - n;

    // get pos and len for this point
    int  lfdz_len  = fdz_op[n].total_len;
    // point to indx/coef for this point
    int   *p_fdz_indx  = fdz_op[n].indx;
    float *p_fdz_coef  = fdz_op[n].coef;
    for (n_fd = 0; n_fd < lfdz_len ; n_fd++) {
      lfdz_shift[n_fd] = p_fdz_indx[n_fd] * siz_slice;
      lfdz_coef[n_fd]  = p_fdz_coef[n_fd];
    }

    // for index
    size_t iptr_k = k * siz_slice;

    for (j=nj1; j<=nj2; j++)
    {
      size_t iptr_j = iptr_k + j * siz_line;

      size_t iptr = iptr_j + ni1;

      for (i=ni1; i<=ni2; i++)
      {
        // metric
        et_f = xi_x[iptr];
        et_c = xi_y[iptr];
        et_r = xi_z[iptr];
        xi_f = et_x[iptr];
        xi_c = et_y[iptr];
        xi_r = et_z[iptr];
        zt_f = zt_x[iptr];
        zt_c = zt_y[iptr];
        zt_r = zt_z[iptr];
        c = y3d[iptr];
        r = z3d[iptr];

        // medium
        lam = lam3d[iptr];
        mu  =  mu3d[iptr];
        slw = slw3d[iptr];
        lam2mu = lam + 2.0 * mu;

        // Vx derivatives
        M_FD_SHIFT(DxVx, Vx, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT(DyVx, Vx, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);

        // Vy derivatives
        M_FD_SHIFT(DxVy, Vy, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT(DyVy, Vy, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);

        // Vz derivatives
        M_FD_SHIFT(DxVz, Vz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
        M_FD_SHIFT(DyVz, Vz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);

        if (k==nk2) // at surface, convert
        {
          size_t ij = (i + j * siz_line)*9;
          DzVy = matVx2Vz[ij+3*0+0] * DyVy
               + matVx2Vz[ij+3*0+1] * DyVx
               + matVx2Vz[ij+3*0+2] * DyVz
               + matVy2Vz[ij+3*0+0] * DxVy
               + matVy2Vz[ij+3*0+1] * DxVx
               + matVy2Vz[ij+3*0+2] * DxVz
               + matV2Vz[ij+3*0+0] * Vy[iptr]
               + matV2Vz[ij+3*0+1] * Vx[iptr]
               + matV2Vz[ij+3*0+2] * Vz[iptr];

          DzVx = matVx2Vz[ij+3*1+0] * DyVy
               + matVx2Vz[ij+3*1+1] * DyVx
               + matVx2Vz[ij+3*1+2] * DyVz
               + matVy2Vz[ij+3*1+0] * DxVy
               + matVy2Vz[ij+3*1+1] * DxVx
               + matVy2Vz[ij+3*1+2] * DxVz
               + matV2Vz[ij+3*1+0] * Vy[iptr]
               + matV2Vz[ij+3*1+1] * Vx[iptr]
               + matV2Vz[ij+3*1+2] * Vz[iptr];

          DzVz = matVx2Vz[ij+3*2+0] * DyVy
               + matVx2Vz[ij+3*2+1] * DyVx
               + matVx2Vz[ij+3*2+2] * DyVz
               + matVy2Vz[ij+3*2+0] * DxVy
               + matVy2Vz[ij+3*2+1] * DxVx
               + matVy2Vz[ij+3*2+2] * DxVz
               + matV2Vz[ij+3*2+0] * Vy[iptr]
               + matV2Vz[ij+3*2+1] * Vx[iptr]
               + matV2Vz[ij+3*2+2] * Vz[iptr];
        }
        else // lower than surface, lower order
        {
          M_FD_SHIFT(DzVx, Vx, iptr, lfdz_len, lfdz_shift, lfdz_coef, n_fd);
          M_FD_SHIFT(DzVy, Vy, iptr, lfdz_len, lfdz_shift, lfdz_coef, n_fd);
          M_FD_SHIFT(DzVz, Vz, iptr, lfdz_len, lfdz_shift, lfdz_coef, n_fd);
        }

        // Hooke's equatoin
        hTxx[iptr] =  lam *    ( xi_c*DyVy  +et_c*DxVy + zt_c*DzVy + Vz[iptr])/r
                    +lam2mu  * (( xi_f*DyVx + et_f*DxVx + zt_f*DzVx) * recip_sin(c) + Vz[iptr] 
                                + Vy[iptr]*cos(c)*recip_sin(c))/r
                    + lam    * (xi_r*DyVz + et_r*DxVz + zt_r*DzVz);

        hTyy[iptr] =  lam2mu * ( xi_c*DyVy  +et_c*DxVy + zt_c*DzVy + Vz[iptr])/r
                    + lam    * (( xi_f*DyVx + et_f*DxVx + zt_f*DzVx) * recip_sin(c) + Vz[iptr]
                                + Vy[iptr]*cos(c)*recip_sin(c))/r
                    + lam    * (xi_r*DyVz + et_r*DxVz + zt_r*DzVz);


        hTzz[iptr] =  lam *    ( xi_c*DyVy  +et_c*DxVy + zt_c*DzVy + Vz[iptr])/r
                    + lam    * (( xi_f*DyVx + et_f*DxVx + zt_f*DzVx) * recip_sin(c) + Vz[iptr]
                                + Vy[iptr]*cos(c)*recip_sin(c))/r
                    + lam2mu * (xi_r*DyVz + et_r*DxVz + zt_r*DzVz);


        hTxy[iptr] = mu *( xi_c*DyVx + et_c*DxVx + zt_c*DzVx
                        + (xi_f*DyVy + et_f*DxVy + zt_f*DzVy)*recip_sin(c)
                        - Vx[iptr]*cos(c)*recip_sin(c)) /r;
        
        hTxz[iptr] = mu *( (xi_f*DyVz + et_f*DxVz + zt_f*DzVz)*recip_sin(c)/r
                          + xi_r*DyVx + et_r*DxVx + zt_r*DzVx
                          - Vx[iptr]/r);

        hTyz[iptr] = mu *( (xi_c*DyVz + et_c*DxVz + zt_c*DzVz)/r
                          + xi_r*DyVy + et_r*DxVy + zt_r*DzVy
                          - Vy[iptr]/r);


        iptr += 1;
      }
    }
  }
}

/*******************************************************************************
 * CFS-PML boundary
 ******************************************************************************/

/*
 * cfspml, reference to each pml var inside function
 */

void
sv_curv_col_el_iso_rhs_cfspml(
    float *restrict  Vx , float *restrict  Vy , float *restrict  Vz ,
    float *restrict  Txx, float *restrict  Tyy, float *restrict  Tzz,
    float *restrict  Txz, float *restrict  Tyz, float *restrict  Txy,
    float *restrict hVx , float *restrict hVy , float *restrict hVz ,
    float *restrict hTxx, float *restrict hTyy, float *restrict hTzz,
    float *restrict hTxz, float *restrict hTyz, float *restrict hTxy,
    float *restrict xi_x, float *restrict xi_y, float *restrict xi_z,
    float *restrict et_x, float *restrict et_y, float *restrict et_z,
    float *restrict zt_x, float *restrict zt_y, float *restrict zt_z,
    float *restrict lam3d, float *restrict  mu3d, float *restrict slw3d,
    int nk2, size_t siz_line, size_t siz_slice,
    int fdx_len, int *restrict fdx_indx, float *restrict fdx_coef,
    int fdy_len, int *restrict fdy_indx, float *restrict fdy_coef,
    int fdz_len, int *restrict fdz_indx, float *restrict fdz_coef,
    bdrypml_t *bdrypml, bdryfree_t *bdryfree,
    const int myid, const int verbose)
{

  float *matVx2Vz = bdryfree->matVx2Vz2;
  float *matVy2Vz = bdryfree->matVy2Vz2;

  // loop var for fd
  int n_fd; // loop var for fd
  // use local stack array for better speed
  float  lfdx_coef [fdx_len];
  int    lfdx_shift[fdx_len];
  float  lfdy_coef [fdy_len];
  int    lfdy_shift[fdy_len];
  float  lfdz_coef [fdz_len];
  int    lfdz_shift[fdz_len];

  // val on point
  float DxTxx,DxTyy,DxTzz,DxTxy,DxTxz,DxTyz,DxVx,DxVy,DxVz;
  float DyTxx,DyTyy,DyTzz,DyTxy,DyTxz,DyTyz,DyVx,DyVy,DyVz;
  float DzTxx,DzTyy,DzTzz,DzTxy,DzTxz,DzTyz,DzVx,DzVy,DzVz;
  float lam,mu,lam2mu,slw;
  float xix,xiy,xiz,etx,ety,etz,ztx,zty,ztz;
  float hVx_rhs,hVy_rhs,hVz_rhs;
  float hTxx_rhs,hTyy_rhs,hTzz_rhs,hTxz_rhs,hTyz_rhs,hTxy_rhs;
  // for free surface
  float Dx_DzVx,Dy_DzVx,Dx_DzVy,Dy_DzVy,Dx_DzVz,Dy_DzVz;

  // local
  int i,j,k;
  int iptr, iptr_j, iptr_k, iptr_a;
  float coef_A, coef_B, coef_D, coef_B_minus_1;

  // put fd op into local array
  for (i=0; i < fdx_len; i++) {
    lfdx_coef [i] = fdx_coef[i];
    lfdx_shift[i] = fdx_indx[i];
  }
  for (j=0; j < fdy_len; j++) {
    lfdy_coef [j] = fdy_coef[j];
    lfdy_shift[j] = fdy_indx[j] * siz_line;
  }
  for (k=0; k < fdz_len; k++) {
    lfdz_coef [k] = fdz_coef[k];
    lfdz_shift[k] = fdz_indx[k] * siz_slice;
  }

  // check each side
  for (int idim=0; idim<CONST_NDIM; idim++)
  {
    for (int iside=0; iside<2; iside++)
    {
      // skip to next face if not cfspml
      if (bdrypml->is_at_sides[idim][iside] == 0) continue;

      // get index into local var
      int abs_ni1 = bdrypml->ni1[idim][iside];
      int abs_ni2 = bdrypml->ni2[idim][iside];
      int abs_nj1 = bdrypml->nj1[idim][iside];
      int abs_nj2 = bdrypml->nj2[idim][iside];
      int abs_nk1 = bdrypml->nk1[idim][iside];
      int abs_nk2 = bdrypml->nk2[idim][iside];

#ifdef SV_ELISO1ST_CURV_MACDRP_DEBUG
    //fprintf(stdout," iface=%d,ni1=%d,ni2=%d,nj1=%d,nj2=%d,nk1=%d,nk2=%d\n",
    //        iface,abs_ni1,abs_ni2,abs_nj1,abs_nj2,abs_nk1,abs_nk2);
    //fflush(stdout);
#endif

      // get coef for this face
      float *restrict ptr_coef_A = bdrypml->A[idim][iside];
      float *restrict ptr_coef_B = bdrypml->B[idim][iside];
      float *restrict ptr_coef_D = bdrypml->D[idim][iside];

      bdrypml_auxvar_t *auxvar = &(bdrypml->auxvar[idim][iside]);

      // get pml vars
      float *restrict abs_vars_cur = auxvar->cur;
      float *restrict abs_vars_rhs = auxvar->rhs;

      float *restrict pml_Vx   = abs_vars_cur + auxvar->Vx_pos;
      float *restrict pml_Vy   = abs_vars_cur + auxvar->Vy_pos;
      float *restrict pml_Vz   = abs_vars_cur + auxvar->Vz_pos;
      float *restrict pml_Txx  = abs_vars_cur + auxvar->Txx_pos;
      float *restrict pml_Tyy  = abs_vars_cur + auxvar->Tyy_pos;
      float *restrict pml_Tzz  = abs_vars_cur + auxvar->Tzz_pos;
      float *restrict pml_Txz  = abs_vars_cur + auxvar->Txz_pos;
      float *restrict pml_Tyz  = abs_vars_cur + auxvar->Tyz_pos;
      float *restrict pml_Txy  = abs_vars_cur + auxvar->Txy_pos;

      float *restrict pml_hVx  = abs_vars_rhs + auxvar->Vx_pos;
      float *restrict pml_hVy  = abs_vars_rhs + auxvar->Vy_pos;
      float *restrict pml_hVz  = abs_vars_rhs + auxvar->Vz_pos;
      float *restrict pml_hTxx = abs_vars_rhs + auxvar->Txx_pos;
      float *restrict pml_hTyy = abs_vars_rhs + auxvar->Tyy_pos;
      float *restrict pml_hTzz = abs_vars_rhs + auxvar->Tzz_pos;
      float *restrict pml_hTxz = abs_vars_rhs + auxvar->Txz_pos;
      float *restrict pml_hTyz = abs_vars_rhs + auxvar->Tyz_pos;
      float *restrict pml_hTxy = abs_vars_rhs + auxvar->Txy_pos;

      // for each dim
      if (idim == 0 ) // x direction
      {
        iptr_a = 0;
        for (k=abs_nk1; k<=abs_nk2; k++)
        {
          iptr_k = k * siz_slice;
          for (j=abs_nj1; j<=abs_nj2; j++)
          {
            iptr_j = iptr_k + j * siz_line;
            iptr = iptr_j + abs_ni1;
            for (i=abs_ni1; i<=abs_ni2; i++)
            {
              // pml coefs
              int abs_i = i - abs_ni1;
              coef_D = ptr_coef_D[abs_i];
              coef_A = ptr_coef_A[abs_i];
              coef_B = ptr_coef_B[abs_i];
              coef_B_minus_1 = coef_B - 1.0;

              // metric
              xix = xi_x[iptr];
              xiy = xi_y[iptr];
              xiz = xi_z[iptr];

              // medium
              lam = lam3d[iptr];
              mu  =  mu3d[iptr];
              slw = slw3d[iptr];
              lam2mu = lam + 2.0 * mu;

              // xi derivatives
              M_FD_SHIFT(DxVx , Vx , iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxVy , Vy , iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxVz , Vz , iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTxx, Txx, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTyy, Tyy, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTzz, Tzz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTxz, Txz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTyz, Tyz, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);
              M_FD_SHIFT(DxTxy, Txy, iptr, fdx_len, lfdx_shift, lfdx_coef, n_fd);

              // combine for corr and aux vars
               hVx_rhs = slw * ( xix*DxTxx + xiy*DxTxy + xiz*DxTxz );
               hVy_rhs = slw * ( xix*DxTxy + xiy*DxTyy + xiz*DxTyz );
               hVz_rhs = slw * ( xix*DxTxz + xiy*DxTyz + xiz*DxTzz );
              hTxx_rhs = lam2mu*xix*DxVx + lam*xiy*DxVy + lam*xiz*DxVz;
              hTyy_rhs = lam*xix*DxVx + lam2mu*xiy*DxVy + lam*xiz*DxVz;
              hTzz_rhs = lam*xix*DxVx + lam*xiy*DxVy + lam2mu*xiz*DxVz;
              hTxy_rhs = mu*( xiy*DxVx + xix*DxVy );
              hTxz_rhs = mu*( xiz*DxVx + xix*DxVz );
              hTyz_rhs = mu*( xiz*DxVy + xiy*DxVz );

              // 1: make corr to moment equation
              hVx[iptr] += coef_B_minus_1 * hVx_rhs - coef_B * pml_Vx[iptr_a];
              hVy[iptr] += coef_B_minus_1 * hVy_rhs - coef_B * pml_Vy[iptr_a];
              hVz[iptr] += coef_B_minus_1 * hVz_rhs - coef_B * pml_Vz[iptr_a];

              // make corr to Hooke's equatoin
              hTxx[iptr] += coef_B_minus_1 * hTxx_rhs - coef_B * pml_Txx[iptr_a];
              hTyy[iptr] += coef_B_minus_1 * hTyy_rhs - coef_B * pml_Tyy[iptr_a];
              hTzz[iptr] += coef_B_minus_1 * hTzz_rhs - coef_B * pml_Tzz[iptr_a];
              hTxz[iptr] += coef_B_minus_1 * hTxz_rhs - coef_B * pml_Txz[iptr_a];
              hTyz[iptr] += coef_B_minus_1 * hTyz_rhs - coef_B * pml_Tyz[iptr_a];
              hTxy[iptr] += coef_B_minus_1 * hTxy_rhs - coef_B * pml_Txy[iptr_a];
              
              // 2: aux var
              //   a1 = alpha + d / beta, dealt in abs_set_cfspml
              pml_hVx[iptr_a]  = coef_D * hVx_rhs  - coef_A * pml_Vx[iptr_a];
              pml_hVy[iptr_a]  = coef_D * hVy_rhs  - coef_A * pml_Vy[iptr_a];
              pml_hVz[iptr_a]  = coef_D * hVz_rhs  - coef_A * pml_Vz[iptr_a];
              pml_hTxx[iptr_a] = coef_D * hTxx_rhs - coef_A * pml_Txx[iptr_a];
              pml_hTyy[iptr_a] = coef_D * hTyy_rhs - coef_A * pml_Tyy[iptr_a];
              pml_hTzz[iptr_a] = coef_D * hTzz_rhs - coef_A * pml_Tzz[iptr_a];
              pml_hTxz[iptr_a] = coef_D * hTxz_rhs - coef_A * pml_Txz[iptr_a];
              pml_hTyz[iptr_a] = coef_D * hTyz_rhs - coef_A * pml_Tyz[iptr_a];
              pml_hTxy[iptr_a] = coef_D * hTxy_rhs - coef_A * pml_Txy[iptr_a];

              // add contributions from free surface condition
              //  not consider timg because conflict with main cfspml,
              //     need to revise in the future if required
              if (bdryfree->is_at_sides[CONST_NDIM-1][1]==1 && k==nk2)
              {
                // zeta derivatives
                int ij = (i + j * siz_line)*9;
                Dx_DzVx = matVx2Vz[ij+3*0+0] * DxVx
                        + matVx2Vz[ij+3*0+1] * DxVy
                        + matVx2Vz[ij+3*0+2] * DxVz;

                Dx_DzVy = matVx2Vz[ij+3*1+0] * DxVx
                        + matVx2Vz[ij+3*1+1] * DxVy
                        + matVx2Vz[ij+3*1+2] * DxVz;

                Dx_DzVz = matVx2Vz[ij+3*2+0] * DxVx
                        + matVx2Vz[ij+3*2+1] * DxVy
                        + matVx2Vz[ij+3*2+2] * DxVz;

                // metric
                ztx = zt_x[iptr];
                zty = zt_y[iptr];
                ztz = zt_z[iptr];

                // keep xi derivative terms, including free surface convered
                hTxx_rhs =    lam2mu * (            ztx*Dx_DzVx)
                            + lam    * (            zty*Dx_DzVy
                                        +           ztz*Dx_DzVz);

                hTyy_rhs =   lam2mu * (            zty*Dx_DzVy)
                            +lam    * (            ztx*Dx_DzVx
                                                  +ztz*Dx_DzVz);

                hTzz_rhs =   lam2mu * (            ztz*Dx_DzVz)
                            +lam    * (            ztx*Dx_DzVx
                                                  +zty*Dx_DzVy);

                hTxy_rhs = mu *(
                             zty*Dx_DzVx + ztx*Dx_DzVy
                            );
                hTxz_rhs = mu *(
                             ztz*Dx_DzVx + ztx*Dx_DzVz
                            );
                hTyz_rhs = mu *(
                             ztz*Dx_DzVy + zty*Dx_DzVz
                            );

                // make corr to Hooke's equatoin
                hTxx[iptr] += (coef_B - 1.0) * hTxx_rhs;
                hTyy[iptr] += (coef_B - 1.0) * hTyy_rhs;
                hTzz[iptr] += (coef_B - 1.0) * hTzz_rhs;
                hTxz[iptr] += (coef_B - 1.0) * hTxz_rhs;
                hTyz[iptr] += (coef_B - 1.0) * hTyz_rhs;
                hTxy[iptr] += (coef_B - 1.0) * hTxy_rhs;

                // aux var
                //   a1 = alpha + d / beta, dealt in abs_set_cfspml
                pml_hTxx[iptr_a] += coef_D * hTxx_rhs;
                pml_hTyy[iptr_a] += coef_D * hTyy_rhs;
                pml_hTzz[iptr_a] += coef_D * hTzz_rhs;
                pml_hTxz[iptr_a] += coef_D * hTxz_rhs;
                pml_hTyz[iptr_a] += coef_D * hTyz_rhs;
                pml_hTxy[iptr_a] += coef_D * hTxy_rhs;
              }

              // incr index
              iptr   += 1;
              iptr_a += 1;
            } // i
          } // j
        } // k
      }
      else if (idim == 1) // y direction
      {
        iptr_a = 0;
        for (k=abs_nk1; k<=abs_nk2; k++)
        {
          iptr_k = k * siz_slice;
          for (j=abs_nj1; j<=abs_nj2; j++)
          {
            iptr_j = iptr_k + j * siz_line;
            iptr = iptr_j + abs_ni1;

            // pml coefs
            int abs_j = j - abs_nj1;
            coef_D = ptr_coef_D[abs_j];
            coef_A = ptr_coef_A[abs_j];
            coef_B = ptr_coef_B[abs_j];
            coef_B_minus_1 = coef_B - 1.0;

            for (i=abs_ni1; i<=abs_ni2; i++)
            {
              // metric
              etx = et_x[iptr];
              ety = et_y[iptr];
              etz = et_z[iptr];

              // medium
              lam = lam3d[iptr];
              mu  =  mu3d[iptr];
              slw = slw3d[iptr];
              lam2mu = lam + 2.0 * mu;

              // et derivatives
              M_FD_SHIFT(DyVx , Vx , iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyVy , Vy , iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyVz , Vz , iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTxx, Txx, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTyy, Tyy, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTzz, Tzz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTxz, Txz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTyz, Tyz, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);
              M_FD_SHIFT(DyTxy, Txy, iptr, fdy_len, lfdy_shift, lfdy_coef, n_fd);

              // combine for corr and aux vars
               hVx_rhs = slw * ( etx*DyTxx + ety*DyTxy + etz*DyTxz );
               hVy_rhs = slw * ( etx*DyTxy + ety*DyTyy + etz*DyTyz );
               hVz_rhs = slw * ( etx*DyTxz + ety*DyTyz + etz*DyTzz );
              hTxx_rhs = lam2mu*etx*DyVx + lam*ety*DyVy + lam*etz*DyVz;
              hTyy_rhs = lam*etx*DyVx + lam2mu*ety*DyVy + lam*etz*DyVz;
              hTzz_rhs = lam*etx*DyVx + lam*ety*DyVy + lam2mu*etz*DyVz;
              hTxy_rhs = mu*( ety*DyVx + etx*DyVy );
              hTxz_rhs = mu*( etz*DyVx + etx*DyVz );
              hTyz_rhs = mu*( etz*DyVy + ety*DyVz );

              // 1: make corr to moment equation
              hVx[iptr] += coef_B_minus_1 * hVx_rhs - coef_B * pml_Vx[iptr_a];
              hVy[iptr] += coef_B_minus_1 * hVy_rhs - coef_B * pml_Vy[iptr_a];
              hVz[iptr] += coef_B_minus_1 * hVz_rhs - coef_B * pml_Vz[iptr_a];

              // make corr to Hooke's equatoin
              hTxx[iptr] += coef_B_minus_1 * hTxx_rhs - coef_B * pml_Txx[iptr_a];
              hTyy[iptr] += coef_B_minus_1 * hTyy_rhs - coef_B * pml_Tyy[iptr_a];
              hTzz[iptr] += coef_B_minus_1 * hTzz_rhs - coef_B * pml_Tzz[iptr_a];
              hTxz[iptr] += coef_B_minus_1 * hTxz_rhs - coef_B * pml_Txz[iptr_a];
              hTyz[iptr] += coef_B_minus_1 * hTyz_rhs - coef_B * pml_Tyz[iptr_a];
              hTxy[iptr] += coef_B_minus_1 * hTxy_rhs - coef_B * pml_Txy[iptr_a];
              
              // 2: aux var
              //   a1 = alpha + d / beta, dealt in abs_set_cfspml
              pml_hVx[iptr_a]  = coef_D * hVx_rhs  - coef_A * pml_Vx[iptr_a];
              pml_hVy[iptr_a]  = coef_D * hVy_rhs  - coef_A * pml_Vy[iptr_a];
              pml_hVz[iptr_a]  = coef_D * hVz_rhs  - coef_A * pml_Vz[iptr_a];
              pml_hTxx[iptr_a] = coef_D * hTxx_rhs - coef_A * pml_Txx[iptr_a];
              pml_hTyy[iptr_a] = coef_D * hTyy_rhs - coef_A * pml_Tyy[iptr_a];
              pml_hTzz[iptr_a] = coef_D * hTzz_rhs - coef_A * pml_Tzz[iptr_a];
              pml_hTxz[iptr_a] = coef_D * hTxz_rhs - coef_A * pml_Txz[iptr_a];
              pml_hTyz[iptr_a] = coef_D * hTyz_rhs - coef_A * pml_Tyz[iptr_a];
              pml_hTxy[iptr_a] = coef_D * hTxy_rhs - coef_A * pml_Txy[iptr_a];

              // add contributions from free surface condition
              if (bdryfree->is_at_sides[CONST_NDIM-1][1]==1 && k==nk2)
              {
                // zeta derivatives
                int ij = (i + j * siz_line)*9;
                Dy_DzVx = matVy2Vz[ij+3*0+0] * DyVx
                        + matVy2Vz[ij+3*0+1] * DyVy
                        + matVy2Vz[ij+3*0+2] * DyVz;

                Dy_DzVy = matVy2Vz[ij+3*1+0] * DyVx
                        + matVy2Vz[ij+3*1+1] * DyVy
                        + matVy2Vz[ij+3*1+2] * DyVz;

                Dy_DzVz = matVy2Vz[ij+3*2+0] * DyVx
                        + matVy2Vz[ij+3*2+1] * DyVy
                        + matVy2Vz[ij+3*2+2] * DyVz;

                // metric
                ztx = zt_x[iptr];
                zty = zt_y[iptr];
                ztz = zt_z[iptr];

                hTxx_rhs =    lam2mu * (             ztx*Dy_DzVx)
                            + lam    * (             zty*Dy_DzVy
                                                    +ztz*Dy_DzVz);

                hTyy_rhs =   lam2mu * (             zty*Dy_DzVy)
                            +lam    * (             ztx*Dy_DzVx
                                                   +ztz*Dy_DzVz);

                hTzz_rhs =   lam2mu * (             ztz*Dy_DzVz)
                            +lam    * (             ztx*Dy_DzVx
                                                   +zty*Dy_DzVy);

                hTxy_rhs = mu *(
                             zty*Dy_DzVx + ztx*Dy_DzVy
                            );
                hTxz_rhs = mu *(
                             ztz*Dy_DzVx + ztx*Dy_DzVz
                            );
                hTyz_rhs = mu *(
                             ztz*Dy_DzVy + zty*Dy_DzVz
                          );

                // make corr to Hooke's equatoin
                hTxx[iptr] += (coef_B - 1.0) * hTxx_rhs;
                hTyy[iptr] += (coef_B - 1.0) * hTyy_rhs;
                hTzz[iptr] += (coef_B - 1.0) * hTzz_rhs;
                hTxz[iptr] += (coef_B - 1.0) * hTxz_rhs;
                hTyz[iptr] += (coef_B - 1.0) * hTyz_rhs;
                hTxy[iptr] += (coef_B - 1.0) * hTxy_rhs;

                // aux var
                //   a1 = alpha + d / beta, dealt in abs_set_cfspml
                pml_hTxx[iptr_a] += coef_D * hTxx_rhs;
                pml_hTyy[iptr_a] += coef_D * hTyy_rhs;
                pml_hTzz[iptr_a] += coef_D * hTzz_rhs;
                pml_hTxz[iptr_a] += coef_D * hTxz_rhs;
                pml_hTyz[iptr_a] += coef_D * hTyz_rhs;
                pml_hTxy[iptr_a] += coef_D * hTxy_rhs;
              }

              // incr index
              iptr   += 1;
              iptr_a += 1;
            } // i
          } // j
        } // k
      }
      else // z direction
      {
        iptr_a = 0;
        for (k=abs_nk1; k<=abs_nk2; k++)
        {
          iptr_k = k * siz_slice;

          // pml coefs
          int abs_k = k - abs_nk1;
          coef_D = ptr_coef_D[abs_k];
          coef_A = ptr_coef_A[abs_k];
          coef_B = ptr_coef_B[abs_k];
          coef_B_minus_1 = coef_B - 1.0;

          for (j=abs_nj1; j<=abs_nj2; j++)
          {
            iptr_j = iptr_k + j * siz_line;
            iptr = iptr_j + abs_ni1;
            for (i=abs_ni1; i<=abs_ni2; i++)
            {
              // metric
              ztx = zt_x[iptr];
              zty = zt_y[iptr];
              ztz = zt_z[iptr];

              // medium
              lam = lam3d[iptr];
              mu  =  mu3d[iptr];
              slw = slw3d[iptr];
              lam2mu = lam + 2.0 * mu;

              // zt derivatives
              M_FD_SHIFT(DzVx , Vx , iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzVy , Vy , iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzVz , Vz , iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzTxx, Txx, iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzTyy, Tyy, iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzTzz, Tzz, iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzTxz, Txz, iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzTyz, Tyz, iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);
              M_FD_SHIFT(DzTxy, Txy, iptr, fdz_len, lfdz_shift, lfdz_coef, n_fd);

              // combine for corr and aux vars
               hVx_rhs = slw * ( ztx*DzTxx + zty*DzTxy + ztz*DzTxz );
               hVy_rhs = slw * ( ztx*DzTxy + zty*DzTyy + ztz*DzTyz );
               hVz_rhs = slw * ( ztx*DzTxz + zty*DzTyz + ztz*DzTzz );
              hTxx_rhs = lam2mu*ztx*DzVx + lam*zty*DzVy + lam*ztz*DzVz;
              hTyy_rhs = lam*ztx*DzVx + lam2mu*zty*DzVy + lam*ztz*DzVz;
              hTzz_rhs = lam*ztx*DzVx + lam*zty*DzVy + lam2mu*ztz*DzVz;
              hTxy_rhs = mu*( zty*DzVx + ztx*DzVy );
              hTxz_rhs = mu*( ztz*DzVx + ztx*DzVz );
              hTyz_rhs = mu*( ztz*DzVy + zty*DzVz );

              // 1: make corr to moment equation
              hVx[iptr] += coef_B_minus_1 * hVx_rhs - coef_B * pml_Vx[iptr_a];
              hVy[iptr] += coef_B_minus_1 * hVy_rhs - coef_B * pml_Vy[iptr_a];
              hVz[iptr] += coef_B_minus_1 * hVz_rhs - coef_B * pml_Vz[iptr_a];

              // make corr to Hooke's equatoin
              hTxx[iptr] += coef_B_minus_1 * hTxx_rhs - coef_B * pml_Txx[iptr_a];
              hTyy[iptr] += coef_B_minus_1 * hTyy_rhs - coef_B * pml_Tyy[iptr_a];
              hTzz[iptr] += coef_B_minus_1 * hTzz_rhs - coef_B * pml_Tzz[iptr_a];
              hTxz[iptr] += coef_B_minus_1 * hTxz_rhs - coef_B * pml_Txz[iptr_a];
              hTyz[iptr] += coef_B_minus_1 * hTyz_rhs - coef_B * pml_Tyz[iptr_a];
              hTxy[iptr] += coef_B_minus_1 * hTxy_rhs - coef_B * pml_Txy[iptr_a];
              
              // 2: aux var
              //   a1 = alpha + d / beta, dealt in abs_set_cfspml
              pml_hVx[iptr_a]  = coef_D * hVx_rhs  - coef_A * pml_Vx[iptr_a];
              pml_hVy[iptr_a]  = coef_D * hVy_rhs  - coef_A * pml_Vy[iptr_a];
              pml_hVz[iptr_a]  = coef_D * hVz_rhs  - coef_A * pml_Vz[iptr_a];
              pml_hTxx[iptr_a] = coef_D * hTxx_rhs - coef_A * pml_Txx[iptr_a];
              pml_hTyy[iptr_a] = coef_D * hTyy_rhs - coef_A * pml_Tyy[iptr_a];
              pml_hTzz[iptr_a] = coef_D * hTzz_rhs - coef_A * pml_Tzz[iptr_a];
              pml_hTxz[iptr_a] = coef_D * hTxz_rhs - coef_A * pml_Txz[iptr_a];
              pml_hTyz[iptr_a] = coef_D * hTyz_rhs - coef_A * pml_Tyz[iptr_a];
              pml_hTxy[iptr_a] = coef_D * hTxy_rhs - coef_A * pml_Txy[iptr_a];

              // incr index
              iptr   += 1;
              iptr_a += 1;
            } // i
          } // j
        } // k
      } // if which dim
    } // iside
  } // idim

  return;
}

/*******************************************************************************
 * ABL-EXP boundary
 ******************************************************************************/

/* 
// apply on wavefield, not on derivatives
int sv_eliso1st_curv_macdrp_apply_ablexp_pointcoef(float *restrict w_cur, 
    int number_of_vars, int *restrict vars_pos,
    // grid size
    int ni1, int ni2, int nj1, int nj2, int nk1, int nk2,
    int ni, int nj, int nk, int nx, int ny, int nz,
    // ablexp info
    int *restrict abs_indx, float *restrict abs_damp
    )
{
  int ierr = 0;

  int iptr,iptr_abs, iptr_var, iptr_k, iptr_j;
  size_t siz_line, siz_slice;
  int i,j,k,ivar;

  siz_line  = nx;
  siz_slice = nx * ny;

  for (ivar=0; ivar<number_of_vars; ivar++)
  {
    iptr_var = vars_pos[ivar];
    iptr_abs = 0;

    for (k=abs_indx[4]; k<=abs_indx[5]; k++)
    {
      iptr_k = iptr_var + k * siz_slice;
      for (j=abs_indx[2]; j<=abs_indx[3]; j++)
      {
        iptr_j = j * siz_line + iptr_k;
        for (i=abs_indx[0]; i<=abs_indx[2]; i++)
        {
          iptr = i + iptr_j;

          w_cur[iptr] *= abs_damp[iptr_abs];

          // next
          iptr_abs += 1;
        }
      }
    }
  }

  return ierr;
}

int sv_eliso1st_curv_macdrp_apply_ablexp(float *restrict w_cur, 
    int number_of_vars, int *restrict vars_pos,
    // grid size
    int nx, int ny, int nz,
    // ablexp info
    int *restrict abs_indx, float *restrict abs_damp
    )
{
  int ierr = 0;

  int iptr,iptr_abs, iptr_var, iptr_k, iptr_j;
  size_t siz_line, siz_slice;
  int i,j,k,ivar;
  float *restrict Dx, Dy, Dz;
  float dampx, dampy, dampz, dampmin;

  siz_line  = nx;
  siz_slice = nx * ny;

  Dx = abs_damp;
  Dy = Dx + nx;
  Dz = Dy + ny; 

  for (ivar=0; ivar<number_of_vars; ivar++)
  {
    iptr_var = vars_pos[ivar];

    for (k=abs_indx[4]; k<=abs_indx[5]; k++)
    {
      iptr_k = iptr_var + k * siz_slice;
      dampz = Dz[k];

      for (j=abs_indx[2]; j<=abs_indx[3]; j++)
      {
        iptr_j = j * siz_line + iptr_k;
        dampy = Dy[j];
        dampmin = (dampy < dampz) ? dampy : dampz;

        for (i=abs_indx[0]; i<=abs_indx[2]; i++)
        {
          iptr = i + iptr_j;
          dampx = Dx[i];
          dampmin = (dampx < dampy) ? dampx : dampy;

          w_cur[iptr] *= dampmin;

        }
      }
    }
  }

  return ierr;
}
*/

/*******************************************************************************
 * free surface coef
 ******************************************************************************/

int
sv_curv_col_el_iso_dvh2dvz(gd_t    *gd,
                                 gdinfo_t    *gdinfo,
                                 gdcurv_metric_t *metric,
                                 md_t       *md,
                                 bdryfree_t      *bdryfree,
                                 const int verbose)
{
  int ierr = 0;

  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  size_t siz_line   = gdinfo->siz_line;
  size_t siz_slice  = gdinfo->siz_slice;
  size_t siz_volume = gdinfo->siz_volume;

  // point to each var
  float *restrict xi_x = metric->xi_x;
  float *restrict xi_y = metric->xi_y;
  float *restrict xi_z = metric->xi_z;
  float *restrict et_x = metric->eta_x;
  float *restrict et_y = metric->eta_y;
  float *restrict et_z = metric->eta_z;
  float *restrict zt_x = metric->zeta_x;
  float *restrict zt_y = metric->zeta_y;
  float *restrict zt_z = metric->zeta_z;
  float *restrict y3d  = gd->y3d;
  float *restrict z3d  = gd->z3d;

  float *restrict lam3d = md->lambda;
  float *restrict  mu3d = md->mu;

  float *matVx2Vz = bdryfree->matVx2Vz2;
  float *matVy2Vz = bdryfree->matVy2Vz2;
  float *matV2Vz  = bdryfree->matV2Vz2;
  
  float A[3][3], B[3][3], C[3][3], D[3][3];
  float AB[3][3], AC[3][3], AD[3][3];

  float xi_c, xi_f, xi_r, et_c, et_f, et_r, zt_c, zt_f, zt_r ;
  float r ,c ;
  float lam2mu, lam, mu;
 
  int k = nk2;

  for (size_t j = nj1; j <= nj2; j++)
  {
    for (size_t i = ni1; i <= ni2; i++)
    {
      size_t iptr = i + j * siz_line + k * siz_slice;

      et_f = xi_x[iptr];
      et_c = xi_y[iptr];
      et_r = xi_z[iptr];
      xi_f = et_x[iptr];
      xi_c = et_y[iptr];
      xi_r = et_z[iptr];
      zt_f = zt_x[iptr];
      zt_c = zt_y[iptr];
      zt_r = zt_z[iptr];

      c = y3d[iptr];
      r = z3d[iptr];


      lam    = lam3d[iptr];
      mu     =  mu3d[iptr];
      lam2mu = lam + 2.0f * mu;

      // first dim: irow; sec dim: jcol, as Fortran code
      A[0][0] =  mu*zt_r*zt_r + lam2mu*zt_c*zt_c/r/r + mu*zt_f*zt_f/r/r*recip_sin(c)*recip_sin(c);
      A[0][1] = (lam+mu)*zt_c*zt_f/r/r*recip_sin(c);
      A[0][2] = (lam+mu)*zt_c*zt_r/r;
      A[1][0] = A[0][1];
      A[1][1] = mu*zt_r*zt_r + mu*zt_c*zt_c/r/r + lam2mu*zt_f*zt_f/r/r*recip_sin(c)*recip_sin(c);
      A[1][2] = (lam+mu)*zt_f*zt_r/r*recip_sin(c);
      A[2][0] = A[0][2];
      A[2][1] = A[1][2];
      A[2][2] = lam2mu*zt_r*zt_r + mu*zt_c*zt_c/r/r + mu*zt_f*zt_f/r/r*recip_sin(c)*recip_sin(c);
      fdlib_math_invert3x3(A);

      B[0][0] =  mu*zt_r*xi_r + lam2mu*zt_c*xi_c/r/r + mu*zt_f*xi_f/r/r*recip_sin(c)*recip_sin(c);
      B[0][1] =  lam*zt_c*xi_f/r/r*recip_sin(c) + mu*zt_f*xi_c/r/r*recip_sin(c);
      B[0][2] =  mu*xi_c*zt_r/r + lam*xi_r*zt_c/r;
      B[1][0] =  lam*zt_f*xi_c/r/r*recip_sin(c) + mu*zt_c*xi_f/r/r*recip_sin(c);
      B[1][1] =  mu*zt_r*xi_r + mu*zt_c*xi_c/r/r + lam2mu*zt_f*xi_f/r/r*recip_sin(c)*recip_sin(c);
      B[1][2] =  mu*zt_r*xi_f/r*recip_sin(c) + lam*zt_f*xi_r/r*recip_sin(c);
      B[2][0] =  mu*xi_r*zt_c/r + lam*xi_c*zt_r/r;
      B[2][1] =  mu*zt_f*xi_r/r*recip_sin(c) + lam*zt_r*xi_f/r*recip_sin(c);
      B[2][2] =  lam2mu*zt_r*xi_r + mu*zt_c*xi_c/r/r + mu*zt_f*xi_f/r/r*recip_sin(c)*recip_sin(c);

      C[0][0] =  mu*zt_r*et_r + lam2mu*zt_c*et_c/r/r + mu*zt_f*et_f/r/r*recip_sin(c)*recip_sin(c);
      C[0][1] =  lam*zt_c*et_f/r/r*recip_sin(c) + mu*zt_f*et_c/r/r*recip_sin(c);
      C[0][2] =  mu*et_c*zt_r/r + lam*et_r*zt_c/r;
      C[1][0] =  lam*zt_f*et_c/r/r*recip_sin(c) + mu*zt_c*et_f/r/r*recip_sin(c);
      C[1][1] =  mu*zt_r*et_r + mu*zt_c*et_c/r/r + lam2mu*zt_f*et_f/r/r*recip_sin(c)*recip_sin(c);
      C[1][2] =  mu*zt_r*et_f/r*recip_sin(c) + lam*zt_f*et_r/r*recip_sin(c);
      C[2][0] =  mu*et_r*zt_c/r + lam*et_c*zt_r/r;
      C[2][1] =  mu*zt_f*et_r/r*recip_sin(c) + lam*zt_r*et_f/r*recip_sin(c);
      C[2][2] =  lam2mu*zt_r*et_r + mu*zt_c*et_c/r/r + mu*zt_f*et_f/r/r*recip_sin(c)*recip_sin(c);

      D[0][0] =  mu*zt_r/r - lam*zt_c*cos(c)*recip_sin(c)/r/r;
      D[0][1] =  mu*zt_f*cos(c)*recip_sin(c)*recip_sin(c)/r/r;
      D[0][2] = -2*(lam+mu)*zt_c/r/r;
      D[1][0] = -lam2mu*zt_f*cos(c)*recip_sin(c)*recip_sin(c)/r/r;
      D[1][1] =  mu*zt_r/r + mu*zt_c*cos(c)*recip_sin(c)/r/r;
      D[1][2] = -2*(lam+mu)*zt_f/r/r*recip_sin(c);
      D[2][0] =  mu*zt_c/r/r - lam*zt_r*cos(c)*recip_sin(c)/r;
      D[2][1] =  mu*zt_f/r/r*recip_sin(c);
      D[2][2] = -2*lam*zt_r/r;

      for(int ii=0; ii<3; ii++){
       for(int jj=0; jj<3; jj++){
        B[ii][jj] *= -1;
        C[ii][jj] *= -1;
       }
      }


      fdlib_math_matmul3x3(A, B, AB);
      fdlib_math_matmul3x3(A, C, AC);
      fdlib_math_matmul3x3(A, D, AD);

      size_t ij = (j * siz_line + i) * 9;

      // save into mat
      for(int irow = 0; irow < 3; irow++)
        for(int jcol = 0; jcol < 3; jcol++){
          matVx2Vz[ij + irow*3 + jcol] = AB[irow][jcol];
          matVy2Vz[ij + irow*3 + jcol] = AC[irow][jcol];
          matV2Vz[ij + irow*3 + jcol]  = AD[irow][jcol];
        }
    }
  }

  return ierr;
}

/*******************************************************************************
 * add source terms
 ******************************************************************************/

int
sv_curv_col_el_iso_rhs_src(
    float *restrict hVx , float *restrict hVy , float *restrict hVz ,
    float *restrict hTxx, float *restrict hTyy, float *restrict hTzz,
    float *restrict hTxz, float *restrict hTyz, float *restrict hTxy,
    float *restrict jac3d, float *restrict slw3d,float *restrict z3d,float dxyz,
    src_t *src, // short nation for reference member
    const int myid, const int verbose)
{
  int ierr = 0;

  // local var
  int si,sj,sk, iptr;

  // for easy coding and efficiency
  int max_ext = src->max_ext;

  // get fi / mij
  float fx, fy, fz;
  float Mxx,Myy,Mzz,Mxz,Myz,Mxy;

  int it     = src->it;
  int istage = src->istage;

  // add src; is is a commont iterater var
  for (int is=0; is < src->total_number; is++)
  {
    int   it_start = src->it_begin[is];
    int   it_end   = src->it_end  [is];

    if (it >= it_start && it <= it_end)
    {
      int   *ptr_ext_indx = src->ext_indx + is * max_ext;
      float *ptr_ext_coef = src->ext_coef + is * max_ext;
      int it_to_it_start = it - it_start;
      int iptr_cur_stage =   is * src->max_nt * src->max_stage // skip other src
                           + it_to_it_start * src->max_stage // skip other time step
                           + istage;
      if (src->force_actived == 1) {
        fx  = src->Fx [iptr_cur_stage];
        fy  = src->Fy [iptr_cur_stage];
        fz  = src->Fz [iptr_cur_stage];
      }
      if (src->moment_actived == 1) {
        Mxx = src->Mxx[iptr_cur_stage];
        Myy = src->Myy[iptr_cur_stage];
        Mzz = src->Mzz[iptr_cur_stage];
        Mxz = src->Mxz[iptr_cur_stage];
        Myz = src->Myz[iptr_cur_stage];
        Mxy = src->Mxy[iptr_cur_stage];
      }
      
      // for extend points
      for (int i_ext=0; i_ext < src->ext_num[is]; i_ext++)
      {
        int   iptr = ptr_ext_indx[i_ext];
        float coef = ptr_ext_coef[i_ext];

        if (src->force_actived == 1) {
          float V = coef * slw3d[iptr] / jac3d[iptr] /z3d[iptr] /z3d[iptr]; 
          hVx[iptr] += fx * V;
          hVy[iptr] += fy * V;
          hVz[iptr] += fz * V;
        }

        if (src->moment_actived == 1) {
          float rjac = coef / jac3d[iptr] /z3d[iptr] /z3d[iptr];
          hTxx[iptr] -= Mxx * rjac;
          hTyy[iptr] -= Myy * rjac;
          hTzz[iptr] -= Mzz * rjac;
          hTxz[iptr] -= Mxz * rjac;
          hTyz[iptr] -= Myz * rjac;
          hTxy[iptr] -= Mxy * rjac;
        }
      } // i_ext

    } // it
  } // is

  return ierr;
}


int
sv_curv_col_el_iso_rhs_src_car(
    float *restrict hVx , float *restrict hVy , float *restrict hVz ,
    float *restrict hTxx, float *restrict hTyy, float *restrict hTzz,
    float *restrict hTxz, float *restrict hTyz, float *restrict hTxy,
    float *restrict slw3d,float dxyz,
    src_t *src, // short nation for reference member
    const int myid, const int verbose)
{
  int ierr = 0;

  // local var
  int si,sj,sk, iptr;

  // for easy coding and efficiency
  int max_ext = src->max_ext;

  // get fi / mij
  float fx, fy, fz;
  float Mxx,Myy,Mzz,Mxz,Myz,Mxy;

  int it     = src->it;
  int istage = src->istage;

  // add src; is is a commont iterater var
  for (int is=0; is < src->total_number; is++)
  {
    int   it_start = src->it_begin[is];
    int   it_end   = src->it_end  [is];

    if (it >= it_start && it <= it_end)
    {
      int   *ptr_ext_indx = src->ext_indx + is * max_ext;
      float *ptr_ext_coef = src->ext_coef + is * max_ext;
      int it_to_it_start = it - it_start;
      int iptr_cur_stage =   is * src->max_nt * src->max_stage // skip other src
                           + it_to_it_start * src->max_stage // skip other time step
                           + istage;
      if (src->force_actived == 1) {
        fx  = src->Fx [iptr_cur_stage];
        fy  = src->Fy [iptr_cur_stage];
        fz  = src->Fz [iptr_cur_stage];
      }
      if (src->moment_actived == 1) {
        Mxx = src->Mxx[iptr_cur_stage];
        Myy = src->Myy[iptr_cur_stage];
        Mzz = src->Mzz[iptr_cur_stage];
        Mxz = src->Mxz[iptr_cur_stage];
        Myz = src->Myz[iptr_cur_stage];
        Mxy = src->Mxy[iptr_cur_stage];
      }
      
      // for extend points
      for (int i_ext=0; i_ext < src->ext_num[is]; i_ext++)
      {
        int   iptr = ptr_ext_indx[i_ext];
        float coef = ptr_ext_coef[i_ext];

        if (src->force_actived == 1) {
          float V = coef * slw3d[iptr] / dxyz /dxyz /dxyz;
          hVx[iptr] += fx * V;
          hVy[iptr] += fy * V;
          hVz[iptr] += fz * V;
        }

        if (src->moment_actived == 1) {
          float rjac = coef / dxyz /dxyz /dxyz;
          hTxx[iptr] -= Mxx * rjac;
          hTyy[iptr] -= Myy * rjac;
          hTzz[iptr] -= Mzz * rjac;
          hTxz[iptr] -= Mxz * rjac;
          hTyz[iptr] -= Myz * rjac;
          hTxy[iptr] -= Mxy * rjac;
        }
      } // i_ext

    } // it
  } // is

  return ierr;
}

