/*
********************************************************************************
* Curve grid metric calculation using MacCormack scheme                        *
********************************************************************************
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "netcdf.h"

#include "fdlib_mem.h"
#include "fdlib_math.h"
#include "fd_t.h"
#include "gd_t.h"
#include "isPointInHexahedron.h"

// used in read grid file
#define M_gd_INDEX( i, j, k, ni, nj ) ( ( i ) + ( j ) * ( ni ) + ( k ) * ( ni ) * ( nj ) )

void 
gd_curv_init(gdinfo_t *gdinfo, gd_t *gdcurv, int a)
{
  /*
   * 0-2: x3d, y3d, z3d
   */

  gdcurv->type = GD_TYPE_CURV;

  gdcurv->nx   = gdinfo->nx;
  gdcurv->ny   = gdinfo->ny;
  gdcurv->nz   = gdinfo->nz;
  gdcurv->ncmp = CONST_NDIM;
  gdcurv->size_of_interp = gdinfo->size_of_interp;

  gdcurv->siz_line   = gdcurv->nx;
  gdcurv->siz_slice   = gdcurv->nx * gdcurv->ny;
  gdcurv->siz_volume = gdcurv->nx * gdcurv->ny * gdcurv->nz;

  gdcurv->npoint_ghosts = gdinfo->npoint_ghosts;
  
  // vars
  gdcurv->v4d = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume * gdcurv->ncmp, -1, "gd_curv_init");
  if (gdcurv->v4d == NULL) {
      fprintf(stderr,"Error: failed to alloc coord vars\n");
      fflush(stderr);
  }
  
  // position of each v4d
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(gdcurv->ncmp ,
                                                         0,
                                                         "gd_curv_init");
  
  // name of each v4d
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(gdcurv->ncmp ,
                                                       CONST_MAX_STRLEN,
                                                       "gd_curv_init");
  
  // set value
  int icmp = 0;
  cmp_pos[icmp] = icmp * gdcurv->siz_volume;
  if (a == 0){
  sprintf(cmp_name[icmp],"%s","x");
  }
  if (a == 1){
  sprintf(cmp_name[icmp],"%s","x_n");
  }
  if (a == 2){
  sprintf(cmp_name[icmp],"%s","xx");
  }
  gdcurv->x3d = gdcurv->v4d + cmp_pos[icmp];

  icmp += 1;
  cmp_pos[icmp] = icmp * gdcurv->siz_volume;
  if (a == 0){
  sprintf(cmp_name[icmp],"%s","y");
  }
  if (a == 1){
  sprintf(cmp_name[icmp],"%s","y_n");
  }
  if (a == 2){
  sprintf(cmp_name[icmp],"%s","yy");
  }
  gdcurv->y3d = gdcurv->v4d + cmp_pos[icmp];

  icmp += 1;
  cmp_pos[icmp] = icmp * gdcurv->siz_volume;
  if (a == 0){
  sprintf(cmp_name[icmp],"%s","z");
  }
  if (a == 1){
  sprintf(cmp_name[icmp],"%s","z_n");
  }
  if (a == 2){
  sprintf(cmp_name[icmp],"%s","zz");
  }
  gdcurv->z3d = gdcurv->v4d + cmp_pos[icmp];
  

  // set pointer
  gdcurv->cmp_pos  = cmp_pos;
  gdcurv->cmp_name = cmp_name;
  
  // alloc AABB vars
  gdcurv->cell_xmin = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume, 0.0, "gd_curv_init");
  gdcurv->cell_xmax = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume, 0.0, "gd_curv_init");
  gdcurv->cell_ymin = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume, 0.0, "gd_curv_init");
  gdcurv->cell_ymax = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume, 0.0, "gd_curv_init");
  gdcurv->cell_zmin = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume, 0.0, "gd_curv_init");
  gdcurv->cell_zmax = (float *) fdlib_mem_calloc_1d_float(
                  gdcurv->siz_volume, 0.0, "gd_curv_init");
  if (gdcurv->cell_zmax == NULL) {
      fprintf(stderr,"Error: failed to alloc coord AABB vars\n");
      fflush(stderr);
  }

  return;
}


void 
gd_curv_metric_init(gdinfo_t        *gdinfo,
                    gdcurv_metric_t *metric)
{
  const int num_grid_vars = 10;
  /*
   * 0: jac
   * 1-3: xi_x, xi_y, xi_z
   * 4-6: eta_x, eta_y, eta_z
   * 7-9: zeta_x, zeta_y, zeta_z
   */

  metric->nx   = gdinfo->nx;
  metric->ny   = gdinfo->ny;
  metric->nz   = gdinfo->nz;
  metric->ncmp = num_grid_vars;

  metric->siz_line   = metric->nx;
  metric->siz_slice  = metric->nx * metric->ny;
  metric->siz_volume = metric->nx * metric->ny * metric->nz;
  
  // vars
  metric->v4d = (float *) fdlib_mem_calloc_1d_float(
                  metric->siz_volume * metric->ncmp, 0.0, "gd_curv_init_g4d");
  if (metric->v4d == NULL) {
      fprintf(stderr,"Error: failed to alloc metric vars\n");
      fflush(stderr);
  }
  
  // position of each v4d
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(metric->ncmp,
                                                         0, 
                                                         "gd_curv_metric_init");
  
  // name of each v4d
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(metric->ncmp,
                                                       CONST_MAX_STRLEN,
                                                       "gd_curv_metric_init");
  
  // set value
  for (int icmp=0; icmp < metric->ncmp; icmp++)
  {
    cmp_pos[icmp] = icmp * metric->siz_volume;
  }

  int icmp = 0;
  sprintf(cmp_name[icmp],"%s","jac");
  metric->jac = metric->v4d + cmp_pos[icmp];

  icmp += 1;
  sprintf(cmp_name[icmp],"%s","xi_x");
  metric->xi_x = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","xi_y");
  metric->xi_y = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","xi_z");
  metric->xi_z = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","eta_x");
  metric->eta_x = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","eta_y");
  metric->eta_y = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","eta_z");
  metric->eta_z = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","zeta_x");
  metric->zeta_x = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","zeta_y");
  metric->zeta_y = metric->v4d + cmp_pos[icmp];
  
  icmp += 1;
  sprintf(cmp_name[icmp],"%s","zeta_z");
  metric->zeta_z = metric->v4d + cmp_pos[icmp];
  
  // set pointer
  metric->cmp_pos  = cmp_pos;
  metric->cmp_name = cmp_name;
}

//
// need to change to use fdlib_math.c
//
void
gd_curv_metric_cal(gdinfo_t        *gdinfo,
                   gd_t        *gdcurv,
                   gd_t        *gdcurv_another,
                   gdcurv_metric_t *metric,
                   int fd_len, int *restrict fd_indx, float *restrict fd_coef, int a)
{
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  size_t siz_line   = gdinfo->siz_line;
  size_t siz_slice  = gdinfo->siz_slice;
  size_t siz_volume = gdinfo->siz_volume;
  float *restrict x3d, *restrict y3d;
  
  gdcurv->z_zeta = (float *) fdlib_mem_calloc_1d_float(gdcurv->siz_volume , 0.0, "z_zeta_init");
  // point to each var
  if (a==0){
    x3d = gdcurv->x3d;
    y3d = gdcurv->y3d;
  }
  if (a==1){
    x3d = gdcurv_another->x3d;
    y3d = gdcurv_another->y3d;
  }
  float *restrict z3d  = gdcurv->z3d;
  float *restrict z_zeta = gdcurv->z_zeta;
  float *restrict jac3d= metric->jac;
  float *restrict xi_x = metric->xi_x;
  float *restrict xi_y = metric->xi_y;
  float *restrict xi_z = metric->xi_z;
  float *restrict et_x = metric->eta_x;
  float *restrict et_y = metric->eta_y;
  float *restrict et_z = metric->eta_z;
  float *restrict zt_x = metric->zeta_x;
  float *restrict zt_y = metric->zeta_y;
  float *restrict zt_z = metric->zeta_z;

  float x_xi, x_et, x_zt;
  float y_xi, y_et, y_zt;
  float z_xi, z_et, z_zt;
  float jac;
  float vec1[3], vec2[3], vec3[3], vecg[3];
  int n_fd;

  // use local stack array for speedup
  float  lfd_coef [fd_len];
  int    lfdx_shift[fd_len];
  int    lfdy_shift[fd_len];
  int    lfdz_shift[fd_len];
  // put fd op into local array
  for (int k=0; k < fd_len; k++) {
    lfd_coef [k] = fd_coef[k];
    lfdx_shift[k] = fd_indx[k]            ;
    lfdy_shift[k] = fd_indx[k] * siz_line ;
    lfdz_shift[k] = fd_indx[k] * siz_slice;
  }

  for (size_t k = nk1; k <= nk2; k++){
    for (size_t j = nj1; j <= nj2; j++) {
      for (size_t i = ni1; i <= ni2; i++)
      {
        size_t iptr = i + j * siz_line + k * siz_slice;

        x_xi = 0.0; x_et = 0.0; x_zt = 0.0;
        y_xi = 0.0; y_et = 0.0; y_zt = 0.0;
        z_xi = 0.0; z_et = 0.0; z_zt = 0.0;

        M_FD_SHIFT(x_xi, x3d, iptr, fd_len, lfdx_shift, lfd_coef, n_fd);
        M_FD_SHIFT(y_xi, y3d, iptr, fd_len, lfdx_shift, lfd_coef, n_fd);
        M_FD_SHIFT(z_xi, z3d, iptr, fd_len, lfdx_shift, lfd_coef, n_fd);

        M_FD_SHIFT(x_et, x3d, iptr, fd_len, lfdy_shift, lfd_coef, n_fd);
        M_FD_SHIFT(y_et, y3d, iptr, fd_len, lfdy_shift, lfd_coef, n_fd);
        M_FD_SHIFT(z_et, z3d, iptr, fd_len, lfdy_shift, lfd_coef, n_fd);

        M_FD_SHIFT(x_zt, x3d, iptr, fd_len, lfdz_shift, lfd_coef, n_fd);
        M_FD_SHIFT(y_zt, y3d, iptr, fd_len, lfdz_shift, lfd_coef, n_fd);
        M_FD_SHIFT(z_zt, z3d, iptr, fd_len, lfdz_shift, lfd_coef, n_fd);

        vec1[0] = x_xi; vec1[1] = y_xi; vec1[2] = z_xi;
        vec2[0] = x_et; vec2[1] = y_et; vec2[2] = z_et;
        vec3[0] = x_zt; vec3[1] = y_zt; vec3[2] = z_zt;
        
        z_zeta[iptr] = z_zt;
        fdlib_math_cross_product(vec1, vec2, vecg);
        jac = fdlib_math_dot_product(vecg, vec3);
        jac3d[iptr]  = jac;

        if (jac == 0){
        fprintf(stdout,"i,j,k %d,%d,%d's jac_value equals %f\n",
                      i,j,k, jac);
        MPI_Abort(MPI_COMM_WORLD,-1);           
        }  

        fdlib_math_cross_product(vec2, vec3, vecg);
        xi_x[iptr] = vecg[0] / jac;
        xi_y[iptr] = vecg[1] / jac;
        xi_z[iptr] = vecg[2] / jac;

        fdlib_math_cross_product(vec3, vec1, vecg);
        et_x[iptr] = vecg[0] / jac;
        et_y[iptr] = vecg[1] / jac;
        et_z[iptr] = vecg[2] / jac;

        fdlib_math_cross_product(vec1, vec2, vecg);
        zt_x[iptr] = vecg[0] / jac;
        zt_y[iptr] = vecg[1] / jac;
        zt_z[iptr] = vecg[2] / jac;
      }
    }
  }
    
  // extend to ghosts. may replaced by mpi exchange
  // x1, mirror
  for (size_t k = 0; k < nz; k++){
    for (size_t j = 0; j < ny; j++) {
      for (size_t i = 0; i < ni1; i++)
      {
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = jac3d[iptr + (ni1-i)*2 -1 ];
         xi_x[iptr] =  xi_x[iptr + (ni1-i)*2 -1 ];
         xi_y[iptr] =  xi_y[iptr + (ni1-i)*2 -1 ];
         xi_z[iptr] =  xi_z[iptr + (ni1-i)*2 -1 ];
         et_x[iptr] =  et_x[iptr + (ni1-i)*2 -1 ];
         et_y[iptr] =  et_y[iptr + (ni1-i)*2 -1 ];
         et_z[iptr] =  et_z[iptr + (ni1-i)*2 -1 ];
         zt_x[iptr] =  zt_x[iptr + (ni1-i)*2 -1 ];
         zt_y[iptr] =  zt_y[iptr + (ni1-i)*2 -1 ];
         zt_z[iptr] =  zt_z[iptr + (ni1-i)*2 -1 ];
      }
    }
  }
  // x2, mirror
  for (size_t k = 0; k < nz; k++){
    for (size_t j = 0; j < ny; j++) {
      for (size_t i = ni2+1; i < nx; i++)
      {
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = jac3d[iptr - (i-ni2)*2 +1 ];
         xi_x[iptr] =  xi_x[iptr - (i-ni2)*2 +1 ];
         xi_y[iptr] =  xi_y[iptr - (i-ni2)*2 +1 ];
         xi_z[iptr] =  xi_z[iptr - (i-ni2)*2 +1 ];
         et_x[iptr] =  et_x[iptr - (i-ni2)*2 +1 ];
         et_y[iptr] =  et_y[iptr - (i-ni2)*2 +1 ];
         et_z[iptr] =  et_z[iptr - (i-ni2)*2 +1 ];
         zt_x[iptr] =  zt_x[iptr - (i-ni2)*2 +1 ];
         zt_y[iptr] =  zt_y[iptr - (i-ni2)*2 +1 ];
         zt_z[iptr] =  zt_z[iptr - (i-ni2)*2 +1 ];
      }
    }
  }
  // y1, mirror
  for (size_t k = 0; k < nz; k++){
    for (size_t j = 0; j < nj1; j++) {
      for (size_t i = 0; i < nx; i++) {
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = jac3d[iptr + ((nj1-j)*2 -1) * siz_line ];
         xi_x[iptr] =  xi_x[iptr + ((nj1-j)*2 -1) * siz_line ];
         xi_y[iptr] =  xi_y[iptr + ((nj1-j)*2 -1) * siz_line ];
         xi_z[iptr] =  xi_z[iptr + ((nj1-j)*2 -1) * siz_line ];
         et_x[iptr] =  et_x[iptr + ((nj1-j)*2 -1) * siz_line ];
         et_y[iptr] =  et_y[iptr + ((nj1-j)*2 -1) * siz_line ];
         et_z[iptr] =  et_z[iptr + ((nj1-j)*2 -1) * siz_line ];
         zt_x[iptr] =  zt_x[iptr + ((nj1-j)*2 -1) * siz_line ];
         zt_y[iptr] =  zt_y[iptr + ((nj1-j)*2 -1) * siz_line ];
         zt_z[iptr] =  zt_z[iptr + ((nj1-j)*2 -1) * siz_line ];
      }
    }
  }
  // y2, mirror
  for (size_t k = 0; k < nz; k++){
    for (size_t j = nj2+1; j < ny; j++) {
      for (size_t i = 0; i < nx; i++) {
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = jac3d[iptr - ((j-nj2)*2 -1) * siz_line ];
         xi_x[iptr] =  xi_x[iptr - ((j-nj2)*2 -1) * siz_line ];
         xi_y[iptr] =  xi_y[iptr - ((j-nj2)*2 -1) * siz_line ];
         xi_z[iptr] =  xi_z[iptr - ((j-nj2)*2 -1) * siz_line ];
         et_x[iptr] =  et_x[iptr - ((j-nj2)*2 -1) * siz_line ];
         et_y[iptr] =  et_y[iptr - ((j-nj2)*2 -1) * siz_line ];
         et_z[iptr] =  et_z[iptr - ((j-nj2)*2 -1) * siz_line ];
         zt_x[iptr] =  zt_x[iptr - ((j-nj2)*2 -1) * siz_line ];
         zt_y[iptr] =  zt_y[iptr - ((j-nj2)*2 -1) * siz_line ];
         zt_z[iptr] =  zt_z[iptr - ((j-nj2)*2 -1) * siz_line ];
      }
    }
  }
  // z1, mirror
  for (size_t k = 0; k < nk1; k++) {
    for (size_t j = 0; j < ny; j++){
      for (size_t i = 0; i < nx; i++) {
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = jac3d[iptr + ((nk1-k)*2 -1) * siz_slice ];
         xi_x[iptr] =  xi_x[iptr + ((nk1-k)*2 -1) * siz_slice ];
         xi_y[iptr] =  xi_y[iptr + ((nk1-k)*2 -1) * siz_slice ];
         xi_z[iptr] =  xi_z[iptr + ((nk1-k)*2 -1) * siz_slice ];
         et_x[iptr] =  et_x[iptr + ((nk1-k)*2 -1) * siz_slice ];
         et_y[iptr] =  et_y[iptr + ((nk1-k)*2 -1) * siz_slice ];
         et_z[iptr] =  et_z[iptr + ((nk1-k)*2 -1) * siz_slice ];
         zt_x[iptr] =  zt_x[iptr + ((nk1-k)*2 -1) * siz_slice ];
         zt_y[iptr] =  zt_y[iptr + ((nk1-k)*2 -1) * siz_slice ];
         zt_z[iptr] =  zt_z[iptr + ((nk1-k)*2 -1) * siz_slice ];
      }
    }
  }
  // z2, mirror
  for (size_t k = nk2+1; k < nz; k++) {
    for (size_t j = 0; j < ny; j++){
      for (size_t i = 0; i < nx; i++) {
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = jac3d[iptr - ((k-nk2)*2 -1) * siz_slice ];
         xi_x[iptr] =  xi_x[iptr - ((k-nk2)*2 -1) * siz_slice ];
         xi_y[iptr] =  xi_y[iptr - ((k-nk2)*2 -1) * siz_slice ];
         xi_z[iptr] =  xi_z[iptr - ((k-nk2)*2 -1) * siz_slice ];
         et_x[iptr] =  et_x[iptr - ((k-nk2)*2 -1) * siz_slice ];
         et_y[iptr] =  et_y[iptr - ((k-nk2)*2 -1) * siz_slice ];
         et_z[iptr] =  et_z[iptr - ((k-nk2)*2 -1) * siz_slice ];
         zt_x[iptr] =  zt_x[iptr - ((k-nk2)*2 -1) * siz_slice ];
         zt_y[iptr] =  zt_y[iptr - ((k-nk2)*2 -1) * siz_slice ];
         zt_z[iptr] =  zt_z[iptr - ((k-nk2)*2 -1) * siz_slice ];
      }
    }
  }
}

//
// exchange metics
//
void
gd_curv_metric_exchange(gdinfo_t        *gdinfo,
                        gdcurv_metric_t *metric,
                        int             *neighid,
                        MPI_Comm        topocomm)
{
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;

  size_t siz_line   = gdinfo->siz_line;
  size_t siz_slice  = gdinfo->siz_slice;
  size_t siz_volume = gdinfo->siz_volume;
  float *restrict g3d = metric->v4d;

  // extend to ghosts, using mpi exchange
  // NOTE in different myid, nx(or ny) may not equal
  // so send type DTypeXL not equal recv type DTypeXL
  int s_iptr;
  int r_iptr;

  MPI_Status status;
  MPI_Datatype DTypeXL, DTypeYL;

  MPI_Type_vector(ny*nz,
                  3,
                  nx,
                  MPI_FLOAT,
                  &DTypeXL); 
  MPI_Type_vector(nz,
                  3*nx,
                  nx*ny,
                  MPI_FLOAT,
                  &DTypeYL);
  MPI_Type_commit(&DTypeXL);
  MPI_Type_commit(&DTypeYL);
  for(int i=0; i<metric->ncmp; i++)
  {
    // to X1
    s_iptr = ni1 + i * siz_volume;        //sendbuff point (ni1,ny1,nz1)
    r_iptr = (ni2+1) + i * siz_volume;    //recvbuff point (ni2+1,ny1,nz1)
    MPI_Sendrecv(&g3d[s_iptr],1,DTypeXL,neighid[0],110,
                 &g3d[r_iptr],1,DTypeXL,neighid[1],110,
                 topocomm,&status);//sendbuf, sendcount, sendtype, dest, sendtag
    // to X2
    s_iptr = (ni2-3+1) + i * siz_volume;    //sendbuff point (ni2-3+1,ny1,nz1)
    r_iptr = (ni1-3) + i * siz_volume;      //recvbuff point (ni1-3,ny1,nz1)
    MPI_Sendrecv(&g3d[s_iptr],1,DTypeXL,neighid[1],120,
                 &g3d[r_iptr],1,DTypeXL,neighid[0],120,
                 topocomm,&status);
    // to Y1
    s_iptr = nj1 * siz_line + i * siz_volume;        //sendbuff point (nx1,nj1,nz1)
    r_iptr = (nj2+1) * siz_line + i * siz_volume;    //recvbuff point (nx1,nj2+1,nz1)
    MPI_Sendrecv(&g3d[s_iptr],1,DTypeYL,neighid[2],210,
                 &g3d[r_iptr],1,DTypeYL,neighid[3],210,
                 topocomm,&status);
    // to Y2
    s_iptr = (nj2-3+1) * siz_line + i * siz_volume;   //sendbuff point (nx1,nj2-3+1,nz1)
    r_iptr = (nj1-3) * siz_line + i * siz_volume;     //recvbuff point (nx1,nj1-3,nz1)
    MPI_Sendrecv(&g3d[s_iptr],1,DTypeYL,neighid[3],220,
                 &g3d[r_iptr],1,DTypeYL,neighid[2],220,
                 topocomm,&status);
  }
/*
  // for test.  check send_recv whether success
  for (size_t i = ni1; i < ni1+3; i++)
  {
    int j = nj1;
    int k = nk1;
    size_t iptr = i + j * siz_line + k * siz_slice;
    if(myid2[0]==1 && myid2[1]==0 ) fprintf(stdout,"aaa  %f %f %f aaa\n",jac3d[iptr],xi_x[iptr], zt_y[iptr]);
  }
  for (size_t i = ni2+1; i <= ni2+3; i++)
  {
    int j = nj1;
    int k = nk1;
    size_t iptr = i + j * siz_line + k * siz_slice;
    if(myid2[0]==0 && myid2[1]==0) fprintf(stdout,"**a %f %f %f **a\n",jac3d[iptr],xi_x[iptr], zt_y[iptr]);
  }

  for (size_t i = ni2-2; i <= ni2; i++)
  {
    int j = nj1;
    int k = nk1;
    size_t iptr = i + j * siz_line + k * siz_slice;
    if(myid2[0]==0 && myid2[1]==1) fprintf(stdout,"bbb %f %f %f bbb\n",jac3d[iptr],xi_x[iptr], zt_y[iptr]);
  }
  for (size_t i = ni1-3; i < ni1; i++)
  {
    int j = nj1;
    int k = nk1;
    size_t iptr = i + j * siz_line + k * siz_slice;
    if(myid2[0]==1 && myid2[1]==1) fprintf(stdout,"**b %f %f %f **b\n",jac3d[iptr],xi_x[iptr], zt_y[iptr]);
  }

  for (size_t j = nj2-2; j <= nj2; j++)
  {
    int i = ni1+1;
    int k = nk1+1;
    size_t iptr = i + j * siz_line + k * siz_slice;
    if(myid2[0]==0 && myid2[1]==0) fprintf(stdout,"ccc %f %f %f ccc\n",jac3d[iptr],xi_x[iptr], zt_y[iptr]);
  }
  for (size_t j = nj1-3; j < nj1; j++)
  {
    int i = ni1+1;
    int k = nk1+1;
    size_t iptr = i + j * siz_line + k * siz_slice;
    if(myid2[0]==0 && myid2[1]==1) fprintf(stdout,"**c %f %f %f **c\n",jac3d[iptr],xi_x[iptr], zt_y[iptr]);
  }
*/

  // for test
  /*
  for (size_t k = 0; k < nz; k++){
    for (size_t j = 0; j < ny; j++) {
      for (size_t i = 0; i < nx; i++)
      {
        float dh=100.0;
        size_t iptr = i + j * siz_line + k * siz_slice;
        jac3d[iptr] = dh*dh*dh;
         xi_x[iptr] = 1.0/dh;
         xi_y[iptr] =  0.0;
         xi_z[iptr] =  0.0;
         et_x[iptr] =  0.0;
         et_y[iptr] = 1.0/dh;
         et_z[iptr] =  0.0;
         zt_x[iptr] =  0.0;
         zt_y[iptr] =  0.0;
         zt_z[iptr] = 1.0/dh;
      }
    }
  }
  */
}

/*
 * generate cartesian grid for curv struct
 */
void
gd_curv_gen_cart(
  gdinfo_t *gdinfo,
  gd_t *gdcurv,
  float dx, float x0_glob,
  float dy, float y0_glob,
  float dz, float z0_glob)
{
  float *x3d = gdcurv->x3d;
  float *y3d = gdcurv->y3d;
  float *z3d = gdcurv->z3d;

  float x0 = x0_glob + (gdinfo->ni1_to_glob_phys0 - gdinfo->fdx_nghosts) * dx;
  float y0 = y0_glob + (gdinfo->nj1_to_glob_phys0 - gdinfo->fdy_nghosts) * dy;
  float z0 = z0_glob + (gdinfo->nk1_to_glob_phys0 - gdinfo->fdz_nghosts) * dz;

  size_t iptr = 0;
  for (size_t k=0; k<gdcurv->nz; k++)
  {
    for (size_t j=0; j<gdcurv->ny; j++)
    {
      for (size_t i=0; i<gdcurv->nx; i++)
      {
        x3d[iptr] = x0 + i * dx;
        y3d[iptr] = y0 + j * dy;
        z3d[iptr] = z0 + k * dz;

        iptr++;
      }
    }
  }

  return;
}

/*
 * generate cartesian grid
 */

void 
gd_cart_init_set(gdinfo_t *gdinfo, gd_t *gdcart,
  float dx, float x0_glob,
  float dy, float y0_glob,
  float dz, float z0_glob)
{
  /*
   * 0-2: x3d, y3d, z3d
   */

  gdcart->type = GD_TYPE_CART;

  gdcart->nx   = gdinfo->nx;
  gdcart->ny   = gdinfo->ny;
  gdcart->nz   = gdinfo->nz;
  gdcart->ncmp = CONST_NDIM;

  gdcart->siz_line   = gdcart->nx;
  gdcart->siz_slice   = gdcart->nx * gdcart->ny;
  gdcart->siz_volume = gdcart->nx * gdcart->ny * gdcart->nz;
  
  // vars
  float *x1d = (float *) fdlib_mem_calloc_1d_float(
                  gdcart->nx, 0.0, "gd_cart_init");
  float *y1d = (float *) fdlib_mem_calloc_1d_float(
                  gdcart->ny, 0.0, "gd_cart_init");
  float *z1d = (float *) fdlib_mem_calloc_1d_float(
                  gdcart->nz, 0.0, "gd_cart_init");
  if (z1d == NULL) {
      fprintf(stderr,"Error: failed to alloc coord vars\n");
      fflush(stderr);
  }

  float x0 = x0_glob + (gdinfo->ni1_to_glob_phys0 - gdinfo->fdx_nghosts) * dx;
  float y0 = y0_glob + (gdinfo->nj1_to_glob_phys0 - gdinfo->fdy_nghosts) * dy;
  float z0 = z0_glob + (gdinfo->nk1_to_glob_phys0 - gdinfo->fdz_nghosts) * dz;

  for (size_t k=0; k< gdcart->nz; k++)
  {
        z1d[k] = z0 + k * dz;
  }
  for (size_t j=0; j< gdcart->ny; j++)
  {
        y1d[j] = y0 + j * dy;
  }
  for (size_t i=0; i< gdcart->nx; i++)
  {
        x1d[i] = x0 + i * dx;
  }

  gdcart->dx = dx;
  gdcart->dy = dy;
  gdcart->dz = dz;

  gdcart->xmin = x0;
  gdcart->ymin = y0;
  gdcart->zmin = z0;
  gdcart->xmax = x0 + (gdcart->nx-1) * dx;
  gdcart->ymax = y0 + (gdcart->ny-1) * dy;
  gdcart->zmax = z0 + (gdcart->nz-1) * dz;

  gdcart->x0_glob = x0_glob;
  gdcart->y0_glob = y0_glob;
  gdcart->z0_glob = z0_glob;

  gdcart->x1d = x1d;
  gdcart->y1d = y1d;
  gdcart->z1d = z1d;
  
  return;
}

//
// input/output
//
void
gd_curv_coord_export(
  gdinfo_t *gdinfo,
  gdinfo_t *gdinfo_n,
  gdinfo_t *gdinfo_car,
  gd_t *gdcurv,
  gd_t *gdcurv_n,
  gd_t *gdcurv_car,
  char *fname_coords,
  char *output_dir)
{
  int number_of_vars = gdcurv->ncmp;
  int  nx = gdcurv->nx;
  int  ny = gdcurv->ny;
  int  nz = gdcurv->nz;
  int  ni1 = gdinfo->ni1;
  int  nj1 = gdinfo->nj1;
  int  nk1 = gdinfo->nk1;
  int  ni  = gdinfo->ni;
  int  nj  = gdinfo->nj;
  int  nk  = gdinfo->nk;
  int  gni1 = gdinfo->ni1_to_glob_phys0;
  int  gnj1 = gdinfo->nj1_to_glob_phys0;
  int  gnk1 = gdinfo->nk1_to_glob_phys0;

  int  nxn = gdcurv_n->nx;
  int  nyn = gdcurv_n->ny;
  int  nzn = gdcurv_n->nz;
  int  ni1n = gdinfo_n->ni1;
  int  nj1n = gdinfo_n->nj1;
  int  nk1n = gdinfo_n->nk1;
  int  nin  = gdinfo_n->ni;
  int  njn  = gdinfo_n->nj;
  int  nkn  = gdinfo_n->nk;
  int  gni1n = gdinfo_n->ni1_to_glob_phys0;
  int  gnj1n = gdinfo_n->nj1_to_glob_phys0;
  int  gnk1n = gdinfo_n->nk1_to_glob_phys0;

  int  nxx = gdinfo_car->nx;
  int  nyy = gdinfo_car->ny;
  int  nzz = gdinfo_car->nz;
  int  nii1 = gdinfo_car->ni1;
  int  njj1 = gdinfo_car->nj1;
  int  nkk1 = gdinfo_car->nk1;
  int  nii  = gdinfo_car->ni;
  int  njj  = gdinfo_car->nj;
  int  nkk  = gdinfo_car->nk;
  int  gnii1 = gdinfo_car->ni1_to_glob_phys0;
  int  gnjj1 = gdinfo_car->nj1_to_glob_phys0;
  int  gnkk1 = gdinfo_car->nk1_to_glob_phys0;

  // construct file name
  char ou_file[CONST_MAX_STRLEN];
  sprintf(ou_file, "%s/coord_%s.nc", output_dir, fname_coords);
  
  // read in nc
  int ncid;
  int varid[gdcurv->ncmp*3];
  int dimid[CONST_NDIM*3];
  int a[3];
  int b[3];
  int c[3];

  int ierr = nc_create(ou_file, NC_CLOBBER | NC_64BIT_OFFSET, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"creat coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // define dimension
  ierr = nc_def_dim(ncid, "fi_yang", nxn, &dimid[8]);
  ierr = nc_def_dim(ncid, "theta_yang", nyn, &dimid[7]);
  ierr = nc_def_dim(ncid, "rho_yang", nzn, &dimid[6]);
  ierr = nc_def_dim(ncid, "nxx", nxx, &dimid[5]);
  ierr = nc_def_dim(ncid, "nyy", nyy, &dimid[4]);
  ierr = nc_def_dim(ncid, "nzz", nzz, &dimid[3]);
  ierr = nc_def_dim(ncid, "fi", nx, &dimid[2]);
  ierr = nc_def_dim(ncid, "theta", ny, &dimid[1]);
  ierr = nc_def_dim(ncid, "rho", nz, &dimid[0]);
  a[0] = dimid[0];
  a[1] = dimid[1];
  a[2] = dimid[2];
  b[0] = dimid[3];
  b[1] = dimid[4];
  b[2] = dimid[5];
  c[0] = dimid[6];
  c[1] = dimid[7];
  c[2] = dimid[8];

  // define vars
  for (int ivar=0; ivar<gdcurv->ncmp; ivar++) {
    ierr = nc_def_var(ncid, gdcurv->cmp_name[ivar],     NC_FLOAT, CONST_NDIM, a, &varid[ivar]);
    ierr = nc_def_var(ncid, gdcurv_car->cmp_name[ivar], NC_FLOAT, CONST_NDIM, b, &varid[ivar + CONST_NDIM  ]);
    ierr = nc_def_var(ncid, gdcurv_n->cmp_name[ivar],   NC_FLOAT, CONST_NDIM, c, &varid[ivar + CONST_NDIM*2]);
  }

  // attribute: index in output snapshot, index w ghost in thread
  int l_start[] = { ni1, nj1, nk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"local_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,l_start);

  int g_start[] = { gni1, gnj1, gnk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,g_start);

  int l_count[] = { ni, nj, nk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points",
                   NC_INT,CONST_NDIM,l_count);

  int car_count[] = { nii, njj ,nkk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points_car",
                   NC_INT,CONST_NDIM,car_count);

  int car_g_start[] = { gnii1, gnjj1, gnkk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"car_global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,car_g_start);    

  int yang_count[] = { nin, njn ,nkn };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points_yang",
                   NC_INT,CONST_NDIM,yang_count);

  int yang_g_start[] = { gni1n, gnj1n, gnk1n };
  nc_put_att_int(ncid,NC_GLOBAL,"yang_global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,yang_g_start);                                

  // end def
  ierr = nc_enddef(ncid);

  // add vars
  for (int ivar=0; ivar<gdcurv->ncmp; ivar++) {
    float *ptr = gdcurv->v4d + gdcurv->cmp_pos[ivar];
    ierr = nc_put_var_float(ncid, varid[ivar],ptr);

    float *ptr1 = gdcurv_car->v4d + gdcurv_car->cmp_pos[ivar];
    ierr = nc_put_var_float(ncid, varid[ivar + CONST_NDIM ],ptr1);

    float *ptr2 = gdcurv_n->v4d + gdcurv_n->cmp_pos[ivar];
    ierr = nc_put_var_float(ncid, varid[ivar + CONST_NDIM*2 ],ptr2);
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

void
gd_curv_coord_import(gd_t *gdcurv, char *fname_coords, char *import_dir)
{
  // construct file name
  char in_file[CONST_MAX_STRLEN];
  sprintf(in_file, "%s/coord_%s.nc", import_dir, fname_coords);
  
  // read in nc
  int ncid;
  int varid;

  int ierr = nc_open(in_file, NC_NOWRITE, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"open coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // read vars
  for (int ivar=0; ivar<gdcurv->ncmp; ivar++)
  {
    float *ptr = gdcurv->v4d + gdcurv->cmp_pos[ivar];

    ierr = nc_inq_varid(ncid, gdcurv->cmp_name[ivar], &varid);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }

    ierr = nc_get_var(ncid, varid, ptr);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

void
gd_cart_coord_export(
  gdinfo_t *gdinfo,
  gd_t *gdcart,
  char *fname_coords,
  char *output_dir)
{
  int  nx = gdcart->nx;
  int  ny = gdcart->ny;
  int  nz = gdcart->nz;
  int  ni1 = gdinfo->ni1;
  int  nj1 = gdinfo->nj1;
  int  nk1 = gdinfo->nk1;
  int  ni  = gdinfo->ni;
  int  nj  = gdinfo->nj;
  int  nk  = gdinfo->nk;
  int  gni1 = gdinfo->ni1_to_glob_phys0;
  int  gnj1 = gdinfo->nj1_to_glob_phys0;
  int  gnk1 = gdinfo->nk1_to_glob_phys0;

  // construct file name
  char ou_file[CONST_MAX_STRLEN];
  sprintf(ou_file, "%s/coord_%s.nc", output_dir, fname_coords);
  
  // read in nc
  int ncid;
  int varid[CONST_NDIM];
  int dimid[CONST_NDIM];

  int ierr = nc_create(ou_file, NC_CLOBBER | NC_64BIT_OFFSET, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"creat coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // define dimension
  ierr = nc_def_dim(ncid, "i", nx, &dimid[2]);
  ierr = nc_def_dim(ncid, "j", ny, &dimid[1]);
  ierr = nc_def_dim(ncid, "k", nz, &dimid[0]);

  // define vars
  ierr = nc_def_var(ncid, "x", NC_FLOAT, 1, dimid+2, &varid[0]);
  ierr = nc_def_var(ncid, "y", NC_FLOAT, 1, dimid+1, &varid[1]);
  ierr = nc_def_var(ncid, "z", NC_FLOAT, 1, dimid+0, &varid[2]);

  // attribute: index in output snapshot, index w ghost in thread
  int l_start[] = { ni1, nj1, nk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"local_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,l_start);

  int g_start[] = { gni1, gnj1, gnk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,g_start);

  int l_count[] = { ni, nj, nk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points",
                   NC_INT,CONST_NDIM,l_count);

  // end def
  ierr = nc_enddef(ncid);

  // add vars
  ierr = nc_put_var_float(ncid, varid[0], gdcart->x1d);
  ierr = nc_put_var_float(ncid, varid[1], gdcart->y1d);
  ierr = nc_put_var_float(ncid, varid[2], gdcart->z1d);
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

void
gd_curv_metric_export(gdinfo_t        *gdinfo,
                      gdcurv_metric_t *metric,
                      char *fname_coords,
                      char *output_dir)
{
  size_t *restrict g3d_pos   = metric->cmp_pos;
  char  **restrict g3d_name  = metric->cmp_name;
  int  number_of_vars = metric->ncmp;
  int  nx = metric->nx;
  int  ny = metric->ny;
  int  nz = metric->nz;
  int  ni1 = gdinfo->ni1;
  int  nj1 = gdinfo->nj1;
  int  nk1 = gdinfo->nk1;
  int  ni  = gdinfo->ni;
  int  nj  = gdinfo->nj;
  int  nk  = gdinfo->nk;
  int  gni1 = gdinfo->ni1_to_glob_phys0;
  int  gnj1 = gdinfo->nj1_to_glob_phys0;
  int  gnk1 = gdinfo->nk1_to_glob_phys0;

  // construct file name
  char ou_file[CONST_MAX_STRLEN];
  sprintf(ou_file, "%s/metric_%s.nc", output_dir, fname_coords);
  
  // read in nc
  int ncid;
  int varid[number_of_vars];
  int dimid[CONST_NDIM];

  int ierr = nc_create(ou_file, NC_CLOBBER | NC_64BIT_OFFSET, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"creat coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // define dimension
  ierr = nc_def_dim(ncid, "i", nx, &dimid[2]);
  ierr = nc_def_dim(ncid, "j", ny, &dimid[1]);
  ierr = nc_def_dim(ncid, "k", nz, &dimid[0]);

  // define vars
  for (int ivar=0; ivar<number_of_vars; ivar++) {
    ierr = nc_def_var(ncid, g3d_name[ivar], NC_FLOAT, CONST_NDIM, dimid, &varid[ivar]);
  }

  // attribute: index in output snapshot, index w ghost in thread
  int l_start[] = { ni1, nj1, nk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"local_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,l_start);

  int g_start[] = { gni1, gnj1, gnk1 };
  nc_put_att_int(ncid,NC_GLOBAL,"global_index_of_first_physical_points",
                   NC_INT,CONST_NDIM,g_start);

  int l_count[] = { ni, nj, nk };
  nc_put_att_int(ncid,NC_GLOBAL,"count_of_physical_points",
                   NC_INT,CONST_NDIM,l_count);

  // end def
  ierr = nc_enddef(ncid);

  // add vars
  for (int ivar=0; ivar<number_of_vars; ivar++) {
    float *ptr = metric->v4d + g3d_pos[ivar];
    ierr = nc_put_var_float(ncid, varid[ivar],ptr);
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }
}

void
gd_curv_metric_import(gdcurv_metric_t *metric, char *fname_coords, char *import_dir)
{
  // construct file name
  char in_file[CONST_MAX_STRLEN];
  sprintf(in_file, "%s/metric_%s.nc", import_dir, fname_coords);
  
  // read in nc
  int ncid;
  int varid;

  int ierr = nc_open(in_file, NC_NOWRITE, &ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"open coord nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  // read vars
  for (int ivar=0; ivar<metric->ncmp; ivar++)
  {
    float *ptr = metric->v4d + metric->cmp_pos[ivar];

    ierr = nc_inq_varid(ncid, metric->cmp_name[ivar], &varid);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }

    ierr = nc_get_var(ncid, varid, ptr);
    if (ierr != NC_NOERR){
      fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
      exit(-1);
    }
  }
  
  // close file
  ierr = nc_close(ncid);
  if (ierr != NC_NOERR){
    fprintf(stderr,"nc error: %s\n", nc_strerror(ierr));
    exit(-1);
  }

  return;
}

/*
 * generate grid from a input grid layer file
 * code by SunWenliang  2021/06/14
 */

int
gd_curv_gen_layer_car(char *in_grid_layer_file,
                      int n_total_grid_car,
                      float *restrict xx3d,
                      float *restrict yy3d,
                      float *restrict zz3d,float *dxyz,
                      int nxx, int gnii1, int fdx_nghosts, 
                      int nyy, int gnjj1, int fdy_nghosts, 
                      int nzz, int gnkk1, int fdz_nghosts)
{
  int ierr = 0;

  //
  // read data from layer file
  //
  FILE * fp;
  fp = fopen( in_grid_layer_file, "r");
  if (!fp){
    fprintf(stderr,"Failed to open input file of interface!!\n");
    exit(-1);
  }


  float * grid3d_In        = NULL;
  grid3d_In = (float *)fdlib_mem_malloc_1d( nzz  * 3 * sizeof(float), 
                                                              "gd_curv_gen_cartesian"); //layer2d_In contains x2d and z2d
  for ( int i=0; i<nzz; i++)
  {
    // read x,z of each sample
    fscanf(fp,"%f",&grid3d_In[i        ]);
    fscanf(fp,"%f",&grid3d_In[i +  nzz ]);
    fscanf(fp,"%f",&grid3d_In[i +2*nzz ]);
  }                                                            
  *dxyz = grid3d_In[1] - grid3d_In[0];

  //interp cartesian grid
  for (int i = 0; i < nxx; i++)
  {
    for (int j = 0; j < nyy; j++) 
    {
      for (int k = 0; k < nzz; k++)
      {
        xx3d[M_gd_INDEX(i, j, k, nxx, nyy)] =  grid3d_In[i + gnii1];
        yy3d[M_gd_INDEX(i, j, k, nxx, nyy)] =  grid3d_In[j + gnjj1 + (n_total_grid_car + 2*fdx_nghosts) * 1];
        zz3d[M_gd_INDEX(i, j, k, nxx, nyy)] =  grid3d_In[k + (n_total_grid_car + 2*fdx_nghosts) * 2];
        //fprintf(stdout, "xx2d and zz2d of iptr %d is %f  and  %f\n",M_gd_INDEX(i, k, nxz),xx2d[M_gd_INDEX(i, k, nxz)],zz2d[M_gd_INDEX(i, k, nxz)]);
      }
    }
  }
  free(grid3d_In);

  return ierr;
}



int
gd_curv_gen_layer(char *in_grid_layer_file,
                      int *grid_layer_resample_factor,
                      int *grid_layer_start,
                      int n_total_grid_x,
                      int n_total_grid_y,
                      int n_total_grid_z,
                      float *restrict x3d,
                      float *restrict y3d,
                      float *restrict z3d,
                      int nx, int ni, int gni1, int fdx_nghosts, 
                      int ny, int nj, int gnj1, int fdy_nghosts, 
                      int nz, int nk, int gnk1, int fdz_nghosts)
{
  int ierr = 0;

  int nLayers;
  int n_Interfaces;
  int nx_layers;
  int ny_layers;
  int nx_first;
  int ny_first;
  int nz_first;
  int nx_interp;
  int ny_interp;
  int nz_interp;
  size_t iptr1 ;
  size_t iptr2 ;
  size_t iptr3 ;

//
// read data from layer file
//

  FILE * fp;
  fp = fopen( in_grid_layer_file, "r");
  if (!fp){
    fprintf(stderr,"Failed to open input file of interface!!\n");
    exit(-1);
  }

  // read number of interface
  fscanf(fp,"%d", &n_Interfaces);

  nLayers = n_Interfaces - 1;
  int NCellPerlay_IN[nLayers];
  int NCellPerlay[nLayers];
  int VmapSpacingIsequal[nLayers];

  // read cells and is_equal of each layer
  for ( int i=0; i<nLayers; i++)
  {
    fscanf(fp,"%d",&NCellPerlay_IN[i]);
  }
  for ( int i=0; i<nLayers; i++)
  {
    fscanf(fp,"%d",&VmapSpacingIsequal[i]);
  }

  // read number of horizontal sampling
  fscanf(fp,"%d",&nx_layers);
  fscanf(fp,"%d",&ny_layers);

  size_t siz_volume_layerIn = nx_layers  * ny_layers  * (nLayers+1) ;  
  float * layer3d_In        = NULL;
  layer3d_In = (float *)fdlib_mem_malloc_1d(siz_volume_layerIn * 3 * sizeof(float), 
                                                              "gd_curv_gen_layer");
  for ( int i=0; i<siz_volume_layerIn; i++)
  {
    // read x,y,z of each sample
    fscanf(fp,"%f",&layer3d_In[i                       ]);
    fscanf(fp,"%f",&layer3d_In[i + siz_volume_layerIn  ]);
    fscanf(fp,"%f",&layer3d_In[i + siz_volume_layerIn*2]);
  }

  fclose( fp );

//
// resample of input interface grid nodes
//

  int x_interp_factor = abs(grid_layer_resample_factor[0]);
  int y_interp_factor = abs(grid_layer_resample_factor[1]);
  int z_interp_factor = abs(grid_layer_resample_factor[2]);

  // effective layer nx after downsampling
  if ( grid_layer_resample_factor[0] < 0 ) {
    nx_interp = floor((nx_layers              + 1) / x_interp_factor);
    nx_first  = floor((grid_layer_start[0] + 1) / x_interp_factor);
  }
  // effective layer nx after upsampling
  else
  { 
    nx_interp = (nx_layers               -1) * x_interp_factor + 1;
    nx_first  = (grid_layer_start[0]-1) * x_interp_factor + 1;
  }

  if ( grid_layer_resample_factor[1] < 0 ) 
  {
    ny_interp = floor( (ny_layers               +1) / y_interp_factor );
    ny_first  = floor( (grid_layer_start[1]+1) / y_interp_factor );
  }
  else
  { 
    ny_interp = (ny_layers               -1) * y_interp_factor + 1;
    ny_first  = (grid_layer_start[1]-1) * y_interp_factor + 1;
  }

  nz_interp = 1;
  if ( grid_layer_resample_factor[2] < 0 ) 
  {
    for ( int kk=0; kk<nLayers; kk++)
    {
      NCellPerlay[kk] = NCellPerlay_IN[kk] / z_interp_factor ;
      nz_interp = nz_interp + NCellPerlay[kk];
    }
  }
  else
  { 
    for ( int kk=0; kk<nLayers; kk++)
    {
      NCellPerlay[kk] = NCellPerlay_IN[kk] * z_interp_factor ;
      nz_interp = nz_interp + NCellPerlay[kk];
    }
  }

  nz_first = nz_interp - grid_layer_start[2] - n_total_grid_z + fdz_nghosts;
  int x_gd_first = nx_first + gni1 - fdx_nghosts; //Starting x index at input interface
  int y_gd_first = ny_first + gnj1 - fdy_nghosts;
  int z_gd_first = nz_first + gnk1 - fdz_nghosts;

  if (gni1 + gnj1 == 0)
  {
    fprintf(stdout, "-------------------------------------------------------\n");
    fprintf(stdout, "--> Input layer information.\n");
    fprintf(stdout, "-------------------------------------------------------\n");
    fprintf(stdout, "n_Interfaces = %d\n", n_Interfaces);
    fprintf(stdout, "nx_layers = %d\nny_layers = %d\n", nx_layers, ny_layers);

    fprintf(stdout, "     resample_factor = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", grid_layer_resample_factor[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "         NCellPerlay = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", NCellPerlay_IN[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "NCellPerlay_resample = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", NCellPerlay[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "  VmapSpacingIsequal = [");
    for (int ii = 0; ii < nLayers; ii++) {
      fprintf(stdout, " %d", VmapSpacingIsequal[ii]);
    }
    fprintf(stdout, " ]\n");

    fprintf(stdout, "n_input_resample = [ %d %d %d ]\n", nx_interp, ny_interp, nz_interp);
    fprintf(stdout, "          n_c3d  = [ %d %d %d ]\n", n_total_grid_x + fdx_nghosts * 2, 
                      n_total_grid_y + fdy_nghosts * 2, n_total_grid_z + fdz_nghosts * 2);
    fprintf(stdout, "horizontal_index = [ %d %d ] --> [ %d %d ]\n", x_gd_first, y_gd_first, 
    x_gd_first + n_total_grid_x + fdx_nghosts * 2, y_gd_first + n_total_grid_y + fdy_nghosts * 2);
    fprintf(stdout, "  vertical_index = %d --> %d \n", z_gd_first, z_gd_first + n_total_grid_z+ 
                                                                           fdz_nghosts);
    fprintf(stdout, "-------------------------------------------------------\n");
    fflush(stdout);
  }

  //chech interface parameters
  if (nx_first - fdx_nghosts < 0 || ny_first - fdy_nghosts < 0)
  {
    fprintf(stdout, "Input Parameter Error: horizontal_start_index.\n");
    fflush(stdout);
    fprintf(stdout, "horizontal_start_index is related to fdx_nghosts, fdy_nghosts and refine_factor\n");
    fflush(stdout);
    exit(-1);
  }
  else if (nx_first + n_total_grid_x + fdx_nghosts > nx_interp || ny_first + n_total_grid_y + fdy_nghosts > ny_interp)
  {
    fprintf(stdout, "Input Parameter Error:\n"); 
    fprintf(stdout,"nx_first=%d+n_total_grid_y=%d+fdx_nghosts=%d>nx_interp=%d\n",
             nx_first,n_total_grid_x,fdx_nghosts,nx_interp);
    fprintf(stdout,"ny_first=%d+n_total_grid_y=%d+fdy_nghosts=%d>ny_interp=%d\n",
             ny_first,n_total_grid_y,fdy_nghosts,ny_interp);
    fprintf(stdout, "please check the number_of_total_grid_points, refine_factor and in_grid_layer_file file !!\n"); 
    fflush(stdout);
    exit(-1);
  }
  else if ( z_gd_first < 0)
  {
    fprintf(stdout, "Input Parameter Error:\n"); 
    fflush(stdout);
    fprintf(stdout, "please check the vertical_FreeSurf_AfterRefine_start_index\n number_of_total_grid_point_z\n refine_factor \nin_grid_layer_file file\n"); 
    fflush(stdout);
    exit(-1);
  }

  // resample based on interp_factor on input grid layer
  size_t siz_volume_layer_interp = nx_interp * ny_interp * (nLayers + 1);
  float *layer3d_interp = NULL;
  layer3d_interp = (float *)fdlib_mem_malloc_1d(siz_volume_layer_interp * 3 * sizeof(float), 
                                                                        "gd_curv_gen_layer");
  
  // 
  float   *xi_lenX = NULL;
  float   *xn_lenX = NULL;
  float *yi_x_lenX = NULL;
  float *yn_x_lenX = NULL;
  float *yi_y_lenX = NULL;
  float *yn_y_lenX = NULL;
  float *yi_z_lenX = NULL;
  float *yn_z_lenX = NULL;
  float   *xi_lenY = NULL;
  float   *xn_lenY = NULL;
  float *yi_x_lenY = NULL;
  float *yn_x_lenY = NULL;
  float *yi_y_lenY = NULL;
  float *yn_y_lenY = NULL;
  float *yi_z_lenY = NULL;
  float *yn_z_lenY = NULL;

  xi_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  xn_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");
  yi_x_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  yn_x_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");
  yi_y_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  yn_y_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");
  yi_z_lenX = (float *)fdlib_mem_malloc_1d(nx_interp * sizeof(float), "gd_curv_gen_layer");
  yn_z_lenX = (float *)fdlib_mem_malloc_1d(nx_layers * sizeof(float), "gd_curv_gen_layer");

  xi_lenY = (float *)fdlib_mem_malloc_1d(ny_interp * sizeof(float), "gd_curv_gen_layer");
  xn_lenY = (float *)fdlib_mem_malloc_1d(ny_layers * sizeof(float), "gd_curv_gen_layer");
  yi_x_lenY = (float *)fdlib_mem_malloc_1d(ny_interp * sizeof(float), "gd_curv_gen_layer");
  yn_x_lenY = (float *)fdlib_mem_malloc_1d(ny_layers * sizeof(float), "gd_curv_gen_layer");
  yi_y_lenY = (float *)fdlib_mem_malloc_1d(ny_interp * sizeof(float), "gd_curv_gen_layer");
  yn_y_lenY = (float *)fdlib_mem_malloc_1d(ny_layers * sizeof(float), "gd_curv_gen_layer");
  yi_z_lenY = (float *)fdlib_mem_malloc_1d(ny_interp * sizeof(float), "gd_curv_gen_layer");
  yn_z_lenY = (float *)fdlib_mem_malloc_1d(ny_layers * sizeof(float), "gd_curv_gen_layer");

  // Downsampling in X and Y
  if (grid_layer_resample_factor[0] < 2 && grid_layer_resample_factor[1] < 2 ) 
  {
    for (int kk = 0; kk < nLayers+1; kk++) {
      for (int jj = 0; jj < ny_interp; jj++) {
        for (int ii = 0; ii < nx_interp; ii++) {
          iptr1 = M_gd_INDEX(ii, jj, kk, nx_interp, ny_interp);
          iptr2 = M_gd_INDEX(ii * x_interp_factor, jj * y_interp_factor, kk, nx_layers,
                        ny_layers);
          layer3d_interp[ iptr1                           ] = layer3d_In[ iptr2 ];
          layer3d_interp[ iptr1 +siz_volume_layer_interp  ] = layer3d_In[ iptr2 +siz_volume_layerIn   ]; 
          layer3d_interp[ iptr1 +siz_volume_layer_interp*2] = layer3d_In[ iptr2 +siz_volume_layerIn*2 ]; 
        }
      }
    }
  }
  //Downsampling in X, Interpolating in Y
  else if( grid_layer_resample_factor[0] < 2 && grid_layer_resample_factor[1] >= 2  )  
  {
    for ( int jj1=0; jj1<ny_interp; jj1++) xi_lenY[jj1] = jj1;
    for ( int jj1=0; jj1<ny_layers; jj1++) xn_lenY[jj1] = jj1*y_interp_factor;

    for (int kk = 0; kk < nLayers+1; kk++) {
      for (int ii = 0; ii < nx_interp; ii++) {
        for ( int jj1=0; jj1<ny_layers; jj1++)
        {
          yn_x_lenY[jj1] = layer3d_In[M_gd_INDEX(ii*x_interp_factor, jj1, kk, nx_layers,
                                       ny_layers)                        ];
          yn_y_lenY[jj1] = layer3d_In[M_gd_INDEX(ii*x_interp_factor, jj1, kk, nx_layers,
                                             ny_layers) + siz_volume_layerIn   ];
          yn_z_lenY[jj1] = layer3d_In[M_gd_INDEX(ii*x_interp_factor, jj1, kk, nx_layers,
                                             ny_layers) + siz_volume_layerIn*2 ];
        }

        gd_SPL(ny_layers, xn_lenY, yn_x_lenY, ny_interp, xi_lenY, yi_x_lenY);
        gd_SPL(ny_layers, xn_lenY, yn_y_lenY, ny_interp, xi_lenY, yi_y_lenY);
        gd_SPL(ny_layers, xn_lenY, yn_z_lenY, ny_interp, xi_lenY, yi_z_lenY);

        for (int jj = 0; jj < ny_interp; jj++)
        {
          iptr1 = M_gd_INDEX(ii, jj, kk, nx_interp, ny_interp);
          layer3d_interp[iptr1] = yi_x_lenY[jj];
          layer3d_interp[iptr1 + siz_volume_layer_interp] = yi_y_lenY[jj];
          layer3d_interp[iptr1 + siz_volume_layer_interp * 2] = yi_z_lenY[jj];
        }
      }
    }
  }
  //Interpolating in in X, Downsampling in Y
  else if( grid_layer_resample_factor[0] >=2 && grid_layer_resample_factor[1] < 2  )  
  {
    for ( int ii1=0; ii1<nx_interp; ii1++) xi_lenX[ii1] = ii1;
    for ( int ii1=0; ii1<nx_layers; ii1++) xn_lenX[ii1] = ii1*x_interp_factor;

    for (int kk = 0; kk < nLayers+1; kk++) {
      for (int jj = 0; jj < ny_interp; jj++) {
        for ( int ii1=0; ii1<nx_layers; ii1++)
        {
          yn_x_lenX[ii1] = layer3d_In[M_gd_INDEX(ii1, jj*y_interp_factor, kk, nx_layers,
                                            ny_layers)                        ];
          yn_y_lenX[ii1] = layer3d_In[M_gd_INDEX(ii1, jj*y_interp_factor, kk, nx_layers,
                                            ny_layers) + siz_volume_layerIn   ];
          yn_z_lenX[ii1] = layer3d_In[M_gd_INDEX(ii1, jj*y_interp_factor, kk, nx_layers,
                                            ny_layers) + siz_volume_layerIn*2 ];
        }

        gd_SPL(nx_layers, xn_lenX, yn_x_lenX, nx_interp, xi_lenX, yi_x_lenX);
        gd_SPL(nx_layers, xn_lenX, yn_y_lenX, nx_interp, xi_lenX, yi_y_lenX);
        gd_SPL(nx_layers, xn_lenX, yn_z_lenX, nx_interp, xi_lenX, yi_z_lenX);

        for (int ii = 0; ii < nx_interp; ii++)
        {
            iptr1 = M_gd_INDEX(ii, jj, kk, nx_interp, ny_interp);
            layer3d_interp[iptr1] = yi_x_lenX[ii];
            layer3d_interp[iptr1 + siz_volume_layer_interp] = yi_y_lenX[ii];
            layer3d_interp[iptr1 + siz_volume_layer_interp * 2] = yi_z_lenX[ii];
        }
      }
    }
  }
  // Interpolating in in X and Y
  else if( grid_layer_resample_factor[0] >=2 && grid_layer_resample_factor[1] >= 2  ) 
  {
    // interp x
    for ( int ii1=0; ii1<nx_interp; ii1++) xi_lenX[ii1] = ii1;
    for ( int ii1=0; ii1<nx_layers; ii1++) xn_lenX[ii1] = ii1*x_interp_factor;
    for (int kk = 0; kk < nLayers+1; kk++) {
      for (int jj = 0; jj < ny_layers; jj++) {
        for ( int ii1=0; ii1<nx_layers; ii1++)
        {
          yn_x_lenX[ii1] = layer3d_In[M_gd_INDEX(ii1, jj, kk, nx_layers, ny_layers)];
          yn_y_lenX[ii1] = layer3d_In[M_gd_INDEX(ii1, jj, kk, nx_layers, ny_layers) 
                                       + siz_volume_layerIn   ];
          yn_z_lenX[ii1] = layer3d_In[M_gd_INDEX(ii1, jj, kk, nx_layers, ny_layers) 
                                       + siz_volume_layerIn*2 ];
        }

        gd_SPL( nx_layers, xn_lenX, yn_x_lenX, nx_interp, xi_lenX, yi_x_lenX);
        gd_SPL( nx_layers, xn_lenX, yn_y_lenX, nx_interp, xi_lenX, yi_y_lenX);
        gd_SPL( nx_layers, xn_lenX, yn_z_lenX, nx_interp, xi_lenX, yi_z_lenX);

        for (int ii = 0; ii < nx_interp; ii++)
        {
          iptr1 = M_gd_INDEX( ii, jj*y_interp_factor, kk, nx_interp, ny_interp );
          layer3d_interp[ iptr1                           ] = yi_x_lenX[ ii ];
          layer3d_interp[ iptr1 +siz_volume_layer_interp  ] = yi_y_lenX[ ii ];
          layer3d_interp[ iptr1 +siz_volume_layer_interp*2] = yi_z_lenX[ ii ];
        }
      }
    }

    // interp y
    for ( int jj1=0; jj1<ny_interp; jj1++) xi_lenY[jj1] = jj1;
    for ( int jj1=0; jj1<ny_layers; jj1++) xn_lenY[jj1] = jj1*y_interp_factor;
    for (int kk = 0; kk < nLayers+1; kk++) {
      for (int ii = 0; ii < nx_interp; ii++) {
        for ( int jj1=0; jj1<ny_layers; jj1++) {
          yn_x_lenY[jj1] = layer3d_interp[M_gd_INDEX(ii, jj1 * y_interp_factor, kk,
                               nx_interp, ny_interp)];
          yn_y_lenY[jj1] = layer3d_interp[M_gd_INDEX(ii, jj1 * y_interp_factor, kk,
                               nx_interp, ny_interp) + siz_volume_layer_interp];
          yn_z_lenY[jj1] = layer3d_interp[M_gd_INDEX(ii, jj1 * y_interp_factor, kk,
                               nx_interp, ny_interp) + siz_volume_layer_interp * 2];
          }
          gd_SPL( ny_layers, xn_lenY, yn_x_lenY, ny_interp, xi_lenY, yi_x_lenY);
          gd_SPL( ny_layers, xn_lenY, yn_y_lenY, ny_interp, xi_lenY, yi_y_lenY);
          gd_SPL( ny_layers, xn_lenY, yn_z_lenY, ny_interp, xi_lenY, yi_z_lenY);
        for (int jj = 0; jj < ny_interp; jj++) {
          iptr1 = M_gd_INDEX( ii, jj, kk, nx_interp, ny_interp );
          layer3d_interp[ iptr1                           ] = yi_x_lenY[ jj ];
          layer3d_interp[ iptr1 +siz_volume_layer_interp  ] = yi_y_lenY[ jj ];
          layer3d_interp[ iptr1 +siz_volume_layer_interp*2] = yi_z_lenY[ jj ];
        }
      }
    }  
  }

  free(xi_lenX);
  free(xn_lenX);
  free(yi_x_lenX);
  free(yn_x_lenX);
  free(yi_y_lenX);
  free(yn_y_lenX);
  free(yi_z_lenX);
  free(yn_z_lenX);
  free(xi_lenY);
  free(xn_lenY);
  free(yi_x_lenY);
  free(yn_x_lenY);
  free(yi_y_lenY);
  free(yn_y_lenY);
  free(yi_z_lenY);
  free(yn_z_lenY);

//
// generate FD grid
//

  size_t siz_volume = nx * ny * nz;
  float *layer3d = NULL;
  layer3d = ( float * ) malloc( sizeof( float ) * nx * ny * (nLayers+1) * 3 );

  // suffix ch means:
  float zdiff_two_interface; // thickness between interfaces
  float zdiff_two_interface_ch;

  float *xlayer3d = layer3d + 0 * nx*ny*(nLayers+1);
  float *ylayer3d = layer3d + 1 * nx*ny*(nLayers+1);
  float *zlayer3d = layer3d + 2 * nx*ny*(nLayers+1);
  
  float * zlayerpart  = NULL;
  float * ylayerpart  = NULL;
  float * xlayerpart  = NULL;
  zlayerpart = (float *)fdlib_mem_malloc_1d((nLayers+1) * sizeof(float), "gd_curv_gen_layer");
  ylayerpart = (float *)fdlib_mem_malloc_1d((nLayers+1) * sizeof(float), "gd_curv_gen_layer");
  xlayerpart = (float *)fdlib_mem_malloc_1d((nLayers+1) * sizeof(float), "gd_curv_gen_layer");

  float * z3dpart  = NULL;
  float * y3dpart  = NULL;
  float * x3dpart  = NULL;
  z3dpart = (float *)fdlib_mem_malloc_1d((nz_interp+fdz_nghosts*2) * sizeof(float), "gd_curv_gen_layer");
  y3dpart = (float *)fdlib_mem_malloc_1d((nz_interp+fdz_nghosts*2) * sizeof(float), "gd_curv_gen_layer");
  x3dpart = (float *)fdlib_mem_malloc_1d((nz_interp+fdz_nghosts*2) * sizeof(float), "gd_curv_gen_layer");

  // layer regions of input model covered by this thread
  for (int k = 0; k < (nLayers + 1); k++) {
    for (int j = 0; j < ny; j++) {
      for (int i = 0; i < nx; i++)
      {
        iptr1 = M_gd_INDEX(i, j, k, nx, ny);
        iptr2 = M_gd_INDEX(i + x_gd_first, j + y_gd_first, k, nx_interp, ny_interp);
        xlayer3d[iptr1] = layer3d_interp[iptr2];
        ylayer3d[iptr1] = layer3d_interp[iptr2 + siz_volume_layer_interp];
        zlayer3d[iptr1] = layer3d_interp[iptr2 + siz_volume_layer_interp * 2];
      }
    }
  }

  // interp both z and x,y
  for (int i = 0; i < nx; i++)
  {
    for (int j = 0; j < ny; j++)
    {
      for (int k = 0; k < nLayers + 1; k++)
      {
        xlayerpart[k] = xlayer3d[M_gd_INDEX(i, j, k, nx, ny)];
        ylayerpart[k] = ylayer3d[M_gd_INDEX(i, j, k, nx, ny)];
        zlayerpart[k] = zlayer3d[M_gd_INDEX(i, j, k, nx, ny)];
      }
      // Interpolating the Z coordinate of the grid 
      gd_grid_z_interp(z3dpart, zlayerpart, NCellPerlay, VmapSpacingIsequal,
                       nLayers, nx, ny);

      // Interpolating the X and Y coordinate of the grid ...
      // by cubic spline interpolation method.
      gd_SPL(nLayers + 1, zlayerpart, xlayerpart, nz_interp, z3dpart, x3dpart);
      gd_SPL(nLayers + 1, zlayerpart, ylayerpart, nz_interp, z3dpart, y3dpart);

      //Grids outside the Free Surface.
      for (int k = 1; k < fdz_nghosts + 1; k++)
      {
        iptr1 = nz_interp +2;
        x3dpart[iptr1 + k] = x3dpart[iptr1] * 2 - x3dpart[iptr1 - k];
        y3dpart[iptr1 + k] = y3dpart[iptr1] * 2 - y3dpart[iptr1 - k];
        z3dpart[iptr1 + k] = z3dpart[iptr1] * 2 - z3dpart[iptr1 - k];
      }

      //Grids under the down surface.
      for (int k = 1; k < fdz_nghosts + 1 ; k++)//1,2,3
      {
        iptr1 = fdz_nghosts ;
        x3dpart[iptr1 - k] = x3dpart[iptr1] * 2 - x3dpart[iptr1 + k];
        y3dpart[iptr1 - k] = y3dpart[iptr1] * 2 - y3dpart[iptr1 + k];
        z3dpart[iptr1 - k] = z3dpart[iptr1] * 2 - z3dpart[iptr1 + k];
      }

      for ( int k = 0; k < nk + fdz_nghosts*2; k ++)
      {
        iptr1 = z_gd_first + k;
        x3d[M_gd_INDEX(i, j, k, nx, ny)] = x3dpart[iptr1];
        y3d[M_gd_INDEX(i, j, k, nx, ny)] = y3dpart[iptr1];
        z3d[M_gd_INDEX(i, j, k, nx, ny)] = z3dpart[iptr1];
      }
    }
  }


  free(layer3d);
  free(layer3d_In);
  free(layer3d_interp);
  free(zlayerpart);
  free(ylayerpart);
  free(xlayerpart);
  free(z3dpart);
  free(y3dpart);
  free(x3dpart);

  return ierr;
}

//  Interpolating the Z coordinate
int gd_grid_z_interp(float *z3dpart, float *zlayerpart, int *NCellPerlay,
                     int *VmapSpacingIsequal, int nLayers, int nx, int ny)
{
  int ierr = 0;

  // If Grid step size of Z coordinate is not equal, divide the layer into two parts.
  // N1 is first part number of this layer and N2 is second.
  int N1;
  int N2;
  float distance;  //Interface spacing
  float dmidpoint;  //The length of the N1th grid
  float N1_Isochromatic; 
  float N2_Isochromatic;
  int NCellPerlay_max = 0;
  int sumNCellPerlay = 3;
  float LayerDz[nLayers];

  for (int i = 0; i < nLayers; i++)
  {
    if (NCellPerlay_max < NCellPerlay[i])
    {
      NCellPerlay_max = NCellPerlay[i];
    }
  }

  float range1[NCellPerlay_max];
  float range2[NCellPerlay_max];

  for (int i = 0; i < nLayers; i++)
  {
    // LayerDz[i] = (zlayer3d[M_gd_INDEX(xi, yi, i + 1, nx, ny)] -
    //               zlayer3d[M_gd_INDEX(xi, yi, i, nx, ny)]) / NCellPerlay[i];
    LayerDz[i] = (zlayerpart[i + 1] - zlayerpart[i]) / NCellPerlay[i];
  }

  for (int i = 0; i < nLayers; i++)
  {
    // The grid spacing is equal
    z3dpart[sumNCellPerlay] = zlayerpart[i];
    for (int ii = sumNCellPerlay; ii < sumNCellPerlay + NCellPerlay[i] - 1; ii++)
    {
      z3dpart[ii+1] = zlayerpart[i] + (ii - sumNCellPerlay + 1) * LayerDz[i];
    }
    // The grid spacing is not equal
    if (VmapSpacingIsequal[i] < 1 && i > 0 && i < nLayers - 1)
    {
      range1[0] = zlayerpart[i];
      if ((LayerDz[i] - LayerDz[i - 1]) * (LayerDz[i + 1] - LayerDz[i]) > 0)
      {
        N1 = ((LayerDz[i] - LayerDz[i - 1]) / (LayerDz[i + 1] - LayerDz[i - 1])) * (NCellPerlay[i] + 2) + 1;
        if (N1 > NCellPerlay[i] - 1)
          N1 = NCellPerlay[i] - 1;
        N2 = NCellPerlay[i] + 2 - N1;

        distance = zlayerpart[i + 1] - zlayerpart[i] + LayerDz[i - 1] + LayerDz[i + 1];
        dmidpoint = (2 * distance - LayerDz[i - 1] * N1 - LayerDz[i + 1] * (N2 + 1)) / (N1 + N2 - 1);

        N1_Isochromatic = (dmidpoint - LayerDz[i - 1]) / (N1 - 1);
        N2_Isochromatic = (LayerDz[i + 1] - dmidpoint) / (N2);

        for (int j = 1; j < N1; j++)
        {
          range1[j] = range1[j - 1] + LayerDz[i - 1] + j * N1_Isochromatic;
        }
        for (int j = N1; j < N1 + N2; j++)
        {
          range1[j] = range1[j - 1] + LayerDz[i + 1] - (N2 + N1 - j - 1) * N2_Isochromatic;
        }
        for (int ii = sumNCellPerlay; ii < sumNCellPerlay + NCellPerlay[i]; ii++)
        {
          z3dpart[ii] = range1[ii - sumNCellPerlay];
        }
      }
    }
    sumNCellPerlay += NCellPerlay[i];
  }
  z3dpart[sumNCellPerlay] = zlayerpart[nLayers];

  return ierr;
}

float gd_seval(int ni, float u,
            int n, float x[], float y[],
            float b[], float c[], float d[],
            int *last)
{
  int i, j, k;
  float w;
  i = *last;
  if (i >= n - 1) i = 0;
  if (i < 0) i = 0;
  if ((x[i] > u) || (x[i + 1] < u))//??
  {
    i = 0;
    j = n;
    do
    {
      k = (i + j) / 2;
      if (u < x[k]) j = k;
      if (u >= x[k]) i = k;
    } while (j > i + 1);
  }
  *last = i;
  w = u - x[i];
  w = y[i] + w * (b[i] + w * (c[i] + w * d[i]));
  return (w);
}

//// Cubic spline difference function
int gd_SPLine( int n, int end1, int end2,
           float slope1, float slope2,
           float x[], float y[],
           float b[], float c[], float d[],
           int *iflag)
{
  int nm1, ib, i, ascend;
  float t;
  nm1 = n - 1;
  *iflag = 0;
  if (n < 2)
  {
    *iflag = 1;
    goto Leavegd_SPLine;
  }
  ascend = 1;
  for (i = 1; i < n; ++i) if (x[i] <= x[i - 1]) ascend = 0;
  if (!ascend)
  {
    *iflag = 2;
    goto Leavegd_SPLine;
  }
  if (n >= 3)
  {
    d[0] = x[1] - x[0];
    c[1] = (y[1] - y[0]) / d[0];
    for (i = 1; i < nm1; ++i)
    {
      d[i] = x[i + 1] - x[i];
      b[i] = 2.0 * (d[i - 1] + d[i]);
      c[i + 1] = (y[i + 1] - y[i]) / d[i];
      c[i] = c[i + 1] - c[i];
    }
    b[0] = -d[0];
    b[nm1] = -d[n - 2];
    c[0] = 0.0;
    c[nm1] = 0.0;
    if (n != 3)
    {
      c[0] = c[2] / (x[3] - x[1]) - c[1] / (x[2] - x[0]);
      c[nm1] = c[n - 2] / (x[nm1] - x[n - 3]) - c[n - 3] / (x[n - 2] - x[n - 4]);
      c[0] = c[0] * d[0] * d[0] / (x[3] - x[0]);
      c[nm1] = -c[nm1] * d[n - 2] * d[n - 2] / (x[nm1] - x[n - 4]);
    }
    if (end1 == 1)
    {
      b[0] = 2.0 * (x[1] - x[0]);
      c[0] = (y[1] - y[0]) / (x[1] - x[0]) - slope1;
    }
    if (end2 == 1)
    {
      b[nm1] = 2.0 * (x[nm1] - x[n - 2]);
      c[nm1] = slope2 - (y[nm1] - y[n - 2]) / (x[nm1] - x[n - 2]);
    }
    // Forward elimination 
    for (i = 1; i < n; ++i)
    {
      t = d[i - 1] / b[i - 1];
      b[i] = b[i] - t * d[i - 1];
      c[i] = c[i] - t * c[i - 1];
    }
    // Back substitution 
    c[nm1] = c[nm1] / b[nm1];
    for (ib = 0; ib < nm1; ++ib)
    {
      i = n - ib - 2;
      c[i] = (c[i] - d[i] * c[i + 1]) / b[i];
    }
    b[nm1] = (y[nm1] - y[n - 2]) / d[n - 2] + d[n - 2] * (c[n - 2] + 2.0 * c[nm1]);
    for (i = 0; i < nm1; ++i)
    {
      b[i] = (y[i + 1] - y[i]) / d[i] - d[i] * (c[i + 1] + 2.0 * c[i]);
      d[i] = (c[i + 1] - c[i]) / d[i];
      c[i] = 3.0 * c[i];
    }
    c[nm1] = 3.0 * c[nm1];
    d[nm1] = d[n - 2];
  }
  else
  {
    b[0] = (y[1] - y[0]) / (x[1] - x[0]);
    c[0] = 0.0;
    d[0] = 0.0;
    b[1] = b[0];
    c[1] = 0.0;
    d[1] = 0.0;
  }
Leavegd_SPLine:
  return 0;
}

//// Cubic spline difference function in grid interpolation
void gd_SPL(int n, float *x, float *y, int ni, float *xi, float *yi)
{
  float *b, *c, *d;
  int iflag=0, last=0, i=0;
  b = (float *)fdlib_mem_malloc_1d(n * sizeof(float), "gd_SPL");
  c = (float *)fdlib_mem_malloc_1d(n * sizeof(float), "gd_SPL");
  d = (float *)fdlib_mem_malloc_1d(n * sizeof(float), "gd_SPL");

  if (!d) { printf("no enough memory for b,c,d\n"); }
  else {
    gd_SPLine(n, 0, 0, 0.0, 0.0, x, y, b, c, d, &iflag);
    for (i = 3; i<ni+3; i++)
      yi[i] = gd_seval(ni, xi[i], n, x, y, b, c, d, &last);
    free(b);
    free(c);
    free(d);
  };
}

/*
 * set min/max of grid for loc
 */

void
gd_curv_set_minmax(gdinfo_t *gdinfo, gd_t *gdcurv)
{

  // all points including ghosts
  float xmin = gdcurv->x3d[0], xmax = gdcurv->x3d[0];
  float ymin = gdcurv->y3d[0], ymax = gdcurv->y3d[0];
  float zmin = gdcurv->z3d[0], zmax = gdcurv->z3d[0];
  for (size_t i = 0; i < gdcurv->siz_volume; i++){
      xmin = xmin < gdcurv->x3d[i] ? xmin : gdcurv->x3d[i];
      xmax = xmax > gdcurv->x3d[i] ? xmax : gdcurv->x3d[i];
      ymin = ymin < gdcurv->y3d[i] ? ymin : gdcurv->y3d[i];
      ymax = ymax > gdcurv->y3d[i] ? ymax : gdcurv->y3d[i];
      zmin = zmin < gdcurv->z3d[i] ? zmin : gdcurv->z3d[i];
      zmax = zmax > gdcurv->z3d[i] ? zmax : gdcurv->z3d[i];
  }
  gdcurv->xmin = xmin;
  gdcurv->xmax = xmax;
  gdcurv->ymin = ymin;
  gdcurv->ymax = ymax;
  gdcurv->zmin = zmin;
  gdcurv->zmax = zmax;

  // all physics points without ghosts
  xmin = gdcurv->xmax;
  xmax = gdcurv->xmin;
  ymin = gdcurv->ymax;
  ymax = gdcurv->ymin;
  zmin = gdcurv->zmax;
  zmax = gdcurv->zmin;
  for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++) {
    for (int j = gdinfo->nj1; j <= gdinfo->nj2; j++) {
      for (int i = gdinfo->ni1; i <= gdinfo->ni2; i++) {
         size_t iptr = i + j * gdinfo->siz_line + k * gdinfo->siz_slice;
         xmin = xmin < gdcurv->x3d[iptr] ? xmin : gdcurv->x3d[iptr];
         xmax = xmax > gdcurv->x3d[iptr] ? xmax : gdcurv->x3d[iptr];
         ymin = ymin < gdcurv->y3d[iptr] ? ymin : gdcurv->y3d[iptr];
         ymax = ymax > gdcurv->y3d[iptr] ? ymax : gdcurv->y3d[iptr];
         zmin = zmin < gdcurv->z3d[iptr] ? zmin : gdcurv->z3d[iptr];
         zmax = zmax > gdcurv->z3d[iptr] ? zmax : gdcurv->z3d[iptr];
      }
    }
  }
  gdcurv->xmin_phy = xmin;
  gdcurv->xmax_phy = xmax;
  gdcurv->ymin_phy = ymin;
  gdcurv->ymax_phy = ymax;
  gdcurv->zmin_phy = zmin;
  gdcurv->zmax_phy = zmax;

  // set cell range, last cell along each dim unusage
  for (int k = 0; k < gdcurv->nz-1; k++) {
    for (int j = 0; j < gdcurv->ny-1; j++) {
      for (int i = 0; i < gdcurv->nx-1; i++) {
         size_t iptr = i + j * gdinfo->siz_line + k * gdinfo->siz_slice;
         xmin = gdcurv->x3d[iptr];
         ymin = gdcurv->y3d[iptr];
         zmin = gdcurv->z3d[iptr];
         xmax = xmin;
         ymax = ymin;
         zmax = zmin;
         for (int n3=0; n3<2; n3++) {
         for (int n2=0; n2<2; n2++) {
         for (int n1=0; n1<2; n1++) {
           size_t iptr_pt = iptr + n3 * gdinfo->siz_slice + n2 * gdinfo->siz_line + n1;
           xmin = xmin < gdcurv->x3d[iptr_pt] ? xmin : gdcurv->x3d[iptr_pt];
           xmax = xmax > gdcurv->x3d[iptr_pt] ? xmax : gdcurv->x3d[iptr_pt];
           ymin = ymin < gdcurv->y3d[iptr_pt] ? ymin : gdcurv->y3d[iptr_pt];
           ymax = ymax > gdcurv->y3d[iptr_pt] ? ymax : gdcurv->y3d[iptr_pt];
           zmin = zmin < gdcurv->z3d[iptr_pt] ? zmin : gdcurv->z3d[iptr_pt];
           zmax = zmax > gdcurv->z3d[iptr_pt] ? zmax : gdcurv->z3d[iptr_pt];
         }
         }
         }
         gdcurv->cell_xmin[iptr] = xmin;
         gdcurv->cell_xmax[iptr] = xmax;
         gdcurv->cell_ymin[iptr] = ymin;
         gdcurv->cell_ymax[iptr] = ymax;
         gdcurv->cell_zmin[iptr] = zmin;
         gdcurv->cell_zmax[iptr] = zmax;
      }
    }
  }

  // set tile range 

  // partition into average plus left at last
  int nx_avg  = gdinfo->ni / GD_TILE_NX; // only for physcial points
  int nx_left = gdinfo->ni % GD_TILE_NX;
  int ny_avg  = gdinfo->nj / GD_TILE_NY;
  int ny_left = gdinfo->nj % GD_TILE_NY;
  int nz_avg  = gdinfo->nk / GD_TILE_NZ;
  int nz_left = gdinfo->nk % GD_TILE_NZ;
  for (int k_tile = 0; k_tile < GD_TILE_NZ; k_tile++)
  {
    if (k_tile == 0) {
      gdcurv->tile_kstart[k_tile] = gdinfo->nk1;
    } else {
      gdcurv->tile_kstart[k_tile] = gdcurv->tile_kend[k_tile-1] + 1;
    }

    gdcurv->tile_kend  [k_tile] = gdcurv->tile_kstart[k_tile] + nz_avg -1;
    if (k_tile < nz_left) {
      gdcurv->tile_kend[k_tile] += 1;
    }

    for (int j_tile = 0; j_tile < GD_TILE_NY; j_tile++)
    {
      if (j_tile == 0) {
        gdcurv->tile_jstart[j_tile] = gdinfo->nj1;
      } else {
        gdcurv->tile_jstart[j_tile] = gdcurv->tile_jend[j_tile-1] + 1;
      }

      gdcurv->tile_jend  [j_tile] = gdcurv->tile_jstart[j_tile] + ny_avg -1;
      if (j_tile < ny_left) {
        gdcurv->tile_jend[j_tile] += 1;
      }

      for (int i_tile = 0; i_tile < GD_TILE_NX; i_tile++)
      {
        if (i_tile == 0) {
          gdcurv->tile_istart[i_tile] = gdinfo->ni1;
        } else {
          gdcurv->tile_istart[i_tile] = gdcurv->tile_iend[i_tile-1] + 1;
        }

        gdcurv->tile_iend  [i_tile] = gdcurv->tile_istart[i_tile] + nx_avg -1;
        if (i_tile < nx_left) {
          gdcurv->tile_iend[i_tile] += 1;
        }

        // use large value to init
        xmin = 1.0e26;
        ymin = 1.0e26;
        zmin = 1.0e26;
        xmax = -1.0e26;
        ymax = -1.0e26;
        zmax = -1.0e26;
        // for cells in each tile
        for (int k = gdcurv->tile_kstart[k_tile]; k <= gdcurv->tile_kend[k_tile]; k++)
        {
          size_t iptr_k = k * gdinfo->siz_slice;
          for (int j = gdcurv->tile_jstart[j_tile]; j <= gdcurv->tile_jend[j_tile]; j++)
          {
            size_t iptr_j = iptr_k + j * gdinfo->siz_line;
            for (int i = gdcurv->tile_istart[i_tile]; i <= gdcurv->tile_iend[i_tile]; i++)
            {
              size_t iptr = i + iptr_j;
              xmin = xmin < gdcurv->cell_xmin[iptr] ? xmin : gdcurv->cell_xmin[iptr];
              xmax = xmax > gdcurv->cell_xmax[iptr] ? xmax : gdcurv->cell_xmax[iptr];
              ymin = ymin < gdcurv->cell_ymin[iptr] ? ymin : gdcurv->cell_ymin[iptr];
              ymax = ymax > gdcurv->cell_ymax[iptr] ? ymax : gdcurv->cell_ymax[iptr];
              zmin = zmin < gdcurv->cell_zmin[iptr] ? zmin : gdcurv->cell_zmin[iptr];
              zmax = zmax > gdcurv->cell_zmax[iptr] ? zmax : gdcurv->cell_zmax[iptr];
            }
          }
        }
        gdcurv->tile_xmin[k_tile][j_tile][i_tile] = xmin;
        gdcurv->tile_xmax[k_tile][j_tile][i_tile] = xmax;
        gdcurv->tile_ymin[k_tile][j_tile][i_tile] = ymin;
        gdcurv->tile_ymax[k_tile][j_tile][i_tile] = ymax;
        gdcurv->tile_zmin[k_tile][j_tile][i_tile] = zmin;
        gdcurv->tile_zmax[k_tile][j_tile][i_tile] = zmax;

      }
    }
  } // k_tile

  return;
}

/*
 * convert cart coord to global index
 */

int
gd_cart_coord_to_glob_indx(gdinfo_t *gdinfo,
                           gd_t *gdcart,
                           float sx,
                           float sy,
                           float sz,
                           MPI_Comm comm,
                           int myid,
                           int   *ou_si, int *ou_sj, int *ou_sk,
                           float *ou_sx_inc, float *ou_sy_inc, float *ou_sz_inc)
{
  int ierr = 0;

  int si_glob = (int)( (sx - gdcart->x0_glob) / gdcart->dx + 0.5 );
  int sj_glob = (int)( (sy - gdcart->y0_glob) / gdcart->dy + 0.5 );
  int sk_glob = (int)( (sz - gdcart->z0_glob) / gdcart->dz + 0.5 );
  float sx_inc = si_glob * gdcart->dx + gdcart->x0_glob - sx;
  float sy_inc = sj_glob * gdcart->dy + gdcart->y0_glob - sy;
  float sz_inc = sk_glob * gdcart->dz + gdcart->z0_glob - sz;

  *ou_si = si_glob;
  *ou_sj = sj_glob;
  *ou_sk = sk_glob;
  *ou_sx_inc = sx_inc;
  *ou_sy_inc = sy_inc;
  *ou_sz_inc = sz_inc;

  return ierr; 
}

/*
 * convert curv coord to global index using MPI
 */

int
gd_curv_coord_to_glob_indx(gdinfo_t *gdinfo,
                           gd_t *gdcurv,
                           float sx,
                           float sy,
                           float sz,
                           MPI_Comm comm,
                           int myid,
                           int   *ou_si, int *ou_sj, int *ou_sk,
                           float *ou_sx_inc, float *ou_sy_inc, float *ou_sz_inc)
{
  int is_here = 0;

  //NOTE si_glob sj_glob sk_glob must less -3. due to ghost points length is 3.
  int si_glob = -1000;
  int sj_glob = -1000;
  int sk_glob = -1000;
  float sx_inc = 0.0;
  float sy_inc = 0.0;
  float sz_inc = 0.0;
  int si = 0;
  int sj = 0;
  int sk = 0;

  // if located in this thread
  is_here = gd_curv_coord_to_local_indx(gdinfo,gdcurv,sx,sy,sz,
                                    &si, &sj, &sk, &sx_inc, &sy_inc, &sz_inc);

  // if in this thread
  if ( is_here == 1)
  {
    // conver to global index
    si_glob = gd_info_ind_lcext2glphy_i(si, gdinfo);
    sj_glob = gd_info_ind_lcext2glphy_j(sj, gdinfo);
    sk_glob = gd_info_ind_lcext2glphy_k(sk, gdinfo);
    //fprintf(stdout," -- located to local index = %d %d %d\n", si,sj,sk);
    //fprintf(stdout," -- located to global index = %d %d %d\n", 
    //                      si_glob, sj_glob, sk_glob);
    //fprintf(stdout," --  with shift = %f %f %f\n", sx_inc,sy_inc,sz_inc);
  } else {
    //fprintf(stdout," -- not in this thread %d\n", myid);
  }

  // reduce global index and shift values
  int sendbufi = si_glob;
  MPI_Allreduce(&sendbufi, &si_glob, 1, MPI_INT, MPI_MAX, comm);

  sendbufi = sj_glob;
  MPI_Allreduce(&sendbufi, &sj_glob, 1, MPI_INT, MPI_MAX, comm);

  sendbufi = sk_glob;
  MPI_Allreduce(&sendbufi, &sk_glob, 1, MPI_INT, MPI_MAX, comm);

  float sendbuf = sx_inc;
  MPI_Allreduce(&sendbuf, &sx_inc, 1, MPI_FLOAT, MPI_SUM, comm);

  sendbuf = sy_inc;
  MPI_Allreduce(&sendbuf, &sy_inc, 1, MPI_FLOAT, MPI_SUM, comm);

  sendbuf = sz_inc;
  MPI_Allreduce(&sendbuf, &sz_inc, 1, MPI_FLOAT, MPI_SUM, comm);

  //fprintf(stdout," --myid=%d,index=%d %d %d,shift = %f %f %f\n",
  //    myid,si_glob,sj_glob,sk_glob, sx_inc,sy_inc,sz_inc);

  *ou_si = si_glob;
  *ou_sj = sj_glob;
  *ou_sk = sk_glob;
  *ou_sx_inc = sx_inc;
  *ou_sy_inc = sy_inc;
  *ou_sz_inc = sz_inc;

  return is_here; 
}

/* 
 * if the nearest point in this thread then search its grid index
 *   return value:
 *      1 - in this thread
 *      0 - not in this thread
 */

int
gd_curv_coord_to_local_indx(gdinfo_t *gdinfo,
                        gd_t *gd,
                        float sx, float sy, float sz,
                        int *si, int *sj, int *sk,
                        float *sx_inc, float *sy_inc, float *sz_inc)
{
  int is_here = 0; // default outside

  // not here if outside coord range
  if ( sx < gd->xmin || sx > gd->xmax ||
       sy < gd->ymin || sy > gd->ymax ||
       sz < gd->zmin || sz > gd->zmax)
  {
    return is_here;
  }

  //fprintf(stdout,"--debug: sx=%g,sy=%g,sz=%g,range (%g,%g),(%g,%g),(%g,%g)\n",
  //            sx,sy,sz,
  //            gd->xmin, gd->xmax,
  //            gd->ymin, gd->ymax,
  //            gd->zmin, gd->zmax);
  //fflush(stdout);

  // otherwise loop all cells

  int nx = gdinfo->nx;
  int ny = gdinfo->ny;
  int nz = gdinfo->nz;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  size_t siz_line  = gdinfo->siz_line;
  size_t siz_slice = gdinfo->siz_slice;

  float *restrict x3d = gd->x3d;
  float *restrict y3d = gd->y3d;
  float *restrict z3d = gd->z3d;

  // for isPointInHexahedron
  float points_x[8];
  float points_y[8];
  float points_z[8];

  size_t iptr_k, iptr_j, iptr;

  // take upper-right cell, thus do not take last index
  for (int k_tile = 0; k_tile < GD_TILE_NZ; k_tile++)
  {
    for (int j_tile = 0; j_tile < GD_TILE_NY; j_tile++)
    {
      for (int i_tile = 0; i_tile < GD_TILE_NX; i_tile++)
      {
        //fprintf(stdout,"--debug0: sx=%g,sy=%g,sz=%g,tile %d,%d,%d,(%g,%g),(%g,%g),(%g,%g)\n",
        //            sx,sy,sz,i_tile,j_tile,k_tile,
        //            gd->tile_xmin[k_tile][j_tile][i_tile],
        //            gd->tile_xmax[k_tile][j_tile][i_tile],
        //            gd->tile_ymin[k_tile][j_tile][i_tile],
        //            gd->tile_ymax[k_tile][j_tile][i_tile],
        //            gd->tile_zmin[k_tile][j_tile][i_tile],
        //            gd->tile_zmax[k_tile][j_tile][i_tile]);
        //fflush(stdout);

        if (  sx < gd->tile_xmin[k_tile][j_tile][i_tile] ||
              sx > gd->tile_xmax[k_tile][j_tile][i_tile] ||
              sy < gd->tile_ymin[k_tile][j_tile][i_tile] ||
              sy > gd->tile_ymax[k_tile][j_tile][i_tile] ||
              sz < gd->tile_zmin[k_tile][j_tile][i_tile] ||
              sz > gd->tile_zmax[k_tile][j_tile][i_tile])
        {
          // loop next tile
          continue;
        }

        //fprintf(stdout,"--debug: sx=%g,sy=%g,sz=%g,tile %d,%d,%d,(%g,%g),(%g,%g),(%g,%g)\n",
        //            sx,sy,sz,i_tile,j_tile,k_tile,
        //            gd->tile_xmin[k_tile][j_tile][i_tile],
        //            gd->tile_xmax[k_tile][j_tile][i_tile],
        //            gd->tile_ymin[k_tile][j_tile][i_tile],
        //            gd->tile_ymax[k_tile][j_tile][i_tile],
        //            gd->tile_zmin[k_tile][j_tile][i_tile],
        //            gd->tile_zmax[k_tile][j_tile][i_tile]);
        //fflush(stdout);

        // otherwise may in this tile
        for (int k = gd->tile_kstart[k_tile]; k <= gd->tile_kend[k_tile]; k++)
        {
          iptr_k = k * siz_slice;
          for (int j = gd->tile_jstart[j_tile]; j <= gd->tile_jend[j_tile]; j++)
          {
            iptr_j = iptr_k + j * siz_line;
            for (int i = gd->tile_istart[i_tile]; i <= gd->tile_iend[i_tile]; i++)
            {
              iptr = i + iptr_j;

              // use AABB algorith
              if (  sx < gd->cell_xmin[iptr] ||
                    sx > gd->cell_xmax[iptr] ||
                    sy < gd->cell_ymin[iptr] ||
                    sy > gd->cell_ymax[iptr] ||
                    sz < gd->cell_zmin[iptr] ||
                    sz > gd->cell_zmax[iptr])
              {
                // loop next cell
                continue;
              }

              //fprintf(stdout,"--debug: point %d,%d,%d,(%g,%g),(%g,%g),(%g,%g)\n",
              //            i,j,k,
              //            gd->cell_xmin[iptr],
              //            gd->cell_xmax[iptr],
              //            gd->cell_ymin[iptr],
              //            gd->cell_ymax[iptr],
              //            gd->cell_zmin[iptr],
              //            gd->cell_zmax[iptr]);
              //fflush(stdout);

              // otherwise may in this cell, use inpolygon to check

              // set cell points
              for (int n3=0; n3<2; n3++) {
                for (int n2=0; n2<2; n2++) {
                  for (int n1=0; n1<2; n1++) {
                    int iptr_cube = n1 + n2 * 2 + n3 * 4;
                    int iptr_pt = (i+n1) + (j+n2) * siz_line + (k+n3) * siz_slice;
                    points_x[iptr_cube] = x3d[iptr_pt];
                    points_y[iptr_cube] = y3d[iptr_pt];
                    points_z[iptr_cube] = z3d[iptr_pt];
                  }
                }
              }

              // is in this cell
              if (isPointInHexahedron(sx,sy,sz,points_x,points_y,points_z) == true)
              {
                is_here = 1;

                // get shift in cell
                gd_curv_coord2shift_sample(sx,sy,sz,8,
                    points_x,points_y,points_z,
                    100,100,100,
                    sx_inc, sy_inc, sz_inc);

                // convert to return values
                *si = i;
                *sj = j;
                *sk = k;

                if (*sx_inc > 0.5) {
                  *si += 1;
                  *sx_inc -= 1.0;
                }
                if (*sy_inc > 0.5) {
                  *sj += 1;
                  *sy_inc -= 1.0;
                }
                if (*sz_inc > 0.5) {
                  *sk += 1;
                  *sz_inc -= 1.0;
                }

                return is_here;
              }
              
            } // i
          }
        }
      } // i_tile
    } // j_tile
  } // k_tile

  // not here
  return is_here;
}

/*
 * convert depth to axis
 */
int
gd_curv_depth_to_axis(gdinfo_t *gdinfo,
                      gd_t *gd,
                      float sx,
                      float sy,
                      float *sz,
                      MPI_Comm comm,
                      int myid)
{
  int ierr = 0;

  // not here if outside coord range
  if ( sx < gd->xmin || sx > gd->xmax ||
       sy < gd->ymin || sy > gd->ymax )
  {
    return ierr;
  }

  float points_x[4];
  float points_y[4];
  float points_z[4];

  size_t iptr_k, iptr_j, iptr;

  // take upper-right cell, thus do not take last index
  int k_tile = GD_TILE_NZ - 1;//= 3
  {
    for (int j_tile = 0; j_tile < GD_TILE_NY; j_tile++)
    {
      for (int i_tile = 0; i_tile < GD_TILE_NX; i_tile++)
      {
        if (  sx < gd->tile_xmin[k_tile][j_tile][i_tile] ||
              sx > gd->tile_xmax[k_tile][j_tile][i_tile] ||
              sy < gd->tile_ymin[k_tile][j_tile][i_tile] ||
              sy > gd->tile_ymax[k_tile][j_tile][i_tile])
        {
          // loop next tile
          continue;
        }

        // otherwise may in this tile
        int k = gd->tile_kend[k_tile];
        {
          iptr_k = k * gdinfo->siz_slice;
          for (int j = gd->tile_jstart[j_tile]; j <= gd->tile_jend[j_tile]; j++)
          {
            iptr_j = iptr_k + j * gdinfo->siz_line;
            for (int i = gd->tile_istart[i_tile]; i <= gd->tile_iend[i_tile]; i++)
            {
              iptr = i + iptr_j;

              // use AABB algorith
              if (  sx < gd->cell_xmin[iptr] ||
                    sx > gd->cell_xmax[iptr] ||
                    sy < gd->cell_ymin[iptr] ||
                    sy > gd->cell_ymax[iptr] )
              {
                // loop next cell
                continue;
              }

              // otherwise may in this cell, use inpolygon to check

              // set cell points
              for (int n2=0; n2<2; n2++) {
                for (int n1=0; n1<2; n1++) {
                  int iptr_cube = n1 + n2 * 2;
                  int iptr_pt = (i+n1) + (j+n2) * gdinfo->siz_line + k * gdinfo->siz_slice;
                  points_x[iptr_cube] = gd->x3d[iptr_pt];
                  points_y[iptr_cube] = gd->y3d[iptr_pt];
                  points_z[iptr_cube] = gd->z3d[iptr_pt];
                }
              }

              // interp z if in this cell
              if (fdlib_math_isPoint2InQuad(sx,sy,points_x,points_y) == 1)
              {
                float ztopo = fdlib_math_rdinterp_2d(sx,sy,4,points_x,points_y,points_z);
                
                *sz = ztopo - (*sz);

                return ierr;
              }
              
            } // i
          } // j
        } // k

      } // i_tile
    } // j_tile
  } // k_tile

  return ierr;
}

/* 
 * find relative coord shift in this cell using sampling
 */

int
gd_curv_coord2shift_sample(float sx, float sy, float sz, 
    int num_points,
    float *points_x, // x coord of all points
    float *points_y,
    float *points_z,
    int    nx_sample,
    int    ny_sample,
    int    nz_sample,
    float *si_shift, // interped curv coord
    float *sj_shift,
    float *sk_shift)
{
  float Lx[2], Ly[2], Lz[2];

  // init closest point
  float min_dist = sqrtf(  (sx - points_x[0]) * (sx - points_x[0])
      + (sy - points_y[0]) * (sy - points_y[0])
      + (sz - points_z[0]) * (sz - points_z[0]) );
  int min_dist_i = 0 ;
  int min_dist_j = 0 ;
  int min_dist_k = 0 ;

  // linear interp for all sample
  for (int n3=0; n3<nz_sample+1; n3++)
  {
    Lz[1] = (float)(n3) / (float)(nz_sample);
    Lz[0] = 1.0 - Lz[1];
    for (int n2=0; n2<ny_sample+1; n2++)
    {
      Ly[1] = (float)(n2) / (float)(ny_sample);
      Ly[0] = 1.0 - Ly[1];
      for (int n1=0; n1<nx_sample+1; n1++)
      {
        Lx[1] = (float)(n1) / (float)(nx_sample);
        Lx[0] = 1.0 - Lx[1];

        // interp
        float x_pt=0;
        float y_pt=0;
        float z_pt=0;
        for (int kk=0; kk<2; kk++) {
          for (int jj=0; jj<2; jj++) {
            for (int ii=0; ii<2; ii++)
            {
              int iptr_cube = ii + jj * 2 + kk * 4;
              x_pt += Lx[ii]*Ly[jj]*Lz[kk] * points_x[iptr_cube];
              y_pt += Lx[ii]*Ly[jj]*Lz[kk] * points_y[iptr_cube];
              z_pt += Lx[ii]*Ly[jj]*Lz[kk] * points_z[iptr_cube];
            }
          }
        }

        // find min dist
        float DistInt = sqrtf(  (sx - x_pt) * (sx - x_pt)
            + (sy - y_pt) * (sy - y_pt)
            + (sz - z_pt) * (sz - z_pt) );

        // replace closest point
        if (min_dist > DistInt)
        {
          min_dist = DistInt;
          min_dist_i = n1;
          min_dist_j = n2;
          min_dist_k = n3;
        }
      } // n1
    } // n2
  } // n3

  *si_shift = (float)min_dist_i / (float)nx_sample;
  *sj_shift = (float)min_dist_j / (float)ny_sample;
  *sk_shift = (float)min_dist_k / (float)nz_sample;

  return 0;
}

/* 
 * find curv coord of cart coord using sampling
 */

int
gd_curv_coord2index_sample(float sx, float sy, float sz, 
    int num_points,
    float *points_x, // x coord of all points
    float *points_y,
    float *points_z,
    float *points_i, // curv coord of all points
    float *points_j,
    float *points_k,
    int    nx_sample,
    int    ny_sample,
    int    nz_sample,
    float *si_curv, // interped curv coord
    float *sj_curv,
    float *sk_curv)
{
  float Lx[2], Ly[2], Lz[2];

  // init closest point
  float min_dist = sqrtf(  (sx - points_x[0]) * (sx - points_x[0])
      + (sy - points_y[0]) * (sy - points_y[0])
      + (sz - points_z[0]) * (sz - points_z[0]) );
  int min_dist_i = 0 ;
  int min_dist_j = 0 ;
  int min_dist_k = 0 ;

  // linear interp for all sample
  for (int n3=0; n3<nz_sample+1; n3++)
  {
    Lz[1] = (float)(n3) / (float)(nz_sample);
    Lz[0] = 1.0 - Lz[1];
    for (int n2=0; n2<ny_sample+1; n2++)
    {
      Ly[1] = (float)(n2) / (float)(ny_sample);
      Ly[0] = 1.0 - Ly[1];
      for (int n1=0; n1<nx_sample+1; n1++)
      {
        Lx[1] = (float)(n1) / (float)(nx_sample);
        Lx[0] = 1.0 - Lx[1];

        // interp
        float x_pt=0;
        float y_pt=0;
        float z_pt=0;
        for (int kk=0; kk<2; kk++) {
          for (int jj=0; jj<2; jj++) {
            for (int ii=0; ii<2; ii++)
            {
              int iptr_cube = ii + jj * 2 + kk * 4;
              x_pt += Lx[ii]*Ly[jj]*Lz[kk] * points_x[iptr_cube];
              y_pt += Lx[ii]*Ly[jj]*Lz[kk] * points_y[iptr_cube];
              z_pt += Lx[ii]*Ly[jj]*Lz[kk] * points_z[iptr_cube];
            }
          }
        }

        // find min dist
        float DistInt = sqrtf(  (sx - x_pt) * (sx - x_pt)
            + (sy - y_pt) * (sy - y_pt)
            + (sz - z_pt) * (sz - z_pt) );

        // replace closest point
        if (min_dist > DistInt)
        {
          min_dist = DistInt;
          min_dist_i = n1;
          min_dist_j = n2;
          min_dist_k = n3;
        }
      } // n1
    } // n2
  } // n3

  *si_curv = points_i[0] + (float)min_dist_i / (float)nx_sample;
  *sj_curv = points_j[0] + (float)min_dist_j / (float)ny_sample;
  *sk_curv = points_k[0] + (float)min_dist_k / (float)nz_sample;

  return 0;
}

/* 
 * interp curv coord using inverse distance interp
 */

  int
gd_curv_coord2index_rdinterp(float sx, float sy, float sz, 
    int num_points,
    float *points_x, // x coord of all points
    float *points_y,
    float *points_z,
    float *points_i, // curv coord of all points
    float *points_j,
    float *points_k,
    float *si_curv, // interped curv coord
    float *sj_curv,
    float *sk_curv)
{
  float weight[num_points];
  float total_weight = 0.0 ;

  // cal weight
  int at_point_indx = -1;
  for (int i=0; i<num_points; i++)
  {
    float dist = sqrtf ((sx - points_x[i]) * (sx - points_x[i])
        + (sy - points_y[i]) * (sy - points_y[i])
        + (sz - points_z[i]) * (sz - points_z[i])
        );
    if (dist < 1e-9) {
      at_point_indx = i;
    } else {
      weight[i]   = 1.0 / dist;
      total_weight += weight[i];
    }
  }
  // if at a point
  if (at_point_indx > 0) {
    total_weight = 1.0;
    // other weight 0
    for (int i=0; i<num_points; i++) {
      weight[i] = 0.0;
    }
    // point weight 1
    weight[at_point_indx] = 1.0;
  }

  // interp

  *si_curv = 0.0;
  *sj_curv = 0.0;
  *sk_curv = 0.0;

  for (int i=0; i<num_points; i++)
  {
    weight[i] *= 1.0 / total_weight ;

    (*si_curv) += weight[i] * points_i[i];
    (*sj_curv) += weight[i] * points_j[i]; 
    (*sk_curv) += weight[i] * points_k[i];  

    fprintf(stdout,"---- i=%d,weight=%f,points_i=%f,points_j=%f,points_k=%f\n",
        i,weight[i],points_i[i],points_j[i],points_k[i]);
  }

  return 0;
}

float
gd_coord_get_x(gd_t *gd, int i, int j, int k)
{
  float var = 0.0;

  if (gd->type == GD_TYPE_CART)
  {
    var = gd->x1d[i];
  }
  else if (gd->type == GD_TYPE_CURV)
  {
    size_t iptr = i + j * gd->siz_line + k * gd->siz_slice;
    var = gd->x3d[iptr];
  }

  return var;
}

float
gd_coord_get_y(gd_t *gd, int i, int j, int k)
{
  float var = 0.0;

  if (gd->type == GD_TYPE_CART)
  {
    var = gd->y1d[j];
  }
  else if (gd->type == GD_TYPE_CURV)
  {
    size_t iptr = i + j * gd->siz_line + k * gd->siz_slice;
    var = gd->y3d[iptr];
  }

  return var;
}

float
gd_coord_get_z(gd_t *gd, int i, int j, int k)
{
  float var = 0.0;

  if (gd->type == GD_TYPE_CART)
  {
    var = gd->z1d[k];
  }
  else if (gd->type == GD_TYPE_CURV)
  {
    size_t iptr = i + j * gd->siz_line + k * gd->siz_slice;
    var = gd->z3d[iptr];
  }

  return var;
}

/*
 * Input: vx, vy, vz are the EIGHT vertexes of the hexahedron 
 *
 *    ↑ +z       4----6
 *    |         /|   /|
 *             / 0--/-2
 *            5----7 /
 *            |/   |/
 *            1----3
 *
 *
 */
// c++ version is coding by jiangluqian
// c cersion is coding by lihualin
int isPointInHexahedron_c(float px,  float py,  float pz,
                          float *vx, float *vy, float *vz)
{
  float point[3] = {px, py, pz};
	/* 
	 * Just for cgfd3D, in which the grid mesh maybe not a hexahedron,
	 */
  // order is back front left right top bottom 
  float hexa[6][3][3] = {
  {{vx[0], vy[0], vz[0]},{vx[4], vy[4], vz[4]},{vx[6], vy[6], vz[6]}},
  {{vx[7], vy[7], vz[7]},{vx[5], vy[5], vz[5]},{vx[1], vy[1], vz[1]}},
  {{vx[5], vy[5], vz[5]},{vx[4], vy[4], vz[4]},{vx[0], vy[0], vz[0]}},
  {{vx[2], vy[2], vz[2]},{vx[6], vy[6], vz[6]},{vx[7], vy[7], vz[7]}},
  {{vx[4], vy[4], vz[4]},{vx[5], vy[5], vz[5]},{vx[7], vy[7], vz[7]}},
  {{vx[3], vy[3], vz[3]},{vx[1], vy[1], vz[1]},{vx[0], vy[0], vz[0]}},
  };

/* 
 * Check whether the point is in the polyhedron.
 * Note: The hexahedron must be convex!
 */
  float sign = 0.0;
  float len_p2f = 0.0;
  float p2f[3] = {0};
  float normal_unit[3] = {0};
  for(int i=0; i<6; i++)
  {
    point2face(hexa[i][0],point,p2f); 
    face_normal(hexa[i],normal_unit);
    sign = fdlib_math_dot_product(p2f,normal_unit);
    len_p2f=sqrt(fdlib_math_dot_product(p2f,p2f));
    sign /= len_p2f;
    if(sign < 0.0) return 0;
  }
  return 1;
}

int point2face(float *hexa1d,float *point, float *p2f)
{
  for(int i=0; i<3; i++)
  {
    p2f[i] = hexa1d[i] - point[i];
  }
  return 0;
}

int face_normal(float (*hexa2d)[3], float *normal_unit)
{
  float A[3];
  float B[3];
  float normal[3]; // normal vector
  float length;
  for(int i=0;i<3;i++)
  {
    A[i] = hexa2d[1][i] - hexa2d[0][i];
    B[i] = hexa2d[2][i] - hexa2d[0][i];
  }
  // calculate normal vector
  fdlib_math_cross_product(A, B, normal);
  // Normalized the normal vector
  length = sqrt(fdlib_math_dot_product(normal, normal));
  for(int i=0; i<3; i++)
  {
    normal_unit[i] = normal[i] / length;
  }

  return 0;
}

int
gd_print(gd_t *gd, int verbose)
{
  fprintf(stdout, "\n-------------------------------------------------------\n");
  fprintf(stdout, "print grid structure info:\n");
  fprintf(stdout, "-------------------------------------------------------\n\n");

  if (gd->type == GD_TYPE_CART) {
    fprintf(stdout, " grid type is cartesian\n");
  } else if (gd->type == GD_TYPE_VMAP) {
    fprintf(stdout, " grid type is vmap\n");
  } else {
    fprintf(stdout, " grid type is general curvilinear\n");
  }

  fprintf(stdout," xmin=%g, xmax=%g\n", gd->xmin,gd->xmax);
  fprintf(stdout," ymin=%g, ymax=%g\n", gd->ymin,gd->ymax);
  fprintf(stdout," zmin=%g, zmax=%g\n", gd->zmin,gd->zmax);

  if (verbose > 9)
  {
    for (int k_tile = 0; k_tile < GD_TILE_NZ; k_tile++)
    {
      fprintf(stdout," tile k=%d, pt k in (%d,%d)\n",
                  k_tile, gd->tile_kstart[k_tile],gd->tile_kend[k_tile]);
    }
    for (int j_tile = 0; j_tile < GD_TILE_NY; j_tile++)
    {
      fprintf(stdout," tile j=%d, pt j in (%d,%d)\n",
                    j_tile, gd->tile_jstart[j_tile],gd->tile_jend[j_tile]);
    }
    for (int i_tile = 0; i_tile < GD_TILE_NX; i_tile++)
    {
      fprintf(stdout," tile i=%d, pt i in (%d,%d)\n",
                    i_tile, gd->tile_istart[i_tile],gd->tile_iend[i_tile]);
    }
  }

  if (verbose > 99)
  {
    for (int k_tile = 0; k_tile < GD_TILE_NZ; k_tile++)
    {
      for (int j_tile = 0; j_tile < GD_TILE_NY; j_tile++)
      {
        for (int i_tile = 0; i_tile < GD_TILE_NX; i_tile++)
        {
          fprintf(stdout," tile %d,%d,%d, range (%g,%g,%g,%g,%g,%g)\n",
            i_tile,j_tile,k_tile,
            gd->tile_xmin[k_tile][j_tile][i_tile],
            gd->tile_xmax[k_tile][j_tile][i_tile],
            gd->tile_ymin[k_tile][j_tile][i_tile],
            gd->tile_ymax[k_tile][j_tile][i_tile],
            gd->tile_zmin[k_tile][j_tile][i_tile],
            gd->tile_zmax[k_tile][j_tile][i_tile]);
        }
      }
    }
  }
  fflush(stdout);

  return 0;
}

int
gd_gather_global(gdinfo_t  *gdinfo, gd_t  *gd,  mympi_t *mympi)
{
  int ni = gdinfo->ni;
  int nj = gdinfo->nj;
  int nk = gdinfo->nk;
  int nx = gdinfo->nx;
  int ny = gdinfo->ny;
  int nz = gdinfo->nz;
  int n_ghost = gd->npoint_ghosts;
  int nprocx = mympi->nprocx;
  int nprocy = mympi->nprocy;
  int nproc = nprocx * nprocy;
  
  gd->displs  = (int *)malloc(nproc * sizeof(int));
  int *eachCount = NULL;
  eachCount = (int *)malloc(nproc * sizeof(int)); //each size of ni*nj*nk

  //cal displs
  int sendnum;
  sendnum = ni * nj * nk; 
  
  MPI_Allgather(&sendnum, 1, MPI_INT, eachCount , 1, MPI_INT, MPI_COMM_WORLD);  
  
  gd->displs[0] =0; 
  for(int i=1 ; i<nproc; i++){
    gd->displs[i] = gd->displs[i-1] + eachCount[i-1] ;
  }

  //gather whole grid
  gd->global_x3d =(float*)fdlib_mem_calloc_1d_float(
                  gdinfo->num_total_grid_x *gdinfo->num_total_grid_y*gdinfo->num_total_grid_z, -10.0, "gd_gather_global");
  gd->global_y3d =(float*)fdlib_mem_calloc_1d_float(
                  gdinfo->num_total_grid_x *gdinfo->num_total_grid_y*gdinfo->num_total_grid_z, -10.0, "gd_gather_global");
  gd->global_z3d =(float*)fdlib_mem_calloc_1d_float(
                  gdinfo->num_total_grid_x *gdinfo->num_total_grid_y*gdinfo->num_total_grid_z, -10.0, "gd_gather_global");

   //for save unordered value
  float *g_x3d =NULL;
  float *g_y3d =NULL;
  float *g_z3d =NULL;
  g_x3d =(float*)fdlib_mem_calloc_1d_float(
                  gdinfo->num_total_grid_x *gdinfo->num_total_grid_y*gdinfo->num_total_grid_z, -10.0, "gd_gather_global");
  g_y3d =(float*)fdlib_mem_calloc_1d_float(
                  gdinfo->num_total_grid_x *gdinfo->num_total_grid_y*gdinfo->num_total_grid_z, -10.0, "gd_gather_global");
  g_z3d =(float*)fdlib_mem_calloc_1d_float(
                  gdinfo->num_total_grid_x *gdinfo->num_total_grid_y*gdinfo->num_total_grid_z, -10.0, "gd_gather_global");
   //exclude ghost layer
  float *local_x3d = NULL;
  float *local_y3d = NULL;
  float *local_z3d = NULL;
  local_x3d = ( float * ) malloc( sizeof( float ) * ni * nj * nk );
  local_y3d = ( float * ) malloc( sizeof( float ) * ni * nj * nk );
  local_z3d = ( float * ) malloc( sizeof( float ) * ni * nj * nk ); 
  for (int k = 0; k < nk; k++)
  {
    for (int j = 0; j < nj; j++)
    {
      for (int i = 0; i < ni; i++)
      {
        //find iptr1
        int iptr1 = (k+n_ghost)*nx*ny + (j+n_ghost)*nx + (i+n_ghost);
        local_x3d[M_gd_INDEX(i, j, k, ni, nj)] = gd->x3d[iptr1];
        local_y3d[M_gd_INDEX(i, j, k, ni, nj)] = gd->y3d[iptr1];
        local_z3d[M_gd_INDEX(i, j, k, ni, nj)] = gd->z3d[iptr1];
      }
    }
  }

  
  MPI_Allgatherv(local_x3d , ni*nj*nk , MPI_FLOAT , g_x3d  , eachCount , gd->displs , MPI_FLOAT , MPI_COMM_WORLD);
  MPI_Allgatherv(local_y3d , ni*nj*nk , MPI_FLOAT , g_y3d  , eachCount , gd->displs , MPI_FLOAT , MPI_COMM_WORLD);
  MPI_Allgatherv(local_z3d , ni*nj*nk , MPI_FLOAT , g_z3d  , eachCount , gd->displs , MPI_FLOAT , MPI_COMM_WORLD);


  //// sort gd_global in right order(g_~3d -> g_~3d_ordered)
  gd->displs_ni    = (int *)malloc(nproc * sizeof(int));
  gd->displs_nj    = (int *)malloc(nproc * sizeof(int));//actually displs_nj is of no use in this func(useful in other func)

  gd->each_ni = (int *)malloc(nproc * sizeof(int));
  gd->each_nj = (int *)malloc(nproc * sizeof(int));
  int *eachCount_ni = gd->each_ni;
  int *eachCount_nj = gd->each_nj;

  MPI_Allgather(&ni , 1, MPI_INT, eachCount_ni, 1, MPI_INT, MPI_COMM_WORLD);
  MPI_Allgather(&nj , 1, MPI_INT, eachCount_nj, 1, MPI_INT, MPI_COMM_WORLD);

  for(int j=0 ; j<nprocy; j++){
    gd->displs_ni [j] =0;
    for(int i=1 ; i<nprocx; i++){
      gd->displs_ni[j + i*nprocy] = gd->displs_ni[j + (i-1)*nprocy] + eachCount_ni[j + (i-1)*nprocy] ;
    }
  }

  for(int i=0 ; i<nprocx; i++){
    gd->displs_nj [i*nprocy] =0;
    for(int j=1 ; j<nprocy; j++){
      gd->displs_nj[j + i*nprocy] = gd->displs_nj[(j-1) + i*nprocy] + eachCount_nj[(j-1) + i*nprocy] ;
    }
  }

  //order sequence, first each layer, then each block_line, then each block
  for(int k=0 ; k<nk ; k++)
  {
    size_t iptr_k = k*gdinfo->num_total_grid_x*gdinfo->num_total_grid_y;
    for(int n=0 ; n<nprocy ; n++)
    {
      for(int m=0 ; m<nprocx ; m++)
      {
        size_t block = m*nprocy + n;

        //in each block
        for(int j=0 ; j<eachCount_nj[block] ; j++)
        {
          for(int i=0 ; i<eachCount_ni[block] ; i++)
          {
            size_t iptr_order   = iptr_k + (gd->displs_nj[block]+j)*gdinfo->num_total_grid_x 
                                + gd->displs_ni[block] +i;
            size_t iptr_unorder = gd->displs[block] + k* eachCount_nj[block] *eachCount_ni[block] +j* eachCount_ni[block] +i;
            gd->global_x3d[iptr_order] = g_x3d [iptr_unorder];//g_x3d [iptr_unorder];
            gd->global_y3d[iptr_order] = g_y3d [iptr_unorder];
            gd->global_z3d[iptr_order] = g_z3d [iptr_unorder];
          }
        }
      }
    }
  }

  //check if global_gd is full
  for(int k=0 ; k<gdinfo->num_total_grid_z ; k++)
  {
    for(int j=0 ; j<gdinfo->num_total_grid_y ; j++)
    {
      for(int i=0 ; i<gdinfo->num_total_grid_x ; i++)
      {
        int iptr = k*gdinfo->num_total_grid_y*gdinfo->num_total_grid_x + j*gdinfo->num_total_grid_x + i;
        if(gd->global_x3d[iptr] ==-10 && gd->global_y3d[iptr] ==-10 && gd->global_z3d[iptr] ==-10){
          fprintf(stdout,"!!!!!!!  error   !!!!! \n something wrong when gather whole_gd in iptr %d\n",iptr);
          exit(-1);
        }
      }
    }
  }

  free(eachCount);
  free(g_x3d);
  free(g_y3d);
  free(g_z3d);
  free(local_x3d);
  free(local_y3d);
  free(local_z3d);
  return 0;

}


//find global neigh, then change to local block and iptr 
int
gd_find_neighbor_yang_from_yin(gdinfo_t  *gdinfo, gd_t  *gd, gd_t  *gd_n, mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  int siz_line  = gdinfo->siz_line;
  int siz_slice = gdinfo->siz_slice;


  gd->en_neigh_lociptr = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nz  ,size*size, -1, "en_neighbor_init");
  
  gd->en_neigh_block = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nz  ,size*size, -1, "en_neighbor_init");

  gd->en_neigh_iptrx = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "en_neighbor_init");
  gd->en_neigh_iptry = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "en_neighbor_init");   

  gd->coeff_en = (float **) fdlib_mem_calloc_2l_float( nx * ny * nz, size*size , 0.0, "coefficient of yinyang interp");                        
  

  if (mympi->neighid[0]==-1)
  {
    //x1 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj1; j<=nj2; j++)
      {
        for (int i=0; i<ni1; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_yinyang_ghost_neighbor(gdinfo ,gd, gd_n, mympi, iptr, k, size);
        }
      }
    }
  } 

  if (mympi->neighid[1]==-1)
  {
    //x2 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj1; j<=nj2; j++)
      {
        for (int i=ni2+1; i<nx; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_yinyang_ghost_neighbor(gdinfo ,gd, gd_n, mympi, iptr, k, size);
        }
      }
    }
  } 

  if (mympi->neighid[2]==-1)
  {
    //y1 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=0; j<nj1; j++)
      {
        for (int i=ni1; i<=ni2; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_yinyang_ghost_neighbor(gdinfo ,gd, gd_n, mympi, iptr, k, size);
        }
      }
    }
  } 

  if (mympi->neighid[3]==-1)
  {
    //y2 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj2+1; j<ny; j++)
      {
        for (int i=ni1; i<=ni2; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_yinyang_ghost_neighbor(gdinfo ,gd, gd_n, mympi, iptr, k, size);
        }
      }
    }
  } 


  return 0;
}

int
gd_func_for_yinyang_ghost_neighbor(gdinfo_t  *gdinfo ,gd_t  *gd, gd_t  *gd_n, mympi_t *mympi, int iptr, int k, int size)
{
  int *neigh_glob_x =  ( int * ) malloc( sizeof( int ) * size );
  int *neigh_glob_y =  ( int * ) malloc( sizeof( int ) * size );

  //in x order
  for (size_t ii =0; ii < gdinfo->num_total_grid_x ;ii++)
  {
    if (gd_n->x3d[iptr] <= gd->global_x3d[ii])
    {
      gd->en_neigh_iptrx[iptr] = ii;
      for (int m =0; m< size; m++) {
          neigh_glob_x[m] = ii-size/2+m;}

      break;
    } 
  }
  
  //in y order
  for (size_t jj =0; jj < gdinfo->num_total_grid_y ;jj++)
  {
    if (gd_n->y3d[iptr] <= gd->global_y3d[jj*gdinfo->num_total_grid_x])
    {
      gd->en_neigh_iptry[iptr] = jj;
      for (int n =0; n< size; n++) {
          neigh_glob_y[n] = jj-size/2+n;}

      break;
    }
  }
  //check if each neigh has found neigh
  if (gd->en_neigh_iptrx[iptr] ==-1 ) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n failed when find global_neigh_x in iptr %d\n",iptr);
    exit(-1);
  }
  if (gd->en_neigh_iptry[iptr] ==-1 ) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n failed when find global_neigh_y in iptr %d\n",iptr);
    exit(-1);
  }



  //change neigh_global to neigh_local
  int nghost = gdinfo->npoint_ghosts;
  int block_i,block_j;

  for (int n =0; n< size; n++)  
  {
    for (int m =0; m< size; m++)  
    {
      //search block
      for(int i=1 ; i<mympi->nprocx; i++)
      {
        if (neigh_glob_x[m] < gd->displs_ni[i*mympi->nprocy]){
          block_i  = i-1;
        break;}
        else{
          block_i = mympi->nprocx -1; }
      }

      for(int j=1 ; j<mympi->nprocy; j++)
      {
        if (neigh_glob_y[n] < gd->displs_nj[j]){
          block_j  = j-1;
        break;}
        else{
          block_j = mympi->nprocy -1; }
      }

      gd->en_neigh_block[iptr][m+size*n] = block_i*mympi->nprocy + block_j;
      
      //find local iptr, this iptr contains ghost points in each block
      int p = gd->en_neigh_block[iptr][m+size*n];
      int local_i = neigh_glob_x[m] - gd->displs_ni[p];
      int local_j = neigh_glob_y[n] - gd->displs_nj[p];
      int ni = gd->each_ni[p];
      int nj = gd->each_nj[p];
      int nx = ni + 2*nghost;
      int ny = nj + 2*nghost;
      gd->en_neigh_lociptr[iptr][m+size*n] = k*nx*ny + (local_j+nghost)*nx + (local_i+nghost);


    }
  }

  //cal interp coeffcient
  float *xArr   = ( float * ) malloc( sizeof( float ) * size *size );
  float *yArr   = ( float * ) malloc( sizeof( float ) * size *size );
  float *zArr   = ( float * ) malloc( sizeof( float ) * size *size );
  for (int j =0; j < size; j++)  
  {
    for (int i =0; i < size; i++) 
    { 
      int iptr_global = (k-nghost) *  gdinfo->num_total_grid_x * gdinfo->num_total_grid_y +
                        (gd->en_neigh_iptrx[iptr] -size/2) + (gd->en_neigh_iptry[iptr]-size/2)* gdinfo->num_total_grid_x;

      xArr[i + j * size] = gd->global_x3d[iptr_global + i + j*gdinfo->num_total_grid_x];
      yArr[i + j * size] = gd->global_y3d[iptr_global + i + j*gdinfo->num_total_grid_x];
      zArr[i + j * size] = gd->global_z3d[iptr_global + i + j*gdinfo->num_total_grid_x];
    }
  }
  Distance2D_coeff(gd_n->x3d[iptr], gd_n->y3d[iptr], gd_n->z3d[iptr], xArr, yArr, zArr, gd->coeff_en[iptr], size); 

  free(neigh_glob_x);
  free(neigh_glob_y);
  free(xArr);
  free(yArr);
  free(zArr);
  return 0;
}

void
Distance2D_coeff(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *coeff, int size) 
{
  float x0 = z*sin(y)*cos(x);
  float y0 = z*sin(y)*sin(x);
  float z0 = z*cos(y);


  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size );//-2 power of diatance
  for (int i = 0; i < size; i++) 
  {
    for (int j = 0; j < size; j++)
    {
      float x1 = zArr[i + j*size]*sin(yArr[i + j*size])*cos(xArr[i + j*size]);
      float y1 = zArr[i + j*size]*sin(yArr[i + j*size])*sin(xArr[i + j*size]);
      float z1 = zArr[i + j*size]*cos(yArr[i + j*size]);

      di[i + j*size] = (x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1) + (z0 - z1)*(z0 - z1);
      if (di[i + j*size] > 1e-10) {
      di[i + j*size] =1/di[i + j*size];
      }
      else{
      di[i + j*size] =1e10;
      }
      d_sum = d_sum + di[i + j*size];
    }
  }

  for (int i = 0; i < size; i++) 
  {
    for (int j = 0; j < size; j++)
    {
      coeff[i + j*size] = di[i + j*size] / d_sum ;
    }
  }

  free(di);
  
}


//find global neigh, then change to local block and iptr
//yin and yang can both use this func 
int
gd_find_neighbor_sphere_from_car(gdinfo_t  *gdinfo, gdinfo_t  *gdinfo_car, gd_t  *gd, gd_t  *gd_car, mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  int nghost = gdinfo->npoint_ghosts;
  int siz_line  = gdinfo->siz_line;
  int siz_slice = gdinfo->siz_slice;

  gd->sc_neigh_lociptr = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nghost  ,size*size*size, -1, "sc_neighbor_init");
  
  gd->sc_neigh_block = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nghost  ,size*size*size, -1, "sc_neighbor_init");

  gd->sc_neigh_iptrx = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nghost , -1, "sc_neighbor_init");
  gd->sc_neigh_iptry = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nghost , -1, "sc_neighbor_init");  
  gd->sc_neigh_iptrz = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nghost , -1, "sc_neighbor_init");  

  gd->coeff_sc = (float **) fdlib_mem_calloc_2l_float(nx * ny * nghost, size*size*size ,0.0,"coefficient sphere_car interp");  

  int *neigh_glob_x =  ( int * ) malloc( sizeof( int ) * size );
  int *neigh_glob_y =  ( int * ) malloc( sizeof( int ) * size );
  int *neigh_glob_z =  ( int * ) malloc( sizeof( int ) * size );

  float *xArr   = ( float * ) malloc( sizeof( float ) * size *size *size );
  float *yArr   = ( float * ) malloc( sizeof( float ) * size *size *size );
  float *zArr   = ( float * ) malloc( sizeof( float ) * size *size *size );

  for (size_t k = 0; k < nk1; k++) 
  {
    for (size_t j = nj1; j <= nj2; j++) 
    {
      for (size_t i = ni1; i <= ni2; i++) 
      {
        //get neigh_global
        size_t iptr = k * siz_slice + j * siz_line + i;
        float spherex = gd->z3d[iptr] * cos(gd->x3d[iptr]) * sin(gd->y3d[iptr]);
        float spherey = gd->z3d[iptr] * sin(gd->x3d[iptr]) * sin(gd->y3d[iptr]);
        float spherez = gd->z3d[iptr] * cos(gd->y3d[iptr]);

        for (size_t ii =0; ii < gdinfo_car->num_total_grid_x ;ii++)
        {
          if (spherex <= gd_car->global_x3d[ii])
          {
            gd->sc_neigh_iptrx[iptr] = ii;
            for (int m =0; m< size; m++) {
                neigh_glob_x[m] = ii-size/2+m;}

            break;
          }
        }

        for (size_t jj =0; jj < gdinfo_car->num_total_grid_y ;jj++)
        {
          if (spherey <= gd_car->global_y3d[jj*gdinfo_car->num_total_grid_x])
          {
            gd->sc_neigh_iptry[iptr] = jj;
            for (int m =0; m< size; m++) {
                neigh_glob_y[m] = jj-size/2+m;}

            break;
          }
        }

        for (size_t kk =0; kk < gdinfo_car->num_total_grid_z ;kk++)
        {
          if (spherez <= gd_car->global_z3d[kk*gdinfo_car->num_total_grid_x*gdinfo_car->num_total_grid_y])
          {
            gd->sc_neigh_iptrz[iptr] = kk;
            for (int m =0; m< size; m++) {
                neigh_glob_z[m] = kk-size/2+m;}

            break;
          }
        }

        //check if each neigh has found neigh
        if (gd->sc_neigh_iptrx[iptr] ==-1 ) {
          fprintf(stdout,"!!!!!!!  error   !!!!! \n sphere from car failed when find global_neigh_x in iptr %d\n",iptr);
          exit(-1);
        }
        if (gd->sc_neigh_iptry[iptr] ==-1 ) {
          fprintf(stdout,"!!!!!!!  error   !!!!! \n sphere from car failed when find global_neigh_y in iptr %d\n",iptr);
          exit(-1);
        }
        if (gd->sc_neigh_iptrz[iptr] ==-1 ) {
          fprintf(stdout,"!!!!!!!  error   !!!!! \n sphere from car failed when find global_neigh_z in iptr %d\n",iptr);
          exit(-1);
        }

        //change neigh_global to neigh_local
        int block_i,block_j;

        for (int mn =0; mn< size; mn++)  
        {
          for (int n =0; n< size; n++)  
          {
            for (int m =0; m< size; m++)  
            {
              //search block
              for(int proci=1 ; proci<mympi->nprocx; proci++)
              {
                if (neigh_glob_x[m] < gd_car->displs_ni[proci*mympi->nprocy]){
                  block_i  = proci-1;
                break;}
                else{
                  block_i = mympi->nprocx -1; }
              }

              for(int procj=1 ; procj<mympi->nprocy; procj++)
              {
                if (neigh_glob_y[n] < gd_car->displs_nj[procj]){
                  block_j  = procj-1;
                break;}
                else{
                  block_j = mympi->nprocy -1; }
              }

              gd->sc_neigh_block[iptr][m+size*n+size*size*mn] = block_i*mympi->nprocy + block_j;
              
              //find local iptr, this iptr contains ghost points in each block
              int p = gd->sc_neigh_block[iptr][m+size*n+size*size*mn];
              int local_i = neigh_glob_x[m] - gd_car->displs_ni[p];
              int local_j = neigh_glob_y[n] - gd_car->displs_nj[p];
              int local_k = neigh_glob_z[mn]; 
              int nii = gd_car->each_ni[p];
              int njj = gd_car->each_nj[p];
              int nxx = nii + 2*nghost;
              int nyy = njj + 2*nghost;
              gd->sc_neigh_lociptr[iptr][m+size*n+size*size*mn] = \
                nxx*nyy*(local_k + nghost) + (local_j+nghost)*nxx + (local_i+nghost);

            }
          }
        }


        //cal interp coeffcient for each point
        for (int kk =0; kk < size; kk++) 
        {
          for (int jj =0; jj < size; jj++) 
          {
            for (int ii =0; ii < size; ii++) 
            {
              int isize = ii + jj*size + kk*size*size;
              
              int iptr_global = (gd->sc_neigh_iptrz[iptr]-size/2) *gdinfo_car->num_total_grid_x *gdinfo_car->num_total_grid_y
                      + (gd->sc_neigh_iptrx[iptr] -size/2) + (gd->sc_neigh_iptry[iptr]-size/2)* gdinfo_car->num_total_grid_x;
              int iptr_g = iptr_global + ii + jj*gdinfo_car->num_total_grid_x + \
                          kk*gdinfo_car->num_total_grid_x*gdinfo_car->num_total_grid_y;
              xArr[isize] = gd_car->global_x3d[iptr_g];
              yArr[isize] = gd_car->global_y3d[iptr_g];
              zArr[isize] = gd_car->global_z3d[iptr_g];

            }
          }
        }
        
        Distance3D_sfromc_coeff(gd->x3d[iptr], gd->y3d[iptr], gd->z3d[iptr],xArr, yArr, zArr, gd->coeff_sc[iptr], size);

      }
    }
  }

  free(xArr);
  free(yArr);
  free(zArr);

  free(neigh_glob_x);
  free(neigh_glob_y);
  free(neigh_glob_z);

  return 0;
}

void
Distance3D_sfromc_coeff(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *coeff, int size)
{
  float x0 = z*sin(y)*cos(x);
  float y0 = z*sin(y)*sin(x);
  float z0 = z*cos(y);

  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size *size );//-2 power of diatance
  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        float x1 = xArr[isize];
        float y1 = yArr[isize];
        float z1 = zArr[isize];

        di[isize] = (x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1) + (z0 - z1)*(z0 - z1);
        if (di[isize] > 1e-10) {
        di[isize] =1/di[isize];
        }
        else{
        di[isize] =1e10;
        }
        d_sum = d_sum + di[isize];
      }
    }
  }

  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        coeff[isize] = di[isize] / d_sum ;
      }
    }
  }

  free(di);
}


//find global neigh, then change to local block and iptr
//first cal car from yin, then convert car from yang to car' from yin
int
gd_find_neighbor_car_from_sphere(gdinfo_t  *gdinfo, gdinfo_t  *gdinfo_car, gd_t  *gd, gd_t  *gd_car, mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int ni1 = gdinfo_car->ni1;
  int ni2 = gdinfo_car->ni2;
  int nj1 = gdinfo_car->nj1;
  int nj2 = gdinfo_car->nj2;
  int nk1 = gdinfo_car->nk1;
  int nk2 = gdinfo_car->nk2;
  int nx  = gdinfo_car->nx;
  int ny  = gdinfo_car->ny;
  int nz  = gdinfo_car->nz;
  int nghost = gdinfo->npoint_ghosts;
  int siz_line  = gdinfo_car->siz_line;
  int siz_slice = gdinfo_car->siz_slice;

  gd_car->ce_neigh_lociptr = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nz  ,size*size*size, -1, "ce_neighbor_init");
  
  gd_car->ce_neigh_block = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nz  ,size*size*size, -1, "ce_neighbor_init");

  gd_car->ce_neigh_iptrx = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "ce_neighbor_init");
  gd_car->ce_neigh_iptry = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "ce_neighbor_init");  
  gd_car->ce_neigh_iptrz = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "ce_neighbor_init");  

  gd_car->cn_neigh_lociptr = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nz  ,size*size*size, -1, "cn_neighbor_init");
  
  gd_car->cn_neigh_block = (int **) fdlib_mem_calloc_2l_int(
                   nx * ny * nz  ,size*size*size, -1, "cn_neighbor_init");

  gd_car->cn_neigh_iptrx = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "cn_neighbor_init");
  gd_car->cn_neigh_iptry = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "cn_neighbor_init");  
  gd_car->cn_neigh_iptrz = ( int * ) fdlib_mem_calloc_1d_int(nx * ny * nz , -1, "cn_neighbor_init"); 

  gd_car->coeff_cs = (float **) fdlib_mem_calloc_2l_float(nx * ny * nz, size*size*size ,0.0,"coefficient car_sphere interp");  


  if (mympi->neighid[0]==-1)
  {
    //x1 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj1; j<=nj2; j++)
      {
        for (int i=0; i<ni1; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_cs_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size);
        }
      }
    }
  } 

  if (mympi->neighid[1]==-1)
  {
    //x2 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj1; j<=nj2; j++)
      {
        for (int i=ni2+1; i<nx; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_cs_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size);
        }
      }
    }
  } 

  if (mympi->neighid[2]==-1)
  {
    //y1 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=0; j<nj1; j++)
      {
        for (int i=ni1; i<=ni2; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_cs_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size);
        }
      }
    }
  } 

  if (mympi->neighid[3]==-1)
  {
    //y2 
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj2+1; j<ny; j++)
      {
        for (int i=ni1; i<=ni2; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          gd_func_for_cs_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size);
        }
      }
    }
  } 

  //z1 and z2
  for (int k=0; k<nk1; k++)
  {
    for (int j=nj1; j<=nj2; j++)
    {
      for (int i=ni1; i<=ni2; i++)
      {
        size_t iptr = k * siz_slice + j * siz_line + i;
        gd_func_for_cs_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size);
      }
    }
  }

  for (int k=nk2+1; k<nz; k++)
  {
    for (int j=nj1; j<=nj2; j++)
    {
      for (int i=ni1; i<=ni2; i++)
      {
        size_t iptr = k * siz_slice + j * siz_line + i;
        gd_func_for_cs_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size);
      }
    }
  }



  return 0;
}

//cal each car point's neigh from sphere,both from yin or yang
int
gd_func_for_cs_ghost_neighbor(gdinfo_t *gdinfo ,gd_t *gd, gd_t *gd_car, mympi_t *mympi,int iptr,int size)
{
  int nx_sphere = gdinfo->num_total_grid_x;
  int ny_sphere = gdinfo->num_total_grid_y;
  float x = gd_car->x3d[iptr];
  float y = gd_car->y3d[iptr];
  float z = gd_car->z3d[iptr];

  float carr = sqrt(x*x + y*y + z*z);
  float carf = atan2(y,x); //-pi~pi
  float carc = acos(z/carr);
  
  //check if in yin range
   //not include gd_global boundary
  if (gd->global_x3d[size/2-1]< carf && carf <gd->global_x3d[nx_sphere-size/2] &&
      gd->global_y3d[(size/2-1)*nx_sphere]< carc && carc <gd->global_y3d[(ny_sphere-size/2)*nx_sphere] )
  {
    car_from_yin_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size, carf, carc, carr, gd_car->ce_neigh_iptrx,
                                gd_car->ce_neigh_iptry,gd_car->ce_neigh_iptrz,
                                gd_car->ce_neigh_block[iptr],gd_car->ce_neigh_lociptr[iptr]);
  }  
  else
  {
    x = -1* gd_car->x3d[iptr];
    y = gd_car->z3d[iptr];
    z = gd_car->y3d[iptr];//change to yang system
    carr = sqrt(x*x + y*y + z*z);
    carf = atan2(y,x); //-pi~pi
    carc = acos(z/carr);
    car_from_yin_ghost_neighbor(gdinfo , gd, gd_car, mympi, iptr, size, carf, carc, carr, gd_car->cn_neigh_iptrx,
                                gd_car->cn_neigh_iptry,gd_car->cn_neigh_iptrz,
                                gd_car->cn_neigh_block[iptr],gd_car->cn_neigh_lociptr[iptr]);
  }
  //considering each point has run car_from_yin func , the check of if point has neigh is enough.

  return 0;
}

int
car_from_yin_ghost_neighbor(gdinfo_t *gdinfo,gd_t *gd, gd_t *gd_car, 
                            mympi_t *mympi,int iptr,int size, float carf, float carc, float carr,
                            int *neigh_x, int *neigh_y, int *neigh_z,
                            int *neigh_block, int *neigh_lociptr )
{
  int *neigh_glob_x =  ( int * ) malloc( sizeof( int ) * size );
  int *neigh_glob_y =  ( int * ) malloc( sizeof( int ) * size );
  int *neigh_glob_z =  ( int * ) malloc( sizeof( int ) * size );

  //in x order
  for (size_t ii =0; ii < gdinfo->num_total_grid_x ;ii++)
  {
    if (carf <= gd->global_x3d[ii])
    {
      neigh_x[iptr] = ii;
      for (int m =0; m< size; m++) {
          neigh_glob_x[m] = ii-size/2+m;}

      break;
    } 
  }
  
  //in y order
  for (size_t jj =0; jj < gdinfo->num_total_grid_y ;jj++)
  {
    if (carc <= gd->global_y3d[jj*gdinfo->num_total_grid_x])
    {
      neigh_y[iptr] = jj;
      for (int n =0; n< size; n++) {
          neigh_glob_y[n] = jj-size/2+n;}

      break;
    }
  }

  //in z order
  for (size_t kk =0; kk < gdinfo->num_total_grid_z ;kk++)
  {
    int iptr_local = kk*gdinfo->num_total_grid_x*gdinfo->num_total_grid_y + \
                     neigh_y[iptr]*gdinfo->num_total_grid_x + neigh_x[iptr];
    if (carr <= gd->global_z3d[iptr_local])
    {
      neigh_z[iptr] = kk;
      for (int mn =0; mn< size; mn++) {
          neigh_glob_z[mn] = kk-size/2+mn;}

      break;
    }
  }

  //check if each neigh has found neigh
  if (neigh_x[iptr] ==-1 ) {
    fprintf(stdout,"myid = %d,carf = %f, carc = %f, carr = %f\n",mympi->myid,carf,carc,carr);
    fprintf(stdout,"!!!!!!!  error   !!!!! \n failed when find global_neigh_x in iptr %d (car from yin)\n",iptr);
    exit(-1);
  }
  if (neigh_y[iptr] ==-1 ) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n failed when find global_neigh_y in iptr %d (car from yin)\n",iptr);
    exit(-1);
  }
  if (neigh_z[iptr] ==-1 ) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n failed when find global_neigh_z in iptr %d (car from yin)\n",iptr);
    exit(-1);
  }


  //change neigh_global to neigh_local
  int nghost = gdinfo->npoint_ghosts;
  int block_i,block_j;

  for (int mn =0; mn< size; mn++)  
  {
    for (int n =0; n< size; n++)  
    {
      for (int m =0; m< size; m++)  
      {
        //search block
        for(int i=1 ; i<mympi->nprocx; i++)
        {
          if (neigh_glob_x[m] < gd->displs_ni[i*mympi->nprocy]){
            block_i  = i-1;
          break;}
          else{
            block_i = mympi->nprocx -1; }
        }

        for(int j=1 ; j<mympi->nprocy; j++)
        {
          if (neigh_glob_y[n] < gd->displs_nj[j]){
            block_j  = j-1;
          break;}
          else{
            block_j = mympi->nprocy -1; }
        }

        neigh_block[m+size*n+size*size*mn] = block_i*mympi->nprocy + block_j;
        
        //find local iptr, this iptr contains ghost points in each block
        int p = neigh_block[m+size*n+size*size*mn];
        int local_i = neigh_glob_x[m] - gd->displs_ni[p];
        int local_j = neigh_glob_y[n] - gd->displs_nj[p];
        int local_k = neigh_glob_z[mn];
        int ni = gd->each_ni[p];
        int nj = gd->each_nj[p];
        int nx = ni + 2*nghost;
        int ny = nj + 2*nghost;
        neigh_lociptr[m+size*n+size*size*mn] = (local_k+nghost)*nx*ny + (local_j+nghost)*nx + (local_i+nghost);

      }
    }
  }

  float *xArr   = ( float * ) malloc( sizeof( float ) * size *size *size );
  float *yArr   = ( float * ) malloc( sizeof( float ) * size *size *size );
  float *zArr   = ( float * ) malloc( sizeof( float ) * size *size *size );
  for (int k =0; k < size; k++) 
  {
    for (int j =0; j < size; j++) 
    {
      for (int i =0; i < size; i++) 
      {
        int isize = i + j*size + k*size*size;
        //car get from yin

        int iptr_global = (neigh_z[iptr]-size/2) *  gdinfo->num_total_grid_x * gdinfo->num_total_grid_y +
                (neigh_x[iptr] -size/2) + (neigh_y[iptr]-size/2)* gdinfo->num_total_grid_x;
        int iptr_g = iptr_global + i + j*gdinfo->num_total_grid_x + k*gdinfo->num_total_grid_x*gdinfo->num_total_grid_y;
        xArr[isize] = gd->global_x3d[iptr_g];
        yArr[isize] = gd->global_y3d[iptr_g];
        zArr[isize] = gd->global_z3d[iptr_g];
        
      }
    }
  }
  
  ///xxx include if judge
  float xxx = carr * sin(carc) * cos(carf);
  float yyy = carr * sin(carc) * sin(carf);
  float zzz = carr * cos(carc);
  Distance3D_cfroms_coeff(xxx, yyy, zzz, xArr, yArr, zArr, gd_car->coeff_cs[iptr], size); 

  free(neigh_glob_x);
  free(neigh_glob_y);
  free(neigh_glob_z);
  free(xArr);
  free(yArr);
  free(zArr);
  return 0;

}


void
Distance3D_cfroms_coeff(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *coeff, int size)
{

  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size *size );//-2 power of diatance
  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        float x1 = zArr[isize]*sin(yArr[isize])*cos(xArr[isize]);
        float y1 = zArr[isize]*sin(yArr[isize])*sin(xArr[isize]);
        float z1 = zArr[isize]*cos(yArr[isize]);

        di[isize] = (x - x1)*(x - x1) + (y - y1)*(y - y1) + (z - z1)*(z - z1);
        if (di[isize] > 1e-10) {
        di[isize] =1/di[isize];
        }
        else{
        di[isize] =1e10;
        }
        d_sum = d_sum + di[isize];
      }
    }
  }

  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        coeff[isize] = di[isize] / d_sum ;
      }
    }
  }

  free(di);
}

//yinyang is the same,so only cal yang from yin
//this func get 'yang recv_from yin'/'yin send_to yang', each block of how many points and which iptr
int
gd_gather_ghost_global_en(gd_t  *gd,gdinfo_t  *gdinfo,mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  int nghost  = gdinfo->npoint_ghosts;
  int siz_line  = gdinfo->siz_line;
  int siz_slice = gdinfo->siz_slice;
  int nprocx = mympi->nprocx;
  int nprocy = mympi->nprocy;
  int nproc  = nprocx * nprocy;
  int nx_glob = gdinfo->num_total_grid_x + nghost*2*nprocx; 
  int ny_glob = gdinfo->num_total_grid_y + nghost*2*nprocy; 

  int *neigh_block = ( int * ) malloc( sizeof( int ) * nx * ny * nz *size *size );//change from 2D to 1D
  int *neigh_iptr  = ( int * ) malloc( sizeof( int ) * nx * ny * nz *size *size );
  for (size_t k = 0; k < nz; k++) 
  {
    for (size_t j = 0; j < ny; j++) 
    {
      for (size_t i = 0; i < nx; i++) 
      { 
        size_t iptr = k * siz_slice + j * siz_line + i;
        for (int n =0; n < size; n++)  {
          for (int m =0; m < size; m++) {
            neigh_block[size*size*iptr + m+size*n ] = gd->en_neigh_block[iptr][m+size*n];
            neigh_iptr [size*size*iptr + m+size*n ] = gd->en_neigh_lociptr[iptr][m+size*n];
          }
        }
      }
    }
  }

  //gather whole ghost points(yang)
  int *displs = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count  = ( int * ) malloc( sizeof( int ) * nproc );
  for(int i=0 ; i<nproc; i++){
    Count[i]  = (gd->each_ni[i] + 2*nghost)* (gd->each_nj[i] + 2*nghost) * nz * size *size;
  }
  displs[0] =0; 
  for(int i=1 ; i<nproc; i++){
    displs[i] = displs[i-1] + Count[i-1] ;
  }


  int *global_neigh_block = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nz *size *size );
  int *global_neigh_iptr  = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nz *size *size );

  MPI_Allgatherv(neigh_block , nx * ny * nz *size *size , MPI_INT , global_neigh_block  ,
                 Count ,displs, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(neigh_iptr ,  nx * ny * nz *size *size , MPI_INT , global_neigh_iptr  ,
                 Count ,displs, MPI_INT , MPI_COMM_WORLD);

  //get block belongs of glob_ghost_points to get recv goal
   //cal recv points' local block and iptr
  int *global_itself_block = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nz *size *size );

  for(int iptr =0;iptr < nx_glob * ny_glob * nz *size *size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs[i]){
      global_itself_block[iptr] = i-1;
      break;}
      else{
      global_itself_block[iptr] = nproc-1; }
    }
  } 

  //find relationship of send_recv
  gd->myblock2block_niptr_en   = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " en_myblock send to block");     
  gd->block2myblock_niptr_en   = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " en_myblock send to block");  

  //(yin) send
  for(int iptr =0;iptr <nx_glob * ny_glob * nz *size *size;iptr ++)
  {
    if (global_neigh_block[iptr]==mympi->myid){ //need myblock
      gd->myblock2block_niptr_en[global_itself_block[iptr]] ++ ;
    }
  }

  //(yang) recv
  for (size_t k = 0; k < nz; k++) 
  {
    for (size_t j = 0; j < ny; j++) 
    {
      for (size_t i = 0; i < nx; i++) 
      { 
        size_t iptr = k * siz_slice + j * siz_line + i;
        for (int n =0; n < size; n++)  {
          for (int m =0; m < size; m++) {
            for(int iblock=0 ; iblock<nproc; iblock++)
              {
                if (gd->en_neigh_block[iptr][m+size*n] ==iblock)
                {
                  gd->block2myblock_niptr_en[iblock] ++ ;
                }
              }
          }
        }
      }
    }
  }
   
  free(neigh_block);
  free(neigh_iptr);


  //check which iptr in myid to which iptr in each block
  int send_niptr_max = 1;

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    if (gd->myblock2block_niptr_en[iblock] >= send_niptr_max)
    send_niptr_max = gd->myblock2block_niptr_en[iblock];
  }

  gd->en_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "en_local_send_init");//which my iptr to every block
  gd->en_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "en_local_send_init");//each point to a block's which iptrmn
  int **en_send2iptrglobal = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "en_local_send_init");//temporary,need change to block+iptr+m+n       

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    size_t iptr_p = 0;
    for (size_t i = 0;i < nx_glob * ny_glob * nz *size *size; i++)
    {
      if(global_itself_block[i] == iblock && global_neigh_block[i] == mympi->myid)
      //ghost points in iblock and need myid's send 
      {
        en_send2iptrglobal[iblock][iptr_p] = i;
        gd->en_myiptr_send[iblock][iptr_p] = global_neigh_iptr[i];
        iptr_p ++;
      }
    }
    
    //check if all points are found
    if (iptr_p != gd->myblock2block_niptr_en[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find yinyang send error when block %d to block %d,only send %d points, not enough of %d points\n",
              mympi->myid,iblock,iptr_p,gd->myblock2block_niptr_en[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd->myblock2block_niptr_en[iblock]; iptr++) 
    {
      //find block    ok,actually yin_send2block = iblock
      int yin_send2block;

      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (en_send2iptrglobal[iblock][iptr]< displs[iproc]){
          yin_send2block = iproc-1;
          break;}
        else{
          yin_send2block = nproc-1; }
      }
      //find iptr
      gd->en_send2iptrmn[iblock][iptr] = en_send2iptrglobal[iblock][iptr]- displs[yin_send2block];
      

      //check if iptrmn < size of block_recv
      if (gd->en_send2iptrmn[iblock][iptr] >= Count[yin_send2block])
      {
        fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
        fprintf(stdout,"myid %d, yinyang send to iptrmn = %d, is bigger than size of this block[%d]=%d\n",
                mympi->myid,gd->en_send2iptrmn[iblock][iptr],yin_send2block,Count[yin_send2block]);// error
        exit(-1);
      }
     
      //check one example if iptrmn is right
//      if(mympi->myid == 6)
//      fprintf(stdout,"myid[%d] send to NO.%d block[%d], NO %d is to iptrmn %d\n",
//                mympi->myid,iblock,yin_send2block, iptr, gd->en_send2iptrmn[iblock][iptr]);// error

    }
  }     

  free(displs);
  free(Count);
  free(global_neigh_block);
  free(global_neigh_iptr);
  free(global_itself_block);   
  for(int i=0;i<nproc;i++)
	{
		free(en_send2iptrglobal[i]);
	}
	free(en_send2iptrglobal);
                  


  return 0;
}


//cal yin and car
//first cal num_send/recv(sphere from car, then car from sphere), the cal which iptr
int
gd_gather_ghost_global_ce(gd_t  *gd,gdinfo_t  *gdinfo,gd_t  *gd_car,gdinfo_t  *gdinfo_car,mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int nprocx = mympi->nprocx;
  int nprocy = mympi->nprocy;
  int nproc  = nprocx * nprocy;
  int nghost  = gdinfo->npoint_ghosts;

  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;

  int nii1 = gdinfo_car->ni1;
  int nii2 = gdinfo_car->ni2;
  int njj1 = gdinfo_car->nj1;
  int njj2 = gdinfo_car->nj2;
  int nkk1 = gdinfo_car->nk1;
  int nkk2 = gdinfo_car->nk2;
  int nxx  = gdinfo_car->nx;
  int nyy  = gdinfo_car->ny;
  int nzz  = gdinfo_car->nz;

  int siz_line  = gdinfo->siz_line;
  int siz_slice = gdinfo->siz_slice;
  int nx_glob = gdinfo->num_total_grid_x + nghost*2*nprocx; 
  int ny_glob = gdinfo->num_total_grid_y + nghost*2*nprocy; 

  int siz_line_car  = gdinfo_car->siz_line;
  int siz_slice_car = gdinfo_car->siz_slice;
  int nxx_glob = gdinfo_car->num_total_grid_x + nghost*2*nprocx; 
  int nyy_glob = gdinfo_car->num_total_grid_y + nghost*2*nprocy; 

  //get num_points of send/recv to/from each block of yin/car
  /////////////////////////sphere from car/////////////////
  int *neigh_block_sphere = ( int * ) malloc( sizeof( int ) * nx * ny * nghost *size *size *size );//change from 2D to 1D
  int *neigh_iptr_sphere  = ( int * ) malloc( sizeof( int ) * nx * ny * nghost *size *size *size );
  for (size_t k = 0; k < nghost; k++) 
  {
    for (size_t j = 0; j < ny; j++) 
    {
      for (size_t i = 0; i < nx; i++) 
      { 
        size_t iptr = k * siz_slice + j * siz_line + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              int iptr_new = size*size*size*iptr + size*size*mn + size*n + m;
              neigh_block_sphere[iptr_new] = gd->sc_neigh_block[iptr][m+size*n+size*size*mn];
              neigh_iptr_sphere [iptr_new] = gd->sc_neigh_lociptr[iptr][m+size*n+size*size*mn];
            }
          }
        }
      }
    }
  }

  //gather whole ghost points
  int *displs_sphere = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count_sphere  = ( int * ) malloc( sizeof( int ) * nproc );
  for(int i=0 ; i<nproc; i++){
    Count_sphere[i]  = (gd->each_ni[i] + 2*nghost)* (gd->each_nj[i] + 2*nghost) * nghost * size *size *size;
  }
  displs_sphere[0] =0; 
  for(int i=1 ; i<nproc; i++){
    displs_sphere[i] = displs_sphere[i-1] + Count_sphere[i-1] ;
  }


  int *global_neigh_block_sphere = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nghost *size *size *size);
  int *global_neigh_iptr_sphere  = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nghost *size *size *size);

  MPI_Allgatherv(neigh_block_sphere , nx * ny * nghost *size *size *size , MPI_INT , global_neigh_block_sphere  ,
                 Count_sphere ,displs_sphere, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(neigh_iptr_sphere ,  nx * ny * nghost *size *size *size , MPI_INT , global_neigh_iptr_sphere  ,
                 Count_sphere ,displs_sphere, MPI_INT , MPI_COMM_WORLD);

  //get block belongs of glob_ghost_points to get recv goal
   //cal recv points' local block and iptr
  int *global_itself_block_sphere = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nghost *size *size *size);

  for(int iptr =0;iptr < nx_glob * ny_glob * nghost *size *size *size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs_sphere[i]){
      global_itself_block_sphere[iptr] = i-1;
      break;}
      else{
      global_itself_block_sphere[iptr] = nproc-1; }
    }
  } 

  //find relationship of send_recv
  gd->myblock2block_niptr_sphere   = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " sphere_myblock send to block");     
  gd->block2myblock_niptr_sphere   = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " sphere_myblock send to block");  
  gd_car->myblock2block_niptr_caryin  = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " car_myblock send to block");     
  gd_car->block2myblock_niptr_caryin  = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " car_myblock send to block");  

  //car send
  for(int iptr =0;iptr <nx_glob * ny_glob * nghost * size *size *size;iptr ++)
  {
    if (global_neigh_block_sphere[iptr]==mympi->myid){ //need myblock
      gd_car->myblock2block_niptr_caryin[global_itself_block_sphere[iptr]] ++ ;
    }
  }

  //sphere recv
  for (size_t k = 0; k < nghost; k++) 
  {
    for (size_t j = 0; j < ny; j++) 
    {
      for (size_t i = 0; i < nx; i++) 
      { 
        size_t iptr = k * siz_slice + j * siz_line + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              for(int iblock=0 ; iblock<nproc; iblock++)
              {
                if (gd->sc_neigh_block[iptr][m+size*n+size*size*mn] ==iblock)
                {
                  gd->block2myblock_niptr_sphere[iblock] ++ ;
                }
              }
            }
          }
        }
      }
    }
  }


  ////////////////////////car from sphere///////////////////////
  int *neigh_block_car = ( int * ) malloc( sizeof( int ) * nxx * nyy * nzz *size *size *size );//change from 2D to 1D
  int *neigh_iptr_car  = ( int * ) malloc( sizeof( int ) * nxx * nyy * nzz *size *size *size );
  for (size_t k = 0; k < nzz; k++) 
  {
    for (size_t j = 0; j < nyy; j++) 
    {
      for (size_t i = 0; i < nxx; i++) 
      { 
        size_t iptr = k * siz_slice_car + j * siz_line_car + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              int iptr_new = size*size*size*iptr + size*size*mn + size*n + m;
              neigh_block_car[iptr_new] = gd_car->ce_neigh_block[iptr][m+size*n+size*size*mn];
              neigh_iptr_car [iptr_new] = gd_car->ce_neigh_lociptr[iptr][m+size*n+size*size*mn];
            }
          }
        }
      }
    }
  }

  //gather whole ghost points
  int *displs_car = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count_car  = ( int * ) malloc( sizeof( int ) * nproc );
  for(int i=0 ; i<nproc; i++){
    Count_car[i]  = (gd_car->each_ni[i] + 2*nghost)* (gd_car->each_nj[i] + 2*nghost) * nzz * size *size *size;
  }
  displs_car[0] =0; 
  for(int i=1 ; i<nproc; i++){
    displs_car[i] = displs_car[i-1] + Count_car[i-1] ;
  }


  int *global_neigh_block_car = ( int * ) malloc( sizeof( int ) * nxx_glob * nyy_glob * nzz *size *size *size);
  int *global_neigh_iptr_car  = ( int * ) malloc( sizeof( int ) * nxx_glob * nyy_glob * nzz *size *size *size);

  MPI_Allgatherv(neigh_block_car , nxx * nyy * nzz *size *size *size , MPI_INT , global_neigh_block_car  ,
                 Count_car ,displs_car, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(neigh_iptr_car ,  nxx * nyy * nzz *size *size *size , MPI_INT , global_neigh_iptr_car  ,
                 Count_car ,displs_car, MPI_INT , MPI_COMM_WORLD);

  //get block belongs of glob_ghost_points to get recv goal
   //cal recv points' local block and iptr
  int *global_itself_block_car = ( int * ) malloc( sizeof( int ) * nxx_glob * nyy_glob * nzz *size *size *size);

  for(int iptr =0;iptr < nxx_glob * nyy_glob * nzz *size *size *size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs_car[i]){
      global_itself_block_car[iptr] = i-1;
      break;}
      else{
      global_itself_block_car[iptr] = nproc-1; }
    }
  } 

  //find relationship of send_recv
  //sphere send
  for(int iptr =0;iptr <nxx_glob * nyy_glob * nzz * size *size *size;iptr ++)
  {
    if (global_neigh_block_car[iptr]==mympi->myid){ //need myblock
      gd->myblock2block_niptr_sphere[global_itself_block_car[iptr]] ++ ;
    }
  }

  //car recv
  for (size_t k = 0; k < nzz; k++) 
  {
    for (size_t j = 0; j < nyy; j++) 
    {
      for (size_t i = 0; i < nxx; i++) 
      { 
        size_t iptr = k * siz_slice_car + j * siz_line_car + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              for(int iblock=0 ; iblock<nproc; iblock++)
              {
                if (gd_car->ce_neigh_block[iptr][m+size*n+size*size*mn] ==iblock)
                {
                  gd_car->block2myblock_niptr_caryin[iblock] ++ ;
                }
              }
            }
          }
        }
      }
    }
  }



  //check which iptr in car myid to which iptr in each block of sphere
  /////////////////////////sphere from car/////////////////
  int send_niptr_max = 1;

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    if (gd_car->myblock2block_niptr_caryin[iblock] >= send_niptr_max)
    send_niptr_max = gd_car->myblock2block_niptr_caryin[iblock];
  }

  gd_car->car2e_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "car_local_send_init");//which my iptr to every block
  gd_car->car2e_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "car_local_send_init");//each point to a block's which iptrmn
  int **car_send2iptrglobal = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "car_local_send_init");//temporary,need change to block+iptr+m+n       

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    size_t iptr_p = 0;
    for (size_t i = 0;i < nx_glob * ny_glob * nghost *size *size *size; i++)
    {
      if(global_itself_block_sphere[i] == iblock && global_neigh_block_sphere[i] == mympi->myid)
      //ghost points in iblock and need myid's send 
      {
        car_send2iptrglobal[iblock][iptr_p] = i;
        gd_car->car2e_myiptr_send[iblock][iptr_p] = global_neigh_iptr_sphere[i];
        iptr_p ++;
      }
    }
    
    //check if all points are found
    if (iptr_p != gd_car->myblock2block_niptr_caryin[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find car send to yin error when block %d to block %d,only send %d points, not enough of %d points\n",
              mympi->myid,iblock,iptr_p,gd_car->myblock2block_niptr_caryin[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd_car->myblock2block_niptr_caryin[iblock]; iptr++) 
    {
      //find block
      int car_send2block;

      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (car_send2iptrglobal[iblock][iptr]< displs_sphere[iproc]){
          car_send2block = iproc-1;
          break;}
        else{
          car_send2block = nproc-1; }
      }
      //find iptr
      gd_car->car2e_send2iptrmn[iblock][iptr] = car_send2iptrglobal[iblock][iptr]- displs_sphere[car_send2block];

      //check if iptrmn < size of block_recv
      if (gd_car->car2e_send2iptrmn[iblock][iptr] >= Count_sphere[car_send2block])
      {
        fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
        fprintf(stdout,"myid %d, car2yin send to iptrmn = %d, is bigger than size of this block[%d]=%d\n",
                mympi->myid,gd_car->car2e_send2iptrmn[iblock][iptr],car_send2block,Count_sphere[car_send2block]);// error
        exit(-1);
      }

    }
  }    

  /////////////////////////car from sphere/////////////////
  send_niptr_max = 1;
  for (int iblock = 0; iblock < nproc; iblock++)
  {
    if (gd->myblock2block_niptr_sphere[iblock] >= send_niptr_max)
    send_niptr_max = gd->myblock2block_niptr_sphere[iblock];
  }

  gd->sphere_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "sphere_local_send_init");//which my iptr to every block
  gd->sphere_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "sphere_local_send_init");//each point to a block's which iptrmn
  int **sphere_send2iptrglobal = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "sphere_local_send_init");//temporary,need change to block+iptr+m+n       

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    size_t iptr_p = 0;
    for (size_t i = 0;i < nxx_glob * nyy_glob * nzz *size *size *size; i++)
    {
      if(global_itself_block_car[i] == iblock && global_neigh_block_car[i] == mympi->myid)
      //ghost points in iblock and need myid's send 
      {
        sphere_send2iptrglobal[iblock][iptr_p] = i;
        gd->sphere_myiptr_send[iblock][iptr_p] = global_neigh_iptr_car[i];
        iptr_p ++;
      }
    }
    
    //check if all points are found
    if (iptr_p != gd->myblock2block_niptr_sphere[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find sphere send to car error when block %d to block %d,only send %d points, not enough of %d points\n",
              mympi->myid,iblock,iptr_p,gd->myblock2block_niptr_sphere[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd->myblock2block_niptr_sphere[iblock]; iptr++) 
    {
      //find block
      int sphere_send2block;

      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (sphere_send2iptrglobal[iblock][iptr]< displs_car[iproc]){
          sphere_send2block = iproc-1;
          break;}
        else{
          sphere_send2block = nproc-1; }
      }
      //find iptr
      gd->sphere_send2iptrmn[iblock][iptr] = sphere_send2iptrglobal[iblock][iptr]- displs_car[sphere_send2block];

      //check if iptrmn < size of block_recv
      if (gd->sphere_send2iptrmn[iblock][iptr] >= Count_car[sphere_send2block])
      {
        fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
        fprintf(stdout,"myid %d, yin2car send to iptrmn = %d, is bigger than size of this block[%d]=%d\n",
                mympi->myid,gd->sphere_send2iptrmn[iblock][iptr],sphere_send2block,Count_car[sphere_send2block]);// error
        exit(-1);
      }
    }
  }    

  

  free(neigh_block_sphere);
  free(neigh_iptr_sphere);
  free(displs_sphere);
  free(Count_sphere);
  free(global_itself_block_sphere);
  free(global_neigh_block_sphere);
  free(global_neigh_iptr_sphere);
  for(int i=0;i<nproc;i++)
	{
		free(sphere_send2iptrglobal[i]);
	}
	free(sphere_send2iptrglobal);
  
  free(neigh_block_car);
  free(neigh_iptr_car);
  free(displs_car);
  free(Count_car);
  free(global_itself_block_car);
  free(global_neigh_block_car);
  free(global_neigh_iptr_car);
  for(int i=0;i<nproc;i++)
	{
		free(car_send2iptrglobal[i]);
	}
	free(car_send2iptrglobal);
  return 0;
}

//similar to gd_gather_ghost_global_ce, only change variable_name of gd_car:change yin to yang 
int
gd_gather_ghost_global_cn(gd_t  *gd,gdinfo_t  *gdinfo,gd_t  *gd_car,gdinfo_t  *gdinfo_car,mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int nprocx = mympi->nprocx;
  int nprocy = mympi->nprocy;
  int nproc  = nprocx * nprocy;
  int nghost  = gdinfo->npoint_ghosts;

  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;

  int nii1 = gdinfo_car->ni1;
  int nii2 = gdinfo_car->ni2;
  int njj1 = gdinfo_car->nj1;
  int njj2 = gdinfo_car->nj2;
  int nkk1 = gdinfo_car->nk1;
  int nkk2 = gdinfo_car->nk2;
  int nxx  = gdinfo_car->nx;
  int nyy  = gdinfo_car->ny;
  int nzz  = gdinfo_car->nz;

  int siz_line  = gdinfo->siz_line;
  int siz_slice = gdinfo->siz_slice;
  int nx_glob = gdinfo->num_total_grid_x + nghost*2*nprocx; 
  int ny_glob = gdinfo->num_total_grid_y + nghost*2*nprocy; 

  int siz_line_car  = gdinfo_car->siz_line;
  int siz_slice_car = gdinfo_car->siz_slice;
  int nxx_glob = gdinfo_car->num_total_grid_x + nghost*2*nprocx; 
  int nyy_glob = gdinfo_car->num_total_grid_y + nghost*2*nprocy; 

  //get num_points of send/recv to/from each block of yin/car
  /////////////////////////sphere from car/////////////////
  int *neigh_block_sphere = ( int * ) malloc( sizeof( int ) * nx * ny * nghost *size *size *size );//change from 2D to 1D
  int *neigh_iptr_sphere  = ( int * ) malloc( sizeof( int ) * nx * ny * nghost *size *size *size );
  for (size_t k = 0; k < nghost; k++) 
  {
    for (size_t j = 0; j < ny; j++) 
    {
      for (size_t i = 0; i < nx; i++) 
      { 
        size_t iptr = k * siz_slice + j * siz_line + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              int iptr_new = size*size*size*iptr + size*size*mn + size*n + m;
              neigh_block_sphere[iptr_new] = gd->sc_neigh_block[iptr][m+size*n+size*size*mn];
              neigh_iptr_sphere [iptr_new] = gd->sc_neigh_lociptr[iptr][m+size*n+size*size*mn];
            }
          }
        }
      }
    }
  }

  //gather whole ghost points
  int *displs_sphere = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count_sphere  = ( int * ) malloc( sizeof( int ) * nproc );
  for(int i=0 ; i<nproc; i++){
    Count_sphere[i]  = (gd->each_ni[i] + 2*nghost)* (gd->each_nj[i] + 2*nghost) * nghost * size *size *size;
  }
  displs_sphere[0] =0; 
  for(int i=1 ; i<nproc; i++){
    displs_sphere[i] = displs_sphere[i-1] + Count_sphere[i-1] ;
  }


  int *global_neigh_block_sphere = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nghost *size *size *size);
  int *global_neigh_iptr_sphere  = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nghost *size *size *size);

  MPI_Allgatherv(neigh_block_sphere , nx * ny * nghost *size *size *size , MPI_INT , global_neigh_block_sphere  ,
                 Count_sphere ,displs_sphere, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(neigh_iptr_sphere ,  nx * ny * nghost *size *size *size , MPI_INT , global_neigh_iptr_sphere  ,
                 Count_sphere ,displs_sphere, MPI_INT , MPI_COMM_WORLD);

  //get block belongs of glob_ghost_points to get recv goal
   //cal recv points' local block and iptr
  int *global_itself_block_sphere = ( int * ) malloc( sizeof( int ) * nx_glob * ny_glob * nghost *size *size *size);

  for(int iptr =0;iptr < nx_glob * ny_glob * nghost *size *size *size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs_sphere[i]){
      global_itself_block_sphere[iptr] = i-1;
      break;}
      else{
      global_itself_block_sphere[iptr] = nproc-1; }
    }
  } 

  //find relationship of send_recv
  gd->myblock2block_niptr_sphere   = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " sphere_myblock send to block");     
  gd->block2myblock_niptr_sphere   = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " sphere_myblock send to block");  
  gd_car->myblock2block_niptr_caryang  = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " car_myblock send to block");     
  gd_car->block2myblock_niptr_caryang  = ( int * ) fdlib_mem_calloc_1d_int(nproc , 0, " car_myblock send to block");  

  //car send
  for(int iptr =0;iptr <nx_glob * ny_glob * nghost * size *size *size;iptr ++)
  {
    if (global_neigh_block_sphere[iptr]==mympi->myid){ //need myblock
      gd_car->myblock2block_niptr_caryang[global_itself_block_sphere[iptr]] ++ ;
    }
  }

  //sphere recv
  for (size_t k = 0; k < nghost; k++) 
  {
    for (size_t j = 0; j < ny; j++) 
    {
      for (size_t i = 0; i < nx; i++) 
      { 
        size_t iptr = k * siz_slice + j * siz_line + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              for(int iblock=0 ; iblock<nproc; iblock++)
              {
                if (gd->sc_neigh_block[iptr][m+size*n+size*size*mn] ==iblock)
                {
                  gd->block2myblock_niptr_sphere[iblock] ++ ;
                }
              }
            }
          }
        }
      }
    }
  }


  ////////////////////////car from sphere///////////////////////
  int *neigh_block_car = ( int * ) malloc( sizeof( int ) * nxx * nyy * nzz *size *size *size );//change from 2D to 1D
  int *neigh_iptr_car  = ( int * ) malloc( sizeof( int ) * nxx * nyy * nzz *size *size *size );
  for (size_t k = 0; k < nzz; k++) 
  {
    for (size_t j = 0; j < nyy; j++) 
    {
      for (size_t i = 0; i < nxx; i++) 
      { 
        size_t iptr = k * siz_slice_car + j * siz_line_car + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              int iptr_new = size*size*size*iptr + size*size*mn + size*n + m;
              neigh_block_car[iptr_new] = gd_car->cn_neigh_block[iptr][m+size*n+size*size*mn];
              neigh_iptr_car [iptr_new] = gd_car->cn_neigh_lociptr[iptr][m+size*n+size*size*mn];
            }
          }
        }
      }
    }
  }

  //gather whole ghost points
  int *displs_car = ( int * ) malloc( sizeof( int ) * nproc );
  int *Count_car  = ( int * ) malloc( sizeof( int ) * nproc );
  for(int i=0 ; i<nproc; i++){
    Count_car[i]  = (gd_car->each_ni[i] + 2*nghost)* (gd_car->each_nj[i] + 2*nghost) * nzz * size *size *size;
  }
  displs_car[0] =0; 
  for(int i=1 ; i<nproc; i++){
    displs_car[i] = displs_car[i-1] + Count_car[i-1] ;
  }


  int *global_neigh_block_car = ( int * ) malloc( sizeof( int ) * nxx_glob * nyy_glob * nzz *size *size *size);
  int *global_neigh_iptr_car  = ( int * ) malloc( sizeof( int ) * nxx_glob * nyy_glob * nzz *size *size *size);

  MPI_Allgatherv(neigh_block_car , nxx * nyy * nzz *size *size *size , MPI_INT , global_neigh_block_car  ,
                 Count_car ,displs_car, MPI_INT , MPI_COMM_WORLD);
  MPI_Allgatherv(neigh_iptr_car ,  nxx * nyy * nzz *size *size *size , MPI_INT , global_neigh_iptr_car  ,
                 Count_car ,displs_car, MPI_INT , MPI_COMM_WORLD);

  //get block belongs of glob_ghost_points to get recv goal
   //cal recv points' local block and iptr
  int *global_itself_block_car = ( int * ) malloc( sizeof( int ) * nxx_glob * nyy_glob * nzz *size *size *size);

  for(int iptr =0;iptr < nxx_glob * nyy_glob * nzz *size *size *size;iptr ++)
  {
    for(int i=1 ; i<nproc; i++)
    {
      if (iptr < displs_car[i]){
      global_itself_block_car[iptr] = i-1;
      break;}
      else{
      global_itself_block_car[iptr] = nproc-1; }
    }
  } 

  //find relationship of send_recv
  //sphere send
  for(int iptr =0;iptr <nxx_glob * nyy_glob * nzz * size *size *size;iptr ++)
  {
    if (global_neigh_block_car[iptr]==mympi->myid){ //need myblock
      gd->myblock2block_niptr_sphere[global_itself_block_car[iptr]] ++ ;
    }
  }

  //car recv
  for (size_t k = 0; k < nzz; k++) 
  {
    for (size_t j = 0; j < nyy; j++) 
    {
      for (size_t i = 0; i < nxx; i++) 
      { 
        size_t iptr = k * siz_slice_car + j * siz_line_car + i;
        for (int mn =0; mn < size; mn++)  {
          for (int n =0; n < size; n++)  {
            for (int m =0; m < size; m++) {
              for(int iblock=0 ; iblock<nproc; iblock++)
              {
                if (gd_car->cn_neigh_block[iptr][m+size*n+size*size*mn] ==iblock)
                {
                  gd_car->block2myblock_niptr_caryang[iblock] ++ ;
                }
              }
            }
          }
        }
      }
    }
  }



  //check which iptr in car myid to which iptr in each block of sphere
  /////////////////////////sphere from car/////////////////
  int send_niptr_max = 1;

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    if (gd_car->myblock2block_niptr_caryang[iblock] >= send_niptr_max)
    send_niptr_max = gd_car->myblock2block_niptr_caryang[iblock];
  }

  gd_car->car2n_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "car_local_send_init");//which my iptr to every block
  gd_car->car2n_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "car_local_send_init");//each point to a block's which iptrmn
  int **car_send2iptrglobal = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "car_local_send_init");//temporary,need change to block+iptr+m+n       

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    size_t iptr_p = 0;
    for (size_t i = 0;i < nx_glob * ny_glob * nghost *size *size *size; i++)
    {
      if(global_itself_block_sphere[i] == iblock && global_neigh_block_sphere[i] == mympi->myid)
      //ghost points in iblock and need myid's send 
      {
        car_send2iptrglobal[iblock][iptr_p] = i;
        gd_car->car2n_myiptr_send[iblock][iptr_p] = global_neigh_iptr_sphere[i];
        iptr_p ++;
      }
    }
    
    //check if all points are found
    if (iptr_p != gd_car->myblock2block_niptr_caryang[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find car send to yin error when block %d to block %d,only send %d points, not enough of %d points\n",
              mympi->myid,iblock,iptr_p,gd_car->myblock2block_niptr_caryang[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd_car->myblock2block_niptr_caryang[iblock]; iptr++) 
    {
      //find block
      int car_send2block;

      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (car_send2iptrglobal[iblock][iptr]< displs_sphere[iproc]){
          car_send2block = iproc-1;
          break;}
        else{
          car_send2block = nproc-1; }
      }
      //find iptr
      gd_car->car2n_send2iptrmn[iblock][iptr] = car_send2iptrglobal[iblock][iptr]- displs_sphere[car_send2block];
 
      //check if iptrmn < size of block_recv
      if (gd_car->car2n_send2iptrmn[iblock][iptr] >= Count_sphere[car_send2block])
      {
        fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
        fprintf(stdout,"myid %d, car2yang send to iptrmn = %d, is bigger than size of this block[%d]=%d\n",
                mympi->myid,gd_car->car2n_send2iptrmn[iblock][iptr],car_send2block,Count_sphere[car_send2block]);// error
        exit(-1);
      }

    }
  }    

  /////////////////////////car from sphere/////////////////
  send_niptr_max = 1;
  for (int iblock = 0; iblock < nproc; iblock++)
  {
    if (gd->myblock2block_niptr_sphere[iblock] >= send_niptr_max)
    send_niptr_max = gd->myblock2block_niptr_sphere[iblock];
  }

  gd->sphere_myiptr_send = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "sphere_local_send_init");//which my iptr to every block
  gd->sphere_send2iptrmn = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "sphere_local_send_init");//each point to a block's which iptrmn
  int **sphere_send2iptrglobal = (int **) fdlib_mem_calloc_2l_int(
                   nproc ,send_niptr_max, -1, "sphere_local_send_init");//temporary,need change to block+iptr+m+n       

  for (int iblock = 0; iblock < nproc; iblock++)
  {
    size_t iptr_p = 0;
    for (size_t i = 0;i < nxx_glob * nyy_glob * nzz *size *size *size; i++)
    {
      if(global_itself_block_car[i] == iblock && global_neigh_block_car[i] == mympi->myid)
      //ghost points in iblock and need myid's send 
      {
        sphere_send2iptrglobal[iblock][iptr_p] = i;
        gd->sphere_myiptr_send[iblock][iptr_p] = global_neigh_iptr_car[i];
        
/*        //check print
        if(mympi->myid == 7)
        {
          fprintf(stdout,"gd_n's block_7 send to car[%d]'s NO.%d point is myiptr %d\n",
                  iblock,iptr_p,gd->sphere_myiptr_send[iblock][iptr_p]);
        }
*/        
        iptr_p ++;
      }
    }
    
    //check if all points are found
    if (iptr_p != gd->myblock2block_niptr_sphere[iblock])
    {
      fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
      fprintf(stdout,"find sphere send to car error when block %d to block %d,only send %d points, not enough of %d points\n",
              mympi->myid,iblock,iptr_p,gd->myblock2block_niptr_sphere[iblock]);// error
      exit(-1);
    }

    //change i to block + iptrmn
    for (size_t iptr = 0; iptr < gd->myblock2block_niptr_sphere[iblock]; iptr++) 
    {
      //find block
      int sphere_send2block;

      for(int iproc=1 ; iproc<nproc; iproc++)
      {
        if (sphere_send2iptrglobal[iblock][iptr]< displs_car[iproc]){
          sphere_send2block = iproc-1;
          break;}
        else{
          sphere_send2block = nproc-1; }
      }
      //find iptr
      gd->sphere_send2iptrmn[iblock][iptr] = sphere_send2iptrglobal[iblock][iptr]- displs_car[sphere_send2block];
      
/*      //check print
      if(mympi->myid == 7)
      {
        fprintf(stdout,"gd_n's block_7 send to car[%d]'s NO.%d point is to iptr %d\n",
                iblock,iptr,gd->sphere_send2iptrmn[iblock][iptr]);
      }
*/

      //check if iptrmn < size of block_recv
      if (gd->sphere_send2iptrmn[iblock][iptr] >= Count_car[sphere_send2block])
      {
        fprintf(stdout,"!!!!!!!  error   !!!!! \n"); 
        fprintf(stdout,"myid %d, yang2car send to iptrmn = %d, is bigger than size of this block[%d]=%d\n",
                mympi->myid,gd->sphere_send2iptrmn[iblock][iptr],sphere_send2block,Count_car[sphere_send2block]);// error
        exit(-1);
      }
    }
  }    

  

  free(neigh_block_sphere);
  free(neigh_iptr_sphere);
  free(displs_sphere);
  free(Count_sphere);
  free(global_itself_block_sphere);
  free(global_neigh_block_sphere);
  free(global_neigh_iptr_sphere);
  for(int i=0;i<nproc;i++)
	{
		free(sphere_send2iptrglobal[i]);
	}
	free(sphere_send2iptrglobal);
  
  free(neigh_block_car);
  free(neigh_iptr_car);
  free(displs_car);
  free(Count_car);
  free(global_itself_block_car);
  free(global_neigh_block_car);
  free(global_neigh_iptr_car);
  for(int i=0;i<nproc;i++)
	{
		free(car_send2iptrglobal[i]);
	}
	free(car_send2iptrglobal);
  return 0;
}























