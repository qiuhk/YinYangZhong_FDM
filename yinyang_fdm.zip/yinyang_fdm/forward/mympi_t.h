#ifndef MY_MPI_H
#define MY_MPI_H

#include <mpi.h>

#include "constants.h"

/*******************************************************************************
 * structure
 ******************************************************************************/

typedef struct {
  int       nprocx;
  int       nprocy;

  int       myid;
  MPI_Comm  comm;

  int    topoid[2];
  //int    neighid[4];
  int    neighid[CONST_NDIM_2];
  MPI_Comm    topocomm;

  size_t siz_sbuff;
  size_t siz_rbuff;
  float *sbuff;
  float *rbuff;

  size_t siz_ssbuff;
  size_t siz_rrbuff;
  float *ssbuff;
  float *rrbuff;
  
  size_t siz_sbuffn;
  size_t siz_rbuffn;
  float *sbuffn;
  float *rbuffn;

  // for col scheme
  MPI_Request r_reqs[4];
  MPI_Request s_reqs[4];

  // for stg,cart
  MPI_Request r_reqs_vel[4];
  MPI_Request s_reqs_vel[4];
  MPI_Request r_reqs_stress[4];
  MPI_Request s_reqs_stress[4];

  // for macdrp
  size_t **pair_siz_sbuff_x1;
  size_t **pair_siz_sbuff_x2;
  size_t **pair_siz_sbuff_y1;
  size_t **pair_siz_sbuff_y2;
  size_t **pair_siz_rbuff_x1;
  size_t **pair_siz_rbuff_x2;
  size_t **pair_siz_rbuff_y1;
  size_t **pair_siz_rbuff_y2;
  MPI_Request ***pair_r_reqs;
  MPI_Request ***pair_s_reqs;

  size_t **pair_siz_sbuff_xx1;
  size_t **pair_siz_sbuff_xx2;
  size_t **pair_siz_sbuff_yy1;
  size_t **pair_siz_sbuff_yy2;
  size_t **pair_siz_rbuff_xx1;
  size_t **pair_siz_rbuff_xx2;
  size_t **pair_siz_rbuff_yy1;
  size_t **pair_siz_rbuff_yy2;
  MPI_Request ***pair_rr_reqs;
  MPI_Request ***pair_ss_reqs;

  size_t **pair_siz_sbuff_x1n;
  size_t **pair_siz_sbuff_x2n;
  size_t **pair_siz_sbuff_y1n;
  size_t **pair_siz_sbuff_y2n;
  size_t **pair_siz_rbuff_x1n;
  size_t **pair_siz_rbuff_x2n;
  size_t **pair_siz_rbuff_y1n;
  size_t **pair_siz_rbuff_y2n;
  MPI_Request ***pair_r_reqsn;
  MPI_Request ***pair_s_reqsn;

  //for interp (3 means include 3 grid)
  float *sbuff3;
  float *rbuff3;
  MPI_Request *pair_r_reqs3;
  MPI_Request *pair_s_reqs3;
  int *siz_send; //points_number of send to each block,inculde 6 pairs 
  int *siz_recv;

} mympi_t;

/*******************************************************************************
 * function prototype
 ******************************************************************************/

int
mympi_set(mympi_t *mympi,
          int number_of_mpiprocs_x,
          int number_of_mpiprocs_y,
          MPI_Comm comm, 
          const int myid, const int verbose);

void
mympi_print(mympi_t *mympi);

#endif
