/*******************************************************************************
 * solver of isotropic elastic 1st-order eqn using curv grid and macdrp schem
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mpi.h>
#include <time.h>

#include "fdlib_mem.h"
#include "fdlib_math.h"
#include "blk_t.h"
#include "sv_curv_col.h"
#include "sv_curv_col_ac_iso.h"
#include "sv_curv_col_el_iso.h"
#include "sv_curv_col_el_vti.h"
#include "sv_curv_col_el_aniso.h"

//#define SV_ELISO1ST_CURV_MACDRP_DEBUG

/*******************************************************************************
 * one simulation over all time steps, could be used in imaging or inversion
 *  simple MPI exchange without computing-communication overlapping
 ******************************************************************************/

void
sv_curv_col_allstep(
  fd_t            *fd,
  gd_t            *gd,
  gd_t            *gd_n,
  gd_t            *gd_car,
  gdinfo_t        *gdinfo,
  gdinfo_t        *gdinfo_n,
  gdinfo_t        *gdinfo_car,
  gdcurv_metric_t *metric,
  gdcurv_metric_t *metric_n,
  md_t      *md,
  md_t      *md_n,
  md_t      *md_car,
  src_t      *src,
  bdryfree_t *bdryfree,
  bdryfree_t *bdryfree_n,
  bdrypml_t  *bdrypml,
  wav_t  *wav,
  wav_t  *wav_n,
  wav_t  *wav_car,
  mympi_t    *mympi,
  iorecv_t   *iorecv,
  ioline_t   *ioline,
  ioslice_t  *ioslice,
  iosnap_t   *iosnap,
  // time
  float dt, int nt_total, float t0,
  char *output_fname_part,
  char *output_dir,
  int qc_check_nan_num_of_step,
  const int output_all, // qc all var
  const int verbose)
{
  // retrieve from struct
  int num_rk_stages = fd->num_rk_stages;
  float *rk_a = fd->rk_a;
  float *rk_b = fd->rk_b;

  int num_of_pairs     = fd->num_of_pairs;
  int fdx_max_half_len = fd->fdx_max_half_len;
  int fdy_max_half_len = fd->fdy_max_half_len;
  int fdz_max_len      = fd->fdz_max_len;
  int num_of_fdz_op    = fd->num_of_fdz_op;

  // mpi
  int myid = mympi->myid;
  int *topoid = mympi->topoid;
  MPI_Comm comm = mympi->comm;
  float *restrict sbuff = mympi->sbuff;
  float *restrict rbuff = mympi->rbuff;
  float *restrict sbuffn = mympi->sbuffn;
  float *restrict rbuffn = mympi->rbuffn;
  float *restrict ssbuff = mympi->ssbuff;
  float *restrict rrbuff = mympi->rrbuff;

  float *restrict sbuff3 = mympi->sbuff3;
  float *restrict rbuff3 = mympi->rbuff3;

  // local allocated array
  char ou_file[CONST_MAX_STRLEN];

  // local pointer
  float *restrict w_cur;
  float *restrict w_pre;
  float *restrict w_rhs;
  float *restrict w_end;
  float *restrict w_tmp;

  float *restrict w_cur_n;
  float *restrict w_pre_n;
  float *restrict w_rhs_n;
  float *restrict w_end_n;
  float *restrict w_tmp_n;

  float *restrict w_cur_car;
  float *restrict w_pre_car;
  float *restrict w_rhs_car;
  float *restrict w_end_car;
  float *restrict w_tmp_car;

  int   ipair, istage;
  float t_cur;
  float t_end; // time after this loop for nc output
  // for mpi message
  int   ipair_mpi, istage_mpi;

  // create slice nc output files
  if (myid==0 && verbose>0) fprintf(stdout,"prepare slice nc output ...\n"); 
  ioslice_nc_t ioslice_nc;
  io_slice_nc_create(ioslice, wav->ncmp, wav->cmp_name,
                     gdinfo->ni, gdinfo->nj, gdinfo->nk, topoid,
                     &ioslice_nc);

  // create snapshot nc output files
  if (myid==0 && verbose>0) fprintf(stdout,"prepare snap nc output ...\n"); 
  iosnap_nc_t  iosnap_nc;
  if (md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO) {
    io_snap_nc_create_ac(iosnap, &iosnap_nc, topoid);
  } else {
    io_snap_nc_create(iosnap, gdinfo, gdinfo_n, gdinfo_car, &iosnap_nc, topoid);
  }

  // only x/y mpi
  int num_of_r_reqs = 4;
  int num_of_s_reqs = 4;
  int nproc = mympi->nprocx*mympi->nprocy;

  // get wavefield
  w_pre = wav->v5d + (wav->siz_ilevel)  * 0; // previous level at n
  w_tmp = wav->v5d + (wav->siz_ilevel)  * 1; // intermidate value
  w_rhs = wav->v5d + (wav->siz_ilevel)  * 2; // for rhs
  w_end = wav->v5d + (wav->siz_ilevel)  * 3; // end level at n+1

  w_pre_n = wav_n->v5d + (wav_n->siz_ilevel)  * 0; // previous level at n
  w_tmp_n = wav_n->v5d + (wav_n->siz_ilevel)  * 1; // intermidate value
  w_rhs_n = wav_n->v5d + (wav_n->siz_ilevel)  * 2; // for rhs
  w_end_n = wav_n->v5d + (wav_n->siz_ilevel)  * 3; // end level at n+1

  w_pre_car = wav_car->v5d + (wav_car->siz_ilevel)  * 0; // previous level at n
  w_tmp_car = wav_car->v5d + (wav_car->siz_ilevel)  * 1; // intermidate value
  w_rhs_car = wav_car->v5d + (wav_car->siz_ilevel)  * 2; // for rhs
  w_end_car = wav_car->v5d + (wav_car->siz_ilevel)  * 3; // end level at n+1
  
  float *w_realn = NULL;
  w_realn= (float *) fdlib_mem_calloc_1d_float(wav_n->siz_ilevel,
                        0.0, "for_save_real_value_in_yang_grid");

  int size = gdinfo->size_of_interp;
  wav->storage_sphere   = (float **) fdlib_mem_calloc_2l_float( wav->ncmp, gdinfo->siz_volume*
                                  size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");
  wav_n->storage_sphere = (float **) fdlib_mem_calloc_2l_float( wav->ncmp, gdinfo_n->siz_volume*
                                  size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st"); 
  wav->storage     = (float **) fdlib_mem_calloc_2l_float( wav->ncmp, gdinfo->siz_slice*gdinfo->npoint_ghosts*
                                  size*size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");                                                               
  wav_n->storage   = (float **) fdlib_mem_calloc_2l_float( wav->ncmp, gdinfo_n->siz_slice*gdinfo_n->npoint_ghosts*
                                  size*size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");
  wav_car->storage = (float **) fdlib_mem_calloc_2l_float( wav->ncmp, gdinfo_car->siz_volume*
                                  size*size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");                                                         

  // alloc free surface PGV PGA and PGD
  float *PG = NULL;
  // Dis_accu is Displacemen accumulation, be uesd for PGD calculaton.
  float *Dis_accu = NULL;
  if (bdryfree->is_at_sides[CONST_NDIM-1][1] == 1)
  {
    PG = (float *) fdlib_mem_calloc_1d_float(CONST_NDIM_3*gdinfo->ny*gdinfo->nx,0.0,"PG malloc");
    Dis_accu = (float *) fdlib_mem_calloc_1d_float(CONST_NDIM*gdinfo->ny*gdinfo->nx,0.0,"Dis_accu malloc");
  }
  // calculate conversion matrix for free surface
  if (bdryfree->is_at_sides[CONST_NDIM-1][1] == 1)
  {
    if (md->medium_type == CONST_MEDIUM_ELASTIC_ISO)
    {
      sv_curv_col_el_iso_dvh2dvz(gd, gdinfo,metric,md,bdryfree,verbose);
      sv_curv_col_el_iso_dvh2dvz(gd, gdinfo_n,metric_n,md_n,bdryfree_n,verbose);
    }
    else if (md->medium_type == CONST_MEDIUM_ELASTIC_VTI)
    {
      sv_curv_col_el_vti_dvh2dvz(gdinfo,metric,md,bdryfree,verbose);
    }
    else if (md->medium_type == CONST_MEDIUM_ELASTIC_ANISO)
    {
      sv_curv_col_el_aniso_dvh2dvz(gdinfo,metric,md,bdryfree,verbose);
    }
    else if (md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO)
    {
      // no need
    }
    else
    {
      fprintf(stderr,"ERROR: conversion matrix for medium_type=%d is not implemented\n",
                    md->medium_type);
      MPI_Abort(MPI_COMM_WORLD,1);
    }
  }

  //--------------------------------------------------------
  // time loop
  //--------------------------------------------------------
  clock_t begintime,endtime;
  if (myid==0 && verbose>0) fprintf(stdout,"start time loop ...\n"); 

  for (int it=0; it<nt_total; it++)
  {
   // time_t t_start1 = time(NULL);

    begintime=clock();

    t_cur  = it * dt + t0;
    t_end = t_cur +dt;

    if (myid==0 && verbose>10) fprintf(stdout,"-> it=%d, t=%f\n", it, t_cur);

    // mod to get ipair
    ipair = it % num_of_pairs;
    if (myid==0 && verbose>10) fprintf(stdout, " --> ipair=%d\n",ipair);

    // loop RK stages for one step
    for (istage=0; istage<num_rk_stages; istage++)
    {
      if (myid==0 && verbose>10) fprintf(stdout, " --> istage=%d\n",istage);

      // for mesg
      if (istage != num_rk_stages-1) {
        ipair_mpi = ipair;
        istage_mpi = istage + 1;
      } else {
        ipair_mpi = (it + 1) % num_of_pairs;
        istage_mpi = 0; 
      }

      // use pointer to avoid 1 copy for previous level value
      if (istage==0) {
        w_cur = w_pre;
        w_cur_n = w_pre_n;
        w_cur_car = w_pre_car;
      }
      else
      {
        w_cur = w_tmp;
        w_cur_n = w_tmp_n;
        w_cur_car = w_tmp_car;
      }

      // set src_t time
      src_set_time(src, it, istage);

      //change ghost point's value
      wave_changevalue_ghost(gdinfo,gd, wav,gdinfo_n,gd_n, wav_n,gdinfo_car,gd_car, wav_car,\
                             w_cur, w_cur_n, w_cur_car, mympi);

      // compute rhs
      switch (md->medium_type)
      {
        case CONST_MEDIUM_ELASTIC_ISO : {
          sv_curv_col_el_iso_onestage(
              w_cur,w_rhs,w_cur_n,w_rhs_n,w_cur_car,w_rhs_car,
              wav,wav_n,wav_car,gd,gd_n,gd_car,
              gdinfo, gdinfo_n, gdinfo_car, metric, metric_n, md,md_n,md_car, bdryfree, bdryfree_n, bdrypml, src,
              fd->num_of_fdx_op, fd->pair_fdx_op[ipair][istage],
              fd->num_of_fdy_op, fd->pair_fdy_op[ipair][istage],
              fd->num_of_fdz_op, fd->pair_fdz_op[ipair][istage],
              fd->fdz_max_len,
              myid, verbose); 

          break;
        }

      }

      
      // recv mesg
      MPI_Startall(num_of_r_reqs, mympi->pair_r_reqs[ipair_mpi][istage_mpi]);
      MPI_Startall(num_of_r_reqs, mympi->pair_r_reqsn[ipair_mpi][istage_mpi]);
      MPI_Startall(num_of_r_reqs, mympi->pair_rr_reqs[ipair_mpi][istage_mpi]);
      MPI_Startall(nproc, mympi->pair_r_reqs3);

      // rk start
      if (istage==0)
      {
        float coef_a = rk_a[istage] * dt;
        float coef_b = rk_b[istage] * dt;

        // wavefield
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_tmp[iptr] = w_pre[iptr] + coef_a * w_rhs[iptr];
        }
        for (size_t iptr=0; iptr < wav_n->siz_ilevel; iptr++) {
            w_tmp_n[iptr] = w_pre_n[iptr] + coef_a * w_rhs_n[iptr];
        }
        for (size_t iptr=0; iptr < wav_car->siz_ilevel; iptr++) {
            w_tmp_car[iptr] = w_pre_car[iptr] + coef_a * w_rhs_car[iptr];
        }

        // apply Qs
        //if (md->visco_type == CONST_VISCO_GRAVES_QS) {
        //  sv_curv_graves_Qs(w_tmp, wave->ncmp, gdinfo, md);
        //}

        // pack and isend
        blk_macdrp_pack_mesg(w_tmp, sbuff, wav->ncmp, gdinfo, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));
        blk_macdrp_pack_mesg(w_tmp_n, sbuffn, wav->ncmp, gdinfo_n, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));                 
        blk_macdrp_pack_mesg(w_tmp_car, ssbuff, wav->ncmp, gdinfo_car, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));
        blk_macdrp_pack_mesg_interp(w_tmp,w_tmp_n,w_tmp_car, sbuff3, wav->ncmp, gd, gdinfo,gd_n,gd_car, gdinfo_car, mympi);          

        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqsn[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(nproc, mympi->pair_s_reqs3);
          

        // w_end
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_end[iptr] = w_pre[iptr] + coef_b * w_rhs[iptr];
        }
        for (size_t iptr=0; iptr < wav_n->siz_ilevel; iptr++) {
            w_end_n[iptr] = w_pre_n[iptr] + coef_b * w_rhs_n[iptr];
        }
        for (size_t iptr=0; iptr < wav_car->siz_ilevel; iptr++) {
            w_end_car[iptr] = w_pre_car[iptr] + coef_b * w_rhs_car[iptr];
        }

      }
      else if (istage<num_rk_stages-1)
      {
        float coef_a = rk_a[istage] * dt;
        float coef_b = rk_b[istage] * dt;

        // wavefield
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_tmp[iptr] = w_pre[iptr] + coef_a * w_rhs[iptr];
        }
        for (size_t iptr=0; iptr < wav_n->siz_ilevel; iptr++) {
            w_tmp_n[iptr] = w_pre_n[iptr] + coef_a * w_rhs_n[iptr];
        }
        for (size_t iptr=0; iptr < wav_car->siz_ilevel; iptr++) {
            w_tmp_car[iptr] = w_pre_car[iptr] + coef_a * w_rhs_car[iptr];
        }

        // apply Qs
        //if (md->visco_type == CONST_VISCO_GRAVES_QS) {
        //  sv_curv_graves_Qs(w_tmp, wave->ncmp, gdinfo, md);
        //}

        // pack and isend
        blk_macdrp_pack_mesg(w_tmp, sbuff, wav->ncmp, gdinfo, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));
        blk_macdrp_pack_mesg(w_tmp_n, sbuffn, wav->ncmp, gdinfo_n, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));                 
        blk_macdrp_pack_mesg(w_tmp_car, ssbuff, wav->ncmp, gdinfo_car, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));
        blk_macdrp_pack_mesg_interp(w_tmp,w_tmp_n,w_tmp_car, sbuff3, wav->ncmp, gd, gdinfo,gd_n,gd_car, gdinfo_car, mympi);


        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqsn[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(nproc, mympi->pair_s_reqs3);

        // w_end
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_end[iptr] += coef_b * w_rhs[iptr];
        }
        for (size_t iptr=0; iptr < wav_n->siz_ilevel; iptr++) {
            w_end_n[iptr] += coef_b * w_rhs_n[iptr];
        }
        for (size_t iptr=0; iptr < wav_car->siz_ilevel; iptr++) {
            w_end_car[iptr] += coef_b * w_rhs_car[iptr];
        }
      }
      else // last stage
      {
        float coef_b = rk_b[istage] * dt;

        // wavefield
        for (size_t iptr=0; iptr < wav->siz_ilevel; iptr++) {
            w_end[iptr] += coef_b * w_rhs[iptr];
        }
        for (size_t iptr=0; iptr < wav_n->siz_ilevel; iptr++) {
            w_end_n[iptr] += coef_b * w_rhs_n[iptr];
        }
        for (size_t iptr=0; iptr < wav_car->siz_ilevel; iptr++) {
            w_end_car[iptr] += coef_b * w_rhs_car[iptr];
        }

        // apply Qs
        if (md->visco_type == CONST_VISCO_GRAVES_QS) {
          sv_curv_graves_Qs(w_end, wav->ncmp, dt, gdinfo, md);
          sv_curv_graves_Qs(w_end_n, wav->ncmp, dt, gdinfo_n, md_n);
          sv_curv_graves_Qs(w_end_car, wav->ncmp, dt, gdinfo_car, md_car);
        }
        
        // pack and isend
        blk_macdrp_pack_mesg(w_end, sbuff, wav->ncmp, gdinfo, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));
        blk_macdrp_pack_mesg(w_end_n, sbuffn, wav->ncmp, gdinfo_n, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));                 
        blk_macdrp_pack_mesg(w_end_car, ssbuff, wav->ncmp, gdinfo_car, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]));
        blk_macdrp_pack_mesg_interp(w_end,w_end_n,w_end_car, sbuff3, wav->ncmp, gd, gdinfo,gd_n,gd_car, gdinfo_car, mympi);                

        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_s_reqsn[ipair_mpi][istage_mpi]);
        MPI_Startall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi]);
        MPI_Startall(nproc, mympi->pair_s_reqs3);

      }

      MPI_Waitall(num_of_s_reqs, mympi->pair_s_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_r_reqs, mympi->pair_r_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_s_reqs, mympi->pair_s_reqsn[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_r_reqs, mympi->pair_r_reqsn[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_s_reqs, mympi->pair_ss_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(num_of_r_reqs, mympi->pair_rr_reqs[ipair_mpi][istage_mpi], MPI_STATUS_IGNORE);
      MPI_Waitall(nproc, mympi->pair_s_reqs3 , MPI_STATUS_IGNORE);
      MPI_Waitall(nproc, mympi->pair_r_reqs3 , MPI_STATUS_IGNORE);

      

      if (istage != num_rk_stages-1) {
        blk_macdrp_unpack_mesg(rbuff, w_tmp, wav->ncmp, gdinfo, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]),
                         mympi->pair_siz_rbuff_x1[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_x2[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_y1[ipair_mpi][istage_mpi],
                         mympi->neighid);
        blk_macdrp_unpack_mesg(rbuffn, w_tmp_n, wav->ncmp, gdinfo_n, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]),
                         mympi->pair_siz_rbuff_x1n[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_x2n[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_y1n[ipair_mpi][istage_mpi],
                         mympi->neighid);
        blk_macdrp_unpack_mesg(rrbuff, w_tmp_car, wav->ncmp, gdinfo_car ,mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]),
                         mympi->pair_siz_rbuff_xx1[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_xx2[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_yy1[ipair_mpi][istage_mpi],
                         mympi->neighid);                                                  
      } else {
        blk_macdrp_unpack_mesg(rbuff, w_end, wav->ncmp, gdinfo, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]),
                         mympi->pair_siz_rbuff_x1[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_x2[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_y1[ipair_mpi][istage_mpi],
                         mympi->neighid);
        blk_macdrp_unpack_mesg(rbuffn, w_end_n, wav->ncmp, gdinfo_n, mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]),
                         mympi->pair_siz_rbuff_x1n[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_x2n[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_y1n[ipair_mpi][istage_mpi],
                         mympi->neighid);
        blk_macdrp_unpack_mesg(rrbuff, w_end_car, wav->ncmp, gdinfo_car ,mympi,
                         &(fd->pair_fdx_op[ipair_mpi][istage_mpi][fd->num_of_fdx_op-1]),
                         &(fd->pair_fdy_op[ipair_mpi][istage_mpi][fd->num_of_fdy_op-1]),
                         mympi->pair_siz_rbuff_xx1[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_xx2[ipair_mpi][istage_mpi],
                         mympi->pair_siz_rbuff_yy1[ipair_mpi][istage_mpi],
                         mympi->neighid); 
                 
      }

      blk_macdrp_unpack_mesg_interp(rbuff3, wav->ncmp, wav, wav_n, wav_car,
                                      gd , gdinfo, gd_n, gd_car , gdinfo_car ,mympi);

    } // RK stages

    //--------------------------------------------
    // QC
    //--------------------------------------------
    
    //get real yang value
    wav_yanggrid2yin(w_end_n, w_realn, gdinfo, gdinfo_n, gd, gd_n, wav, wav_n, mympi);
 /*
    /////////////////check print
    float *restrict Vxn    = w_end + wav->Vx_pos ;
    float *restrict Vyn    = w_end + wav->Vy_pos ;
    float *restrict Vzn    = w_end + wav->Vz_pos ;
    for(int iptr=0;  iptr < 3*gd->nx*gd->ny; iptr++)
    {
      if (mympi->myid == 30)
      {
        fprintf(stdout,"yin grid, iptr[%d]'s f,c,r = %.2f,%.2f,%.2f,xyz = %.2f,%.2f,%.2f. Vx,y,z = %.2f,%.2f,%.2f\n",
                iptr,gd->x3d[iptr],gd->y3d[iptr],gd->z3d[iptr],
                gd->z3d[iptr]*sin(gd->y3d[iptr])*cos(gd->x3d[iptr]),
                gd->z3d[iptr]*sin(gd->y3d[iptr])*sin(gd->x3d[iptr]),
                gd->z3d[iptr]*cos(gd->y3d[iptr]),
                sin(gd->y3d[iptr])*cos(gd->x3d[iptr])*Vzn[iptr]+cos(gd->y3d[iptr])*cos(gd->x3d[iptr])*Vyn[iptr]\
                -sin(gd->x3d[iptr])*Vxn[iptr],
                sin(gd->y3d[iptr])*sin(gd->x3d[iptr])*Vzn[iptr]+cos(gd->y3d[iptr])*sin(gd->x3d[iptr])*Vyn[iptr]\
                +cos(gd->x3d[iptr])*Vxn[iptr],
                cos(gd->y3d[iptr])*Vzn[iptr]-sin(gd->y3d[iptr])*Vyn[iptr]); 
      }

    }
*/




    
    if (qc_check_nan_num_of_step >0  && (it % qc_check_nan_num_of_step) == 0) {
      if (myid==0 && verbose>10) fprintf(stdout,"-> check value nan\n");
        wav_check_value(w_end,w_realn,w_end_car,wav, wav_n ,wav_car,it);
    }

    if(bdrypml->is_enable_ablexp == 1)
    {
     // bdry_ablexp_apply(bdrypml, w_end, wav->ncmp, wav->siz_volume + wav->siz_volume_car);
    }
    
    //--------------------------------------------
    // save results
    //--------------------------------------------
    // calculate PGV,PGA,PGD for each surface at each stage
    if (bdryfree->is_at_sides[CONST_NDIM-1][1] == 1)
    {
        PG_calcu(w_end, w_pre, gdinfo, PG, Dis_accu, dt);
    }

    //-- recv by interp
//    io_recv_keep(iorecv, w_end, it, wav->ncmp, wav->siz_volume);

    //-- line values
    io_line_keep(ioline, w_end, it, wav->ncmp, wav->siz_volume);

    // write slice, use w_rhs as buff
    io_slice_nc_put(ioslice,&ioslice_nc,gdinfo,w_end,w_rhs,it,t_end,0,wav->ncmp-1);

    // snapshot

    if (md->medium_type == CONST_MEDIUM_ACOUSTIC_ISO) {
      io_snap_nc_put_ac(iosnap, &iosnap_nc, gdinfo, wav, 
                     w_end, w_rhs, nt_total, it, t_end, 1,1,1);
    } else {
      io_snap_nc_put(iosnap, &iosnap_nc, gdinfo,gdinfo_car, md, wav, wav_car,
                     w_end, w_rhs,w_realn, w_rhs_n, w_end_car, w_rhs_car, nt_total, it, t_end, 1,1,1);
    }

    // zero temp used w_rsh
    wav_zero_edge(gdinfo, wav, w_rhs);
    wav_zero_edge(gdinfo_n, wav_n, w_rhs_n);
    wav_zero_edge(gdinfo_car, wav_car, w_rhs_car);

    // debug output
    if (output_all==1)
    {
        io_build_fname_time(output_dir,"w3d",".nc",topoid,it,ou_file);
        io_var3d_export_nc(ou_file,
                           w_end,
                           wav->cmp_pos,
                           wav->cmp_name,
                           wav->ncmp,
                           gdinfo->index_name,
                           gdinfo->nx,
                           gdinfo->ny,
                           gdinfo->nz);
    }


    // swap w_pre and w_end, avoid copying
    w_cur = w_pre; w_pre = w_end; w_end = w_cur;
    w_cur_n = w_pre_n; w_pre_n = w_end_n; w_end_n = w_cur_n;
    w_cur_car = w_pre_car; w_pre_car = w_end_car; w_end_car = w_cur_car;
    

    //time_t t_end1 = time(NULL);
    endtime = clock();	
    int t1 = endtime - begintime;
    if (myid==0) 
    fprintf(stdout,"The remaining time is :%f s and whole time is %f s \n", 
            (float)t1*(nt_total-it)/CLOCKS_PER_SEC,(float)t1*(nt_total)/CLOCKS_PER_SEC);
   //  fprintf(stdout,"The remaining time is :%f s and whole time is %f s \n", 
   //          difftime(t_end1,t_start1)*(nt_total-it),difftime(t_end1,t_start1)*(nt_total));

  } // time loop

  // postproc
  if (bdryfree->is_at_sides[CONST_NDIM-1][1] == 1)
  {
    PG_slice_output(PG,gdinfo,output_dir, output_fname_part,topoid);
  }
  // close nc
  io_slice_nc_close(&ioslice_nc);
  io_snap_nc_close(&iosnap_nc);

  return;
  
}

int
sv_curv_graves_Qs(float *w, int ncmp, float dt, gdinfo_t *gdinfo, md_t *md)
{
  int ierr = 0;

  float coef = - PI * md->visco_Qs_freq * dt;

  for (int icmp=0; icmp<ncmp; icmp++)
  {
    //yin
    float *restrict var = w + icmp * gdinfo->siz_volume;

    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      for (int j = gdinfo->nj1; j <= gdinfo->nj2; j++)
      {
        for (int i = gdinfo->ni1; i <= gdinfo->ni2; i++)
        {
          size_t iptr = i + j * gdinfo->siz_line + k * gdinfo->siz_slice;

          float Qatt = expf( coef / md->Qs[iptr] );

          var[iptr] *= Qatt;
        }
      }
    }
  }

  return ierr;
}
