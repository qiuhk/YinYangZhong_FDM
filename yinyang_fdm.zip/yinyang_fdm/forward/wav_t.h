#ifndef WF_EL_1ST_H
#define WF_EL_1ST_H

#include "gd_info.h"
#include "gd_t.h"
#include "fdlib_mem.h"
#include "fdlib_math.h"
/*************************************************
 * structure
 *************************************************/

/*
 * wavefield structure
 */

// wavefield variables elastic 1st eqn: vel + stress
typedef struct {
  float *v5d; // allocated var
  float **storage;//only allocate var used for interp(size^3)
  float **storage_sphere;//for yin-yang, size^2

  int n1, n2, n3, n4, n5;
  int nx, ny, nz, ncmp, nlevel;

  size_t siz_line;
  size_t siz_slice;
  size_t siz_volume;
  size_t siz_ilevel;

  size_t *cmp_pos;
  char  **cmp_name;
  size_t *level_pos;

  size_t Vx_pos;
  size_t Vy_pos;
  size_t Vz_pos;
  size_t Txx_pos;
  size_t Tyy_pos;
  size_t Tzz_pos;
  size_t Tyz_pos;
  size_t Txz_pos;
  size_t Txy_pos;

  // sequential index 0-based
  size_t Vx_seq;
  size_t Vy_seq;
  size_t Vz_seq;
  size_t Txx_seq;
  size_t Tyy_seq;
  size_t Tzz_seq;
  size_t Tyz_seq;
  size_t Txz_seq;
  size_t Txy_seq;

} wav_t;



struct fd_vel_t
{
  float *Vx;
  float *Vy;
  float *Vz;
};

struct fd_stress_t
{
  float *Txx;
  float *Tyy;
  float *Tzz;
};

struct var5d_t
{
  int n1, n2, n3, n4, n5;
  int nx, ny, nz, ncmp, nlevel;
  float *v5d;

  size_t siz_iy;
  size_t siz_iz;
  size_t siz_icmp;
  size_t siz_ilevel;

  size_t *cmp_pos;
  char  **cmp_name;
};

/*************************************************
 * function prototype
 *************************************************/

int 
wav_init(gdinfo_t *gdinfo,
               wav_t *V,
               int number_of_levels);

int
wav_check_value(float *restrict w,float *restrict wn,float *restrict wcar, wav_t *wav,wav_t *wav_n,wav_t *wav_car ,int it);

int
wav_zero_edge(gdinfo_t *gdinfo, wav_t *wav, float *restrict w4d);

int 
wav_yanggrid2yin(float *restrict w,float *restrict w_real,gdinfo_t *gdinfo,gdinfo_t *gdinfo_n, 
         gd_t *gd, gd_t *gd_n, wav_t *wav,wav_t *wav_n, mympi_t *mympi);
         
int
wave_changevalue_ghost(gdinfo_t *gdinfo,gd_t  *gd, wav_t *wav,gdinfo_t *gdinfo_n,gd_t  *gd_n, wav_t *wav_n,
                       gdinfo_t *gdinfo_car,gd_t  *gd_car, wav_t *wav_car,
                       float *restrict w4d, float *restrict w4d_n, float *restrict w4d_car, mympi_t *mympi);

void
yang_point_get_value_from_yin(gdinfo_t *gdinfo, gd_t  *gd, gd_t  *gd_n, 
                              wav_t *wav_n, float *restrict w4d_n, mympi_t *mympi, int k, int iptr);

void
yin_point_get_value_from_yang(gdinfo_t *gdinfo, gd_t  *gd, gd_t  *gd_n, 
                              wav_t *wav, float *restrict w4d, mympi_t *mympi,int k, int iptr);

void
car_point_get_value_from_sphere(gdinfo_t *gdinfo, gd_t  *gd, gd_t  *gd_n, gd_t  *gd_car, 
                                wav_t *wav_car, float *restrict w4d_car, mympi_t *mympi, int iptr);
void
sphere_point_get_value_from_car(gdinfo_t *gdinfo_car, gd_t  *gd, gd_t  *gd_car, 
                            wav_t *wav, float *restrict w4d, mympi_t *mympi, int iptr);

void
yanggrid_value2n(gd_t *gd, gd_t *gd_n, wav_t *wav_n, float *restrict w4d_n,  mympi_t *mympi, int iptr);

float 
lagrange2D(float x, float y, float *xArr, float *yArr, float *value, int size,size_t iptr);

float 
lagrange3D(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr);

float 
Distance2D(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr);

float 
Distance3D_cfroms(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr);

float 
Distance3D_sfromc(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr);


int 
wav_ac_init(gdinfo_t *gdinfo,
               wav_t *V,
               int number_of_levels);

int
PG_calcu(float *w_end, float *w_pre, gdinfo_t *gdinfo, float *PG, float *Dis_accu, float dt);

#endif
