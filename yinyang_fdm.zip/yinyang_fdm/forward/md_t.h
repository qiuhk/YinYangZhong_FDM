#ifndef MD_EL_ISO_H
#define MD_EL_ISO_H

#include "gd_info.h"
#include "gd_t.h"

/*************************************************
 * structure
 *************************************************/

typedef struct {
  int n1, n2, n3, n4;
  int nx, ny, nz, ncmp;
  float *v4d; // allocated var

  size_t siz_line;
  size_t siz_slice;
  size_t siz_volume;

  size_t *cmp_pos;
  char  **cmp_name;

  // flag to determine medium type
  int medium_type;

  // rho for all media
  float *rho;

  // for acustic
  float *kappa; // pointer to var

  // for isotropic media
  float *lambda; // pointer to var
  float *mu;

  // for visco attenuation
  float *Qs;

  // for anisotropic media
  float *c11;
  float *c12;
  float *c13;
  float *c14;
  float *c15;
  float *c16;
  float *c22;
  float *c23;
  float *c24;
  float *c25;
  float *c26;
  float *c33;
  float *c34;
  float *c35;
  float *c36;
  float *c44;
  float *c45;
  float *c46;
  float *c55;
  float *c56;
  float *c66;

  int visco_type;
  float visco_Qs_freq;

} md_t;


/*************************************************
 * function prototype
 *************************************************/

int
md_init(gdinfo_t *gdinfo, md_t *md, int media_type, int visco_type, int a);

int
md_import(md_t *md, char *fname_coords, char *in_dir);

int
md_export(gdinfo_t  *gdinfo,
          gdinfo_t  *gdinfo_n,
          gdinfo_t  *gdinfo_car,
          md_t *md,
          md_t *md_n,
          md_t *md_car,
          char *fname_coords,
          char *output_dir);

int
md_prem(gd_t *gd, gd_t *gd_n,gd_t *gd_car, md_t *md, md_t *md_n, md_t *md_car, char *in_dir);

float 
Distance_1D(float x, float *xs, float *ys,  float power) ;

int
md_gen_test_ac_iso(md_t *md);

int
md_gen_test_el_iso(md_t *md);

int
md_gen_test_Qs(md_t *md, float Qs_freq);

int
md_gen_test_el_vti(md_t *md);

int
md_gen_test_el_aniso(md_t *md);

int
md_rho_to_slow(float *restrict rho, size_t siz_volume);

int
md_ac_Vp_to_kappa(float *restrict rho, float *restrict kappa, size_t siz_volume);

#endif
