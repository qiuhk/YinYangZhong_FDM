/*********************************************************************
 * wavefield for 3d elastic 1st-order equations
 **********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "constants.h"
#include "fdlib_mem.h"
#include "wav_t.h"

int 
wav_init(gdinfo_t *gdinfo,
         wav_t *V,
         int number_of_levels)
{
  int ierr = 0;

  V->nx   = gdinfo->nx;
  V->ny   = gdinfo->ny;
  V->nz   = gdinfo->nz;
  V->ncmp = 9;
  V->nlevel = number_of_levels;

  V->siz_line    = V->nx;
  V->siz_slice   = V->nx * V->ny;
  V->siz_volume  = V->nx * V->ny * V->nz;
  V->siz_ilevel  = V->siz_volume * V->ncmp;

  // vars
  // 3 Vi, 6 Tij, 4 rk stages
  V->v5d = (float *) fdlib_mem_calloc_1d_float(V->siz_ilevel  * V->nlevel,
                        0.0, "v5d, wf_el3d_1st");
  // position of each var
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                      V->ncmp, 0, "w3d_pos, wf_el3d_1st");
  // name of each var
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(
                      V->ncmp, CONST_MAX_STRLEN, "w3d_name, wf_el3d_1st");

// int size = gdinfo->size_of_interp;
// V->storage_for_sphere_interp = (float **) fdlib_mem_calloc_2l_float( V->ncmp, gdinfo->siz_slice*gdinfo->fdx_nghosts*
//                        size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");
// V->storage_for_car_interp   = (float **) fdlib_mem_calloc_2l_float( V->ncmp, gdinfo->siz_volume_*
//                        size*size , 0.0, "storage_for_interp, wf_el3d_glob_1st");                    

  // set value
  for (int icmp=0; icmp < V->ncmp; icmp++)
  {
    cmp_pos[icmp] = icmp * V->siz_volume;
  }

  // set values
  int icmp = 0;

  /*
   * 0-3: Vx,Vy,Vz
   * 4-9: Txx,Tyy,Tzz,Txz,Tyz,Txy
   */

  sprintf(cmp_name[icmp],"%s","Vx");
  V->Vx_pos = cmp_pos[icmp];
  V->Vx_seq = 0;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Vy");
  V->Vy_pos = cmp_pos[icmp];
  V->Vy_seq = 1;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Vz");
  V->Vz_pos = cmp_pos[icmp];
  V->Vz_seq = 2;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Txx");
  V->Txx_pos = cmp_pos[icmp];
  V->Txx_seq = 3;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Tyy");
  V->Tyy_pos = cmp_pos[icmp];
  V->Tyy_seq = 4;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Tzz");
  V->Tzz_pos = cmp_pos[icmp];
  V->Tzz_seq = 5;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Tyz");
  V->Tyz_pos = cmp_pos[icmp];
  V->Tyz_seq = 6;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Txz");
  V->Txz_pos = cmp_pos[icmp];
  V->Txz_seq = 7;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Txy");
  V->Txy_pos = cmp_pos[icmp];
  V->Txy_seq = 8;
  icmp += 1;

  // set pointer
  V->cmp_pos  = cmp_pos;
  V->cmp_name = cmp_name;

  return ierr;
}


int 
wav_ac_init(gdinfo_t *gdinfo,
               wav_t *V,
               int number_of_levels)
{
  int ierr = 0;

  // Vx,Vy,Vz,P
  V->ncmp = 4;

  V->nx   = gdinfo->nx;
  V->ny   = gdinfo->ny;
  V->nz   = gdinfo->nz;
  V->nlevel = number_of_levels;

  V->siz_line   = V->nx;
  V->siz_slice   = V->nx * V->ny;
  V->siz_volume = V->nx * V->ny * V->nz;
  V->siz_ilevel = V->siz_volume * V->ncmp;

  // vars
  // 3 Vi, 6 Tij, 4 rk stages
  V->v5d = (float *) fdlib_mem_calloc_1d_float(V->siz_ilevel * V->nlevel,
                        0.0, "v5d, wf_ac3d_1st");
  // position of each var
  size_t *cmp_pos = (size_t *) fdlib_mem_calloc_1d_sizet(
                      V->ncmp, 0, "w3d_pos, wf_ac3d_1st");
  // name of each var
  char **cmp_name = (char **) fdlib_mem_malloc_2l_char(
                      V->ncmp, CONST_MAX_STRLEN, "w3d_name, wf_ac3d_1st");
  
  // set value
  for (int icmp=0; icmp < V->ncmp; icmp++)
  {
    cmp_pos[icmp] = icmp * V->siz_volume;
  }

  // set values
  int icmp = 0;

  /*
   * 0-3: Vx,Vy,Vz
   * 4: P
   */

  sprintf(cmp_name[icmp],"%s","Vx");
  V->Vx_pos = cmp_pos[icmp];
  V->Vx_seq = 0;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Vy");
  V->Vy_pos = cmp_pos[icmp];
  V->Vy_seq = 1;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","Vz");
  V->Vz_pos = cmp_pos[icmp];
  V->Vz_seq = 2;
  icmp += 1;

  sprintf(cmp_name[icmp],"%s","P");
  V->Txx_pos = cmp_pos[icmp];
  V->Txx_seq = 3;
  icmp += 1;

  // set pointer
  V->cmp_pos  = cmp_pos;
  V->cmp_name = cmp_name;

  return ierr;
}

int
wav_check_value(float *restrict w,float *restrict wn,float *restrict wcar, wav_t *wav,wav_t *wav_n,wav_t *wav_car ,int it)
{
  int ierr = 0;

  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    float *ptr = w + icmp * wav->siz_volume;
    float *ptrn = wn + icmp * wav_n->siz_volume;
    float *ptrcar = wcar + icmp * wav_car->siz_volume;
    for (size_t iptr=0; iptr < wav->siz_volume ; iptr++)
    {
      if (ptr[iptr] != ptr[iptr])
      {
        fprintf(stderr, "ERROR: NaN occurs at time=%d , point_iptr=%d ,variable_icmp=%d, in sphere yin\n",it, iptr, icmp);
        fflush(stderr);
        exit(-1);
      }
    }

    for (size_t iptr=0; iptr < wav_n->siz_volume ; iptr++)
    {
      if (ptrn[iptr] != ptrn[iptr])
      {
        fprintf(stderr, "ERROR: NaN occurs at time=%d , point_iptr=%d ,variable_icmp=%d, in sphere yang\n",it, iptr, icmp);
        fflush(stderr);
        exit(-1);
      }
    }

    for (size_t iptr=0; iptr < wav_car->siz_volume ; iptr++)
    {
      if (ptrcar[iptr] != ptrcar[iptr])
      {
        fprintf(stderr, "ERROR: NaN occurs at time=%d , point_iptr=%d ,variable_icmp=%d, in cartesian\n",it, iptr, icmp);
        fflush(stderr);
        exit(-1);
      }
    }
  }

  return ierr;
}

int
wav_zero_edge(gdinfo_t *gdinfo, wav_t *wav, float *restrict w4d)
{
  int ierr = 0;

  for (int icmp=0; icmp < wav->ncmp; icmp++)
  {
    float *restrict var = w4d + wav->cmp_pos[icmp];

    // z1
    for (int k=0; k < gdinfo->nk1; k++)
    {
      size_t iptr_k = k * gdinfo->siz_slice;
      for (int j=0; j < gdinfo->ny; j++)
      {
        size_t iptr_j = iptr_k + j * gdinfo->siz_line;
        for (int i=0; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_j + i;
          var[iptr] = 0.0; 
        }
      }
    }

    // z2
    for (int k=gdinfo->nk2+1; k < gdinfo->nz; k++)
    {
      size_t iptr_k = k * gdinfo->siz_slice;
      for (int j=0; j < gdinfo->ny; j++)
      {
        size_t iptr_j = iptr_k + j * gdinfo->siz_line;
        for (int i=0; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_j + i;
          var[iptr] = 0.0; 
        }
      }
    }

    // y1
    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      size_t iptr_k = k * gdinfo->siz_slice;
      for (int j=0; j < gdinfo->nj1; j++)
      {
        size_t iptr_j = iptr_k + j * gdinfo->siz_line;
        for (int i=0; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_j + i;
          var[iptr] = 0.0; 
        }
      }
    }

    // y2
    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      size_t iptr_k = k * gdinfo->siz_slice;
      for (int j = gdinfo->nj2+1; j < gdinfo->ny; j++)
      {
        size_t iptr_j = iptr_k + j * gdinfo->siz_line;
        for (int i=0; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_j + i;
          var[iptr] = 0.0; 
        }
      }
    }

    // x1
    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      size_t iptr_k = k * gdinfo->siz_slice;
      for (int j = gdinfo->nj1; j <= gdinfo->nj2; j++)
      {
        size_t iptr_j = iptr_k + j * gdinfo->siz_line;
        for (int i=0; i < gdinfo->ni1; i++)
        {
          size_t iptr = iptr_j + i;
          var[iptr] = 0.0; 
        }
      }
    } 

    // x2
    for (int k = gdinfo->nk1; k <= gdinfo->nk2; k++)
    {
      size_t iptr_k = k * gdinfo->siz_slice;
      for (int j = gdinfo->nj1; j <= gdinfo->nj2; j++)
      {
        size_t iptr_j = iptr_k + j * gdinfo->siz_line;
        for (int i = gdinfo->ni2+1; i < gdinfo->nx; i++)
        {
          size_t iptr = iptr_j + i;
          var[iptr] = 0.0; 
        }
      }
    } 
  }

  return ierr;
}


int
wav_yanggrid2yin(float *restrict w,float *restrict w_real,gdinfo_t *gdinfo,gdinfo_t *gdinfo_n, 
         gd_t *gd, gd_t *gd_n, wav_t *wav,wav_t *wav_n, mympi_t *mympi)
{
  int ierr = 0;

  int ni1 = gdinfo->ni1;
  int nj1 = gdinfo->nj1;
  int nk1 = gdinfo->nk1;
  int ni2 = gdinfo->ni2;
  int nj2 = gdinfo->nj2;
  int nk2 = gdinfo->nk2;
  int siz_line = gdinfo->siz_line;
  int siz_slice  = gdinfo->siz_slice;
  int siz_volume = gdinfo->siz_volume;

  float *restrict x3d  = gd->x3d;
  float *restrict y3d  = gd->y3d;
  float *restrict x3dn  = gd_n->x3d;
  float *restrict y3dn  = gd_n->y3d;

  float *restrict Vx    = w + wav->Vx_pos ;
  float *restrict Vy    = w + wav->Vy_pos ;
  float *restrict Vz    = w + wav->Vz_pos ;
  float *restrict Txx   = w + wav->Txx_pos;
  float *restrict Tyy   = w + wav->Tyy_pos;
  float *restrict Tzz   = w + wav->Tzz_pos;
  float *restrict Txz   = w + wav->Txz_pos;
  float *restrict Tyz   = w + wav->Tyz_pos;
  float *restrict Txy   = w + wav->Txy_pos;

  float *restrict Vxn    = w_real + wav_n->Vx_pos ;
  float *restrict Vyn    = w_real + wav_n->Vy_pos ;
  float *restrict Vzn    = w_real + wav_n->Vz_pos ;
  float *restrict Txxn   = w_real + wav_n->Txx_pos;
  float *restrict Tyyn   = w_real + wav_n->Tyy_pos;
  float *restrict Tzzn   = w_real + wav_n->Tzz_pos;
  float *restrict Txzn   = w_real + wav_n->Txz_pos;
  float *restrict Tyzn   = w_real + wav_n->Tyz_pos;
  float *restrict Txyn   = w_real + wav_n->Txy_pos;

  float P[3][3];//P is P in paper
  float V[3], PV[3];

  float Pn[3][3];//Pn is P-1 in paper
  float T[3][3], PT1[3][3], PT[3][3];

  for (size_t k=nk1; k<=nk2; k++)
  {
    for (size_t j=nj1; j<=nj2; j++)
    {
    for (size_t i=ni1; i<=ni2; i++)
     {
      size_t iptr = k * siz_slice + j * siz_line + i;
      
      //get V
      Pn[0][0] = 1;
      Pn[0][1] = 0;
      Pn[0][2] = 0;
      Pn[1][0] = 0;
      Pn[1][1] = -1*sin(x3dn[iptr]) * sin(x3d[iptr]);
      Pn[1][2] = -1*cos(x3d[iptr]) * recip_sin(y3dn[iptr]);
      Pn[2][0] = 0;
      Pn[2][1] = cos(x3d[iptr]) * recip_sin(y3dn[iptr]);
      Pn[2][2] = -1*sin(x3dn[iptr]) * sin(x3d[iptr]);

      P[0][0] = Pn[0][0];
      P[0][1] = Pn[1][0];
      P[0][2] = Pn[2][0];
      P[1][0] = Pn[0][1];
      P[1][1] = Pn[1][1];
      P[1][2] = Pn[2][1];
      P[2][0] = Pn[0][2];
      P[2][1] = Pn[1][2];
      P[2][2] = Pn[2][2];

      V[0] = Vz[iptr];
      V[1] = Vy[iptr];
      V[2] = Vx[iptr];

      T[0][0] = Tzz[iptr];
      T[0][1] = Tyz[iptr];
      T[0][2] = Txz[iptr];
      T[1][0] = T[0][1];
      T[1][1] = Tyy[iptr];
      T[1][2] = Txy[iptr];
      T[2][0] = T[0][2];
      T[2][1] = T[1][2];
      T[2][2] = Txx[iptr];     

      fdlib_math_matmul3x1(Pn, V, PV);
      fdlib_math_matmul3x3(Pn, T, PT1);
      fdlib_math_matmul3x3(PT1, P, PT);

      Vxn[iptr] = PV[2];
      Vyn[iptr] = PV[1];
      Vzn[iptr] = PV[0];

      Txxn[iptr] = PT[2][2];
      Tyyn[iptr] = PT[1][1];
      Tzzn[iptr] = PT[0][0];
      Txzn[iptr] = PT[0][2];
      Tyzn[iptr] = PT[0][1];
      Txyn[iptr] = PT[1][2];

     }
    }
  }

  return ierr;
}

int
wave_changevalue_ghost(gdinfo_t *gdinfo,gd_t  *gd, wav_t *wav,gdinfo_t *gdinfo_n,gd_t  *gd_n, wav_t *wav_n,
                       gdinfo_t *gdinfo_car,gd_t  *gd_car, wav_t *wav_car,
                       float *restrict w4d, float *restrict w4d_n, float *restrict w4d_car, mympi_t *mympi)
{
  int size = gdinfo->size_of_interp;
  int nghost = gdinfo->npoint_ghosts;

  int ni1 = gdinfo->ni1;
  int ni2 = gdinfo->ni2;
  int nj1 = gdinfo->nj1;
  int nj2 = gdinfo->nj2;
  int nk1 = gdinfo->nk1;
  int nk2 = gdinfo->nk2;
  int nx  = gdinfo->nx;
  int ny  = gdinfo->ny;
  int nz  = gdinfo->nz;
  int siz_line  = gdinfo->siz_line;
  int siz_slice = gdinfo->siz_slice;

  int nii1 = gdinfo_car->ni1;
  int nii2 = gdinfo_car->ni2;
  int njj1 = gdinfo_car->nj1;
  int njj2 = gdinfo_car->nj2;
  int nkk1 = gdinfo_car->nk1;
  int nkk2 = gdinfo_car->nk2;
  int nxx  = gdinfo_car->nx;
  int nyy  = gdinfo_car->ny;
  int nzz  = gdinfo_car->nz;
  int siz_line_car  = gdinfo_car->siz_line;
  int siz_slice_car = gdinfo_car->siz_slice;

  //get interp value of sphere from car
  for (size_t k = 0; k < nk1; k++) 
  {
    for (size_t j = nj1; j <= nj2; j++) 
    {
      for (size_t i = ni1; i <= ni2; i++) 
      {
        //get neigh_global
        size_t iptr = k * siz_slice + j * siz_line + i;
        sphere_point_get_value_from_car(gdinfo_car, gd, gd_car, wav, w4d, mympi, iptr);
        sphere_point_get_value_from_car(gdinfo_car, gd_n, gd_car, wav_n, w4d_n, mympi, iptr);
        yanggrid_value2n(gd, gd_n, wav_n, w4d_n, mympi, iptr);
      }
    }
  }



  //z1 and z2 of car from sphere
  for (size_t k = 0; k < nkk1; k++) 
  {
    for (size_t j = njj1; j <= njj2; j++) 
    {
      for (size_t i = nii1; i <= nii2; i++) 
      {
        size_t iptr = k * siz_slice_car + j * siz_line_car + i;
        car_point_get_value_from_sphere(gdinfo, gd, gd_n, gd_car, wav_car, w4d_car, mympi, iptr);
      }
    }
  }
  for (size_t k = nkk2+1; k < nzz; k++) 
  {
    for (size_t j = njj1; j <= njj2; j++) 
    {
      for (size_t i = nii1; i <= nii2; i++) 
      {
        size_t iptr = k * siz_slice_car + j * siz_line_car + i;
        car_point_get_value_from_sphere(gdinfo, gd, gd_n, gd_car, wav_car, w4d_car, mympi, iptr);
      }
    }
  }



  //get interp value of yin-yang and car_from_sphere
  if (mympi->neighid[0]==-1)
  {
    //x1 get value
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj1; j<=nj2; j++)
      {
        for (int i=0; i<ni1; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          yang_point_get_value_from_yin(gdinfo, gd, gd_n, wav_n, w4d_n, mympi, k, iptr);
          yin_point_get_value_from_yang(gdinfo, gd, gd_n, wav, w4d, mympi, k, iptr);
        }
      }
    }
    
    //x1 of car
    for (int k=nkk1; k<=nkk2; k++)
    {
      for (int j=njj1; j<=njj2; j++)
      {
        for (int i=0; i<nii1; i++)
        {
          size_t iptr = k * siz_slice_car + j * siz_line_car + i;
          car_point_get_value_from_sphere(gdinfo, gd, gd_n, gd_car, wav_car, w4d_car, mympi, iptr);
        }
      }
    }
  } 

  if (mympi->neighid[1]==-1)
  {
    //x2 get value
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj1; j<=nj2; j++)
      {
        for (int i=ni2+1; i<nx; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          yang_point_get_value_from_yin(gdinfo, gd, gd_n, wav_n, w4d_n, mympi, k, iptr);
          yin_point_get_value_from_yang(gdinfo, gd, gd_n, wav, w4d, mympi, k, iptr);
        }
      }
    }

    //x2 of car
    for (int k=nkk1; k<=nkk2; k++)
    {
      for (int j=njj1; j<=njj2; j++)
      {
        for (int i=nii2+1; i<nxx; i++)
        {
          size_t iptr = k * siz_slice_car+ j * siz_line_car + i;
          car_point_get_value_from_sphere(gdinfo, gd, gd_n, gd_car, wav_car, w4d_car, mympi, iptr);
        }
      }
    }
  } 

  if (mympi->neighid[2]==-1)
  {
    //y1 get value
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=0; j<nj1; j++)
      {
        for (int i=ni1; i<=ni2; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          yang_point_get_value_from_yin(gdinfo, gd, gd_n, wav_n, w4d_n, mympi, k, iptr);
          yin_point_get_value_from_yang(gdinfo, gd, gd_n, wav, w4d, mympi, k, iptr);
        }
      }
    }

    //y1 of car
    for (int k=nkk1; k<=nkk2; k++)
    {
      for (int j=0; j<njj1; j++)
      {
        for (int i=nii1; i<=nii2; i++)
        {
          size_t iptr = k * siz_slice_car + j * siz_line_car + i;
          car_point_get_value_from_sphere(gdinfo, gd, gd_n, gd_car, wav_car, w4d_car, mympi, iptr);
        }
      }
    }
  } 

  if (mympi->neighid[3]==-1)
  {
    //y2 get value
    for (int k=nk1; k<=nk2; k++)
    {
      for (int j=nj2+1; j<ny; j++)
      {
        for (int i=ni1; i<=ni2; i++)
        {
          size_t iptr = k * siz_slice + j * siz_line + i;
          yang_point_get_value_from_yin(gdinfo, gd, gd_n, wav_n, w4d_n, mympi, k, iptr);
          yin_point_get_value_from_yang(gdinfo, gd, gd_n, wav, w4d, mympi, k, iptr);
        }
      }
    }

    //y2 of car
    for (int k=nkk1; k<=nkk2; k++)
    {
      for (int j=njj2+1; j<nyy; j++)
      {
        for (int i=nii1; i<=nii2; i++)
        {
          size_t iptr = k * siz_slice_car + j * siz_line_car + i;
          car_point_get_value_from_sphere(gdinfo, gd, gd_n, gd_car, wav_car, w4d_car, mympi, iptr);
        }
      }
    }
  }


  return 0;
}


void
yang_point_get_value_from_yin(gdinfo_t *gdinfo, gd_t  *gd, gd_t  *gd_n, 
                              wav_t *wav_n, float *restrict w4d_n, mympi_t *mympi, int k, int iptr)
{
  int size = gdinfo->size_of_interp;
  int nghost = gdinfo->npoint_ghosts;
  int ncmp = wav_n->ncmp;
  float *varnew = (float *) fdlib_mem_calloc_1d_float(ncmp, 0.0, "varnew");

  ////  lagrange interp for iptr
  for (int j =0; j < size; j++)  {
    for (int i =0; i < size; i++) {
      for (int icmp =0; icmp < ncmp; icmp++) {

        float value = wav_n->storage_sphere[icmp][iptr*size*size + i + j*size];
        varnew[icmp] += gd->coeff_en[iptr][i + j*size] * value; 
      }
    }
  }

  
  ////  change value to new_value in yang' grid(need change twice)
  float *restrict x3d  = gd->x3d;
  float *restrict y3d  = gd->y3d;
  float *restrict x3dn  = gd_n->x3d;
  float *restrict y3dn  = gd_n->y3d;

  float vx = varnew[0];
  float vy = varnew[1];
  float vz = varnew[2];
  float txx = varnew[3];
  float tyy = varnew[4];
  float tzz = varnew[5];
  float tyz = varnew[6];
  float txz = varnew[7];
  float txy = varnew[8];//these is var wait for change

  float *restrict Vx = w4d_n + wav_n->cmp_pos[0];
  float *restrict Vy = w4d_n + wav_n->cmp_pos[1];
  float *restrict Vz = w4d_n + wav_n->cmp_pos[2];
  float *restrict Txx = w4d_n + wav_n->cmp_pos[3];
  float *restrict Tyy = w4d_n + wav_n->cmp_pos[4];
  float *restrict Tzz = w4d_n + wav_n->cmp_pos[5];
  float *restrict Tyz = w4d_n + wav_n->cmp_pos[6];
  float *restrict Txz = w4d_n + wav_n->cmp_pos[7];
  float *restrict Txy = w4d_n + wav_n->cmp_pos[8];


  float P[3][3], Pn[3][3];//P is P in paper
  float V[3], T[3][3];
  float PV[3], PT[3][3], PT1[3][3];

  P[0][0] = 1;
  P[0][1] = 0;
  P[0][2] = 0;
  P[1][0] = 0;
  P[1][1] = -1*sin(x3d[iptr]) * sin(x3dn[iptr]);
  P[1][2] = -1*cos(x3dn[iptr]) * recip_sin(y3d[iptr]);
  P[2][0] = 0;
  P[2][1] = cos(x3dn[iptr]) * recip_sin(y3d[iptr]);
  P[2][2] = -1*sin(x3d[iptr]) * sin(x3dn[iptr]);

  Pn[0][0] = P[0][0];
  Pn[0][1] = P[1][0];
  Pn[0][2] = P[2][0];
  Pn[1][0] = P[0][1];
  Pn[1][1] = P[1][1];
  Pn[1][2] = P[2][1];
  Pn[2][0] = P[0][2];
  Pn[2][1] = P[1][2];
  Pn[2][2] = P[2][2];

  V[0] = vz;
  V[1] = vy;
  V[2] = vx;

  T[0][0] = tzz;
  T[0][1] = tyz;
  T[0][2] = txz;
  T[1][0] = T[0][1];
  T[1][1] = tyy;
  T[1][2] = txy;
  T[2][0] = T[0][2];
  T[2][1] = T[1][2];
  T[2][2] = txx;

  fdlib_math_matmul3x1(P, V, PV);
  fdlib_math_matmul3x3(P, T, PT1);
  fdlib_math_matmul3x3(PT1, Pn, PT); 

  Vx[iptr] = PV[2];
  Vy[iptr] = PV[1];
  Vz[iptr] = PV[0];

  Txx[iptr] = PT[2][2];
  Tyy[iptr] = PT[1][1];
  Tzz[iptr] = PT[0][0];
  Txz[iptr] = PT[0][2];
  Tyz[iptr] = PT[0][1];
  Txy[iptr] = PT[1][2];


  free(varnew);
  return;
}


void
yin_point_get_value_from_yang(gdinfo_t *gdinfo, gd_t  *gd, gd_t  *gd_n, 
                              wav_t *wav, float *restrict w4d, mympi_t *mympi, int k, int iptr)
{
  int size = gdinfo->size_of_interp;
  int nghost = gdinfo->npoint_ghosts;
  int ncmp = wav->ncmp;
  float *varnew = (float *) fdlib_mem_calloc_1d_float(ncmp, 0.0, "varnew");

  ////  lagrange interp for iptr
  for (int j =0; j < size; j++)  {
    for (int i =0; i < size; i++) {
      for (int icmp =0; icmp < ncmp; icmp++) {
        float value = wav->storage_sphere[icmp][iptr*size*size + i + j*size];
        varnew[icmp] += gd->coeff_en[iptr][i + j*size] * value;
      }
    }
  }
  

  ////  change value to new_value in my grid
  float *restrict x3d  = gd->x3d;
  float *restrict y3d  = gd->y3d;
  float *restrict x3dn  = gd_n->x3d;
  float *restrict y3dn  = gd_n->y3d;

  float vx = varnew[0];
  float vy = varnew[1];
  float vz = varnew[2];
  float txx = varnew[3];
  float tyy = varnew[4];
  float tzz = varnew[5];
  float tyz = varnew[6];
  float txz = varnew[7];
  float txy = varnew[8];//these is var wait for change

  float *restrict Vx = w4d + wav->cmp_pos[0];
  float *restrict Vy = w4d + wav->cmp_pos[1];
  float *restrict Vz = w4d + wav->cmp_pos[2];
  float *restrict Txx = w4d + wav->cmp_pos[3];
  float *restrict Tyy = w4d + wav->cmp_pos[4];
  float *restrict Tzz = w4d + wav->cmp_pos[5];
  float *restrict Tyz = w4d + wav->cmp_pos[6];
  float *restrict Txz = w4d + wav->cmp_pos[7];
  float *restrict Txy = w4d + wav->cmp_pos[8];


  float P[3][3], Pn[3][3];//Pn is P-1 in paper
  float V[3], T[3][3];
  float PV[3], PT[3][3], PT1[3][3];

  Pn[0][0] = 1;
  Pn[0][1] = 0;
  Pn[0][2] = 0;
  Pn[1][0] = 0;
  Pn[1][1] = -1*sin(x3d[iptr]) * sin(x3dn[iptr]);
  Pn[1][2] = -1*cos(x3dn[iptr]) * recip_sin(y3d[iptr]);
  Pn[2][0] = 0;
  Pn[2][1] = cos(x3dn[iptr]) * recip_sin(y3d[iptr]);
  Pn[2][2] = -1*sin(x3d[iptr]) * sin(x3dn[iptr]);

  P[0][0] = Pn[0][0];
  P[0][1] = Pn[1][0];
  P[0][2] = Pn[2][0];
  P[1][0] = Pn[0][1];
  P[1][1] = Pn[1][1];
  P[1][2] = Pn[2][1];
  P[2][0] = Pn[0][2];
  P[2][1] = Pn[1][2];
  P[2][2] = Pn[2][2];

  V[0] = vz;
  V[1] = vy;
  V[2] = vx;

  T[0][0] = tzz;
  T[0][1] = tyz;
  T[0][2] = txz;
  T[1][0] = T[0][1];
  T[1][1] = tyy;
  T[1][2] = txy;
  T[2][0] = T[0][2];
  T[2][1] = T[1][2];
  T[2][2] = txx;  

  fdlib_math_matmul3x1(Pn, V, PV);
  fdlib_math_matmul3x3(Pn, T, PT1);
  fdlib_math_matmul3x3(PT1, P, PT);

  Vx[iptr] = PV[2];
  Vy[iptr] = PV[1];
  Vz[iptr] = PV[0];

  Txx[iptr] = PT[2][2];
  Tyy[iptr] = PT[1][1];
  Tzz[iptr] = PT[0][0];
  Txz[iptr] = PT[0][2];
  Tyz[iptr] = PT[0][1];
  Txy[iptr] = PT[1][2];
  
  free(varnew);
  return;
}


//both message of car from yin and yang are all in wav_car->storage 
void
car_point_get_value_from_sphere(gdinfo_t *gdinfo, gd_t  *gd, gd_t  *gd_n, gd_t  *gd_car, 
                                wav_t *wav_car, float *restrict w4d_car, mympi_t *mympi, int iptr)
{
  int size = gdinfo->size_of_interp;
  int nghost = gdinfo->npoint_ghosts;
  int ncmp = wav_car->ncmp;
  float *varnew = (float *) fdlib_mem_calloc_1d_float(ncmp, 0.0, "varnew");

  ////  lagrange interp for iptr,first change value to yang grid
  for (int k =0; k < size; k++) 
  {
    for (int j =0; j < size; j++) 
    {
      for (int i =0; i < size; i++) 
      {
        int isize = i + j*size + k*size*size;
        
        //get value Arr
        for (int icmp =0; icmp < ncmp; icmp++) {
          float value = wav_car->storage[icmp][iptr*size*size*size + isize];
          varnew[icmp] += gd_car->coeff_cs[iptr][isize] * value;
        }
      }
    }
  }
  

  //change value from sphere to car
  float xx = gd_car->x3d[iptr];
  float yy = gd_car->y3d[iptr];
  float zz = gd_car->z3d[iptr];
  float r = sqrt(xx*xx + yy*yy + zz*zz);
  float f = atan2(yy,xx);
  float c = acos(zz/r);//actually is yin

  float *restrict Vx = w4d_car + wav_car->cmp_pos[0];
  float *restrict Vy = w4d_car + wav_car->cmp_pos[1];
  float *restrict Vz = w4d_car + wav_car->cmp_pos[2];
  float *restrict Txx = w4d_car + wav_car->cmp_pos[3];
  float *restrict Tyy = w4d_car + wav_car->cmp_pos[4];
  float *restrict Tzz = w4d_car + wav_car->cmp_pos[5];
  float *restrict Tyz = w4d_car + wav_car->cmp_pos[6];
  float *restrict Txz = w4d_car + wav_car->cmp_pos[7];
  float *restrict Txy = w4d_car + wav_car->cmp_pos[8];

  float vx = varnew[0];
  float vy = varnew[1];
  float vz = varnew[2];
  float txx = varnew[3];
  float tyy = varnew[4];
  float tzz = varnew[5];
  float tyz = varnew[6];
  float txz = varnew[7];
  float txy = varnew[8];//these are rcf var 

  //if get value from yang, first change vlaue from yang to yin
  if(gd_car->cn_neigh_iptrx[iptr] != -1)
  {
    float xxn = -1*xx;
    float yyn = zz;
    float zzn = yy; //xxyyzz_n in yang direction

    float rn = sqrt(xxn*xxn + yyn*yyn + zzn*zzn);
    float fn = atan2(yyn,xxn);
    float cn = acos(zzn/rn);//actually in yang directon

    float Pn[3][3],P[3][3];//Pn is P-1 in paper
    float V0[3], T0[3][3];
    float PV[3], PT[3][3], PT1[3][3];

    Pn[0][0] = 1;
    Pn[0][1] = 0;
    Pn[0][2] = 0;
    Pn[1][0] = 0;
    Pn[1][1] = -1*sin(f) * sin(fn);
    Pn[1][2] = -1*cos(fn) * recip_sin(c);
    Pn[2][0] = 0;
    Pn[2][1] = cos(fn) * recip_sin(c);
    Pn[2][2] = -1*sin(f) * sin(fn);

    P[0][0] = Pn[0][0];
    P[0][1] = Pn[1][0];
    P[0][2] = Pn[2][0];
    P[1][0] = Pn[0][1];
    P[1][1] = Pn[1][1];
    P[1][2] = Pn[2][1];
    P[2][0] = Pn[0][2];
    P[2][1] = Pn[1][2];
    P[2][2] = Pn[2][2];

    V0[0] = vz;
    V0[1] = vy;
    V0[2] = vx;

    T0[0][0] = tzz;
    T0[0][1] = tyz;
    T0[0][2] = txz;
    T0[1][0] = T0[0][1];
    T0[1][1] = tyy;
    T0[1][2] = txy;
    T0[2][0] = T0[0][2];
    T0[2][1] = T0[1][2];
    T0[2][2] = txx;    

    fdlib_math_matmul3x1(Pn, V0, PV);
    fdlib_math_matmul3x3(Pn, T0, PT1);
    fdlib_math_matmul3x3(PT1, P, PT);

    vx = PV[2];
    vy = PV[1];
    vz = PV[0];

    txx = PT[2][2];
    tyy = PT[1][1];
    tzz = PT[0][0];
    txz = PT[0][2];
    tyz = PT[0][1];
    txy = PT[1][2];

  }


  float D[3][3], Dn[3][3];//D is T in word
  float V[3], T[3][3];
  float DV[3], DT[3][3],DT1[3][3];

  D[0][0] = sin(c)*cos(f);
  D[0][1] = sin(c)*sin(f);
  D[0][2] = cos(c);
  D[1][0] = cos(c)*cos(f);
  D[1][1] = cos(c)*sin(f);
  D[1][2] = -1*sin(c);
  D[2][0] = -1*sin(f);
  D[2][1] = cos(f);
  D[2][2] = 0;

  Dn[0][0] = D[0][0];
  Dn[0][1] = D[1][0];
  Dn[0][2] = D[2][0];
  Dn[1][0] = D[0][1];
  Dn[1][1] = D[1][1];
  Dn[1][2] = D[2][1];
  Dn[2][0] = D[0][2];
  Dn[2][1] = D[1][2];
  Dn[2][2] = D[2][2];

  V[0] = vz;
  V[1] = vy;
  V[2] = vx;

  T[0][0] = tzz;
  T[0][1] = tyz;
  T[0][2] = txz;
  T[1][0] = T[0][1];
  T[1][1] = tyy;
  T[1][2] = txy;
  T[2][0] = T[0][2];
  T[2][1] = T[1][2];
  T[2][2] = txx;

  fdlib_math_matmul3x1(Dn, V, DV);
  fdlib_math_matmul3x3(Dn, T, DT1);
  fdlib_math_matmul3x3(DT1, D, DT);

  Vx[iptr] = DV[0];
  Vy[iptr] = DV[1];
  Vz[iptr] = DV[2];

  Txx[iptr] = DT[0][0];
  Tyy[iptr] = DT[1][1];
  Tzz[iptr] = DT[2][2];
  Txz[iptr] = DT[0][2];
  Tyz[iptr] = DT[1][2];
  Txy[iptr] = DT[0][1];

  free(varnew);
  return;
}


//yin and yang both use this func ,use yin as example
void
sphere_point_get_value_from_car(gdinfo_t *gdinfo_car, gd_t  *gd, gd_t  *gd_car, 
                            wav_t *wav, float *restrict w4d, mympi_t *mympi, int iptr)
{
  int size = gdinfo_car->size_of_interp;
  int nghost = gdinfo_car->npoint_ghosts;
  int ncmp = wav->ncmp;
  float *varnew = (float *) fdlib_mem_calloc_1d_float(ncmp, 0.0, "varnew");

  ////  lagrange interp for iptr,first change value to yang grid
  for (int k =0; k < size; k++) 
  {
    for (int j =0; j < size; j++) 
    {
      for (int i =0; i < size; i++) 
      {
        int isize = i + j*size + k*size*size;

        //get value Arr
        for (int icmp =0; icmp < ncmp; icmp++) {
          float value = wav->storage[icmp][iptr*size*size*size + isize];
          varnew[icmp] += gd->coeff_sc[iptr][isize] * value;
        }

      }
    }
  }
 
  
  //change value from car to yin
  float *restrict Vx = w4d + wav->cmp_pos[0];
  float *restrict Vy = w4d + wav->cmp_pos[1];
  float *restrict Vz = w4d + wav->cmp_pos[2];
  float *restrict Txx = w4d + wav->cmp_pos[3];
  float *restrict Tyy = w4d + wav->cmp_pos[4];
  float *restrict Tzz = w4d + wav->cmp_pos[5];
  float *restrict Tyz = w4d + wav->cmp_pos[6];
  float *restrict Txz = w4d + wav->cmp_pos[7];
  float *restrict Txy = w4d + wav->cmp_pos[8];

  float vx = varnew[0];
  float vy = varnew[1];
  float vz = varnew[2];
  float txx = varnew[3];
  float tyy = varnew[4];
  float tzz = varnew[5];
  float tyz = varnew[6];
  float txz = varnew[7];
  float txy = varnew[8];//these is rcf var 

  float f = gd->x3d[iptr];
  float c = gd->y3d[iptr];
  float r = gd->z3d[iptr];
  
  float D[3][3], Dn[3][3];//D is T in word
  float V[3], T[3][3];
  float DV[3], DT[3][3],DT1[3][3];

  D[0][0] = sin(c)*cos(f);
  D[0][1] = sin(c)*sin(f);
  D[0][2] = cos(c);
  D[1][0] = cos(c)*cos(f);
  D[1][1] = cos(c)*sin(f);
  D[1][2] = -1*sin(c);
  D[2][0] = -1*sin(f);
  D[2][1] = cos(f);
  D[2][2] = 0;

  Dn[0][0] = D[0][0];
  Dn[0][1] = D[1][0];
  Dn[0][2] = D[2][0];
  Dn[1][0] = D[0][1];
  Dn[1][1] = D[1][1];
  Dn[1][2] = D[2][1];
  Dn[2][0] = D[0][2];
  Dn[2][1] = D[1][2];
  Dn[2][2] = D[2][2];

  V[0] = vx;
  V[1] = vy;
  V[2] = vz;

  T[0][0] = txx;
  T[0][1] = txy;
  T[0][2] = txz;
  T[1][0] = T[0][1];
  T[1][1] = tyy;
  T[1][2] = tyz;
  T[2][0] = T[0][2];
  T[2][1] = T[1][2];
  T[2][2] = tzz;

  fdlib_math_matmul3x1(D, V, DV);
  fdlib_math_matmul3x3(D, T, DT1);
  fdlib_math_matmul3x3(DT1, Dn, DT);

  Vx[iptr] = DV[2];
  Vy[iptr] = DV[1];
  Vz[iptr] = DV[0];

  Txx[iptr] = DT[2][2];
  Tyy[iptr] = DT[1][1];
  Tzz[iptr] = DT[0][0];
  Txz[iptr] = DT[0][2];
  Tyz[iptr] = DT[0][1];
  Txy[iptr] = DT[1][2];

  free(varnew);
  return;
}


//change yang grid's yin direction value that get from car to yang direction
void
yanggrid_value2n(gd_t *gd, gd_t *gd_n, wav_t *wav_n, float *restrict w4d_n,  mympi_t *mympi, int iptr)
{
  float *restrict x3d  = gd->x3d;
  float *restrict y3d  = gd->y3d;
  float *restrict x3dn  = gd_n->x3d;
  float *restrict y3dn  = gd_n->y3d;

  float *restrict Vx    = w4d_n + wav_n->Vx_pos ;
  float *restrict Vy    = w4d_n + wav_n->Vy_pos ;
  float *restrict Vz    = w4d_n + wav_n->Vz_pos ;
  float *restrict Txx   = w4d_n + wav_n->Txx_pos;
  float *restrict Tyy   = w4d_n + wav_n->Tyy_pos;
  float *restrict Tzz   = w4d_n + wav_n->Tzz_pos;
  float *restrict Txz   = w4d_n + wav_n->Txz_pos;
  float *restrict Tyz   = w4d_n + wav_n->Tyz_pos;
  float *restrict Txy   = w4d_n + wav_n->Txy_pos;


  float P[3][3],Pn[3][3];//P is P in paper
  float V[3], PV[3];
  float T[3][3], PT[3][3], PT1[3][3];
 
  //get V
  P[0][0] = 1;
  P[0][1] = 0;
  P[0][2] = 0;
  P[1][0] = 0;
  P[1][1] = -1*sin(x3d[iptr]) * sin(x3dn[iptr]);
  P[1][2] = -1*cos(x3dn[iptr]) * recip_sin(y3d[iptr]);
  P[2][0] = 0;
  P[2][1] = cos(x3dn[iptr]) * recip_sin(y3d[iptr]);
  P[2][2] = -1*sin(x3d[iptr]) * sin(x3dn[iptr]);

  Pn[0][0] = P[0][0];
  Pn[0][1] = P[1][0];
  Pn[0][2] = P[2][0];
  Pn[1][0] = P[0][1];
  Pn[1][1] = P[1][1];
  Pn[1][2] = P[2][1];
  Pn[2][0] = P[0][2];
  Pn[2][1] = P[1][2];
  Pn[2][2] = P[2][2];

  V[0] = Vz[iptr];
  V[1] = Vy[iptr];
  V[2] = Vx[iptr];

  T[0][0] = Tzz[iptr];
  T[0][1] = Tyz[iptr];
  T[0][2] = Txz[iptr];
  T[1][0] = T[0][1];
  T[1][1] = Tyy[iptr];
  T[1][2] = Txy[iptr];
  T[2][0] = T[0][2];
  T[2][1] = T[1][2];
  T[2][2] = Txx[iptr]; 

  fdlib_math_matmul3x1(P, V, PV);
  fdlib_math_matmul3x3(P, T, PT1);
  fdlib_math_matmul3x3(PT1, Pn, PT);

  Vx[iptr] = PV[2];
  Vy[iptr] = PV[1];
  Vz[iptr] = PV[0];

  Txx[iptr] = PT[2][2];
  Tyy[iptr] = PT[1][1];
  Tzz[iptr] = PT[0][0];
  Txz[iptr] = PT[0][2];
  Tyz[iptr] = PT[0][1];
  Txy[iptr] = PT[1][2];

}

//used for 2D
float 
lagrange2D(float x, float y, float *xArr, float *yArr, float *value, int size,size_t iptr) 
{
  
  for (int i = 0; i < size; i++) 
  {
    for (int j = 0; j < size; j++)
    {
      for(int m = 0;m<size ; m++)
      if (m!=i && xArr[i+j*size]==xArr[m+j*size])
      {
        for (int ii = 0; ii < size; ii++) fprintf(stdout, "xArr[%d] (a line)is %f\n",ii+j*size,xArr[ii+j*size]);
        fprintf(stderr, "ERROR: lagrange interp at point %zd occurs xArr[%d] equals xArr[%d]\n",iptr,i+j*size,m+j*size);
      }
      for(int n = 0;n<size ; n++)
      if (n!=j && yArr[i+j*size]==yArr[i+n*size])
      {
        for (int jj = 0; jj < size; jj++) fprintf(stdout, "yArr[%d] (a column)is %f\n",i+jj*size,yArr[i+jj*size]);
        fprintf(stderr, "ERROR: lagrange interp at point %zd occurs yArr[%d] equals yArr[%d]\n",iptr,i+j*size,i+n*size);
      }
    }
  } 
  
  float z = 0.0;
  for (int i = 0; i < size; i++) 
  {
    for (int j = 0; j < size; j++)
    {
      float numerator = 1.0;
      float denominator = 1.0;
      //call Lij
      for (int m = 0; m < size; m++) 
      {         
          if (m != i) 
          {
              numerator *= (x - xArr[m + j*size]) ;
              denominator *= (xArr[i + j*size] - xArr[m + j*size]);
          }          
      }
      for (int n = 0; n < size; n++) 
      {         
          if (n != j) 
          {
              numerator *= (y - yArr[i + n*size]);
              denominator *= (yArr[i + j*size] - yArr[i + n*size]);
          }          
      } 
      z += value[i + j*size] * numerator / denominator;
    }
  }
  return z;
}


//used for yinyang, suit size^2
float 
Distance2D(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr) 
{
  float x0 = z*sin(y)*cos(x);
  float y0 = z*sin(y)*sin(x);
  float z0 = z*cos(y);

  float w = 0.0;
  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size );//-2 power of diatance
  for (int i = 0; i < size; i++) 
  {
    for (int j = 0; j < size; j++)
    {
      float x1 = zArr[i + j*size]*sin(yArr[i + j*size])*cos(xArr[i + j*size]);
      float y1 = zArr[i + j*size]*sin(yArr[i + j*size])*sin(xArr[i + j*size]);
      float z1 = zArr[i + j*size]*cos(yArr[i + j*size]);

      di[i + j*size] = (x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1) + (z0 - z1)*(z0 - z1);
      if (di[i + j*size] > 1e-10) {
      di[i + j*size] =1/di[i + j*size];
      }
      else{
      di[i + j*size] =1e10;
      }
      d_sum = d_sum + di[i + j*size];
    }
  }

  for (int i = 0; i < size; i++) 
  {
    for (int j = 0; j < size; j++)
    {
      w = w + di[i + j*size] / d_sum * value[i + j*size];
    }
  }

  free(di);
  return w;
  
}

float 
Distance3D_cfroms(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr) 
{

  float w = 0.0;
  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size *size );//-2 power of diatance
  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        float x1 = zArr[isize]*sin(yArr[isize])*cos(xArr[isize]);
        float y1 = zArr[isize]*sin(yArr[isize])*sin(xArr[isize]);
        float z1 = zArr[isize]*cos(yArr[isize]);

        di[isize] = (x - x1)*(x - x1) + (y - y1)*(y - y1) + (z - z1)*(z - z1);
        if (di[isize] > 1e-10) {
        di[isize] =1/di[isize];
        }
        else{
        di[isize] =1e10;
        }
        d_sum = d_sum + di[isize];
      }
    }
  }

  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        w = w + di[isize] / d_sum * value[isize];
      }
    }
  }

  free(di);
  return w;
  
}

float 
Distance3D_sfromc(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr) 
{
  float x0 = z*sin(y)*cos(x);
  float y0 = z*sin(y)*sin(x);
  float z0 = z*cos(y);

  float w = 0.0;
  float d_sum = 0.0;
  float *di = ( float * ) malloc( sizeof( float ) * size *size *size );//-2 power of diatance
  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        float x1 = xArr[isize];
        float y1 = yArr[isize];
        float z1 = zArr[isize];

        di[isize] = (x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1) + (z0 - z1)*(z0 - z1);
        if (di[isize] > 1e-10) {
        di[isize] =1/di[isize];
        }
        else{
        di[isize] =1e10;
        }
        d_sum = d_sum + di[isize];
      }
    }
  }

  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        int isize = k*size*size + j*size + i; 
        w = w + di[isize] / d_sum * value[isize];
      }
    }
  }

  free(di);
  return w;
  
}


//used for 2D
float 
lagrange3D(float x, float y, float z, float *xArr, float *yArr, float *zArr, float *value, int size,size_t iptr) 
{
  /*
  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
       for(int m = 0;m<size ; m++)
        if (m!=i && xArr[i+j*size+k*size*size]==xArr[m+j*size+k*size*size])
        {
          for (int ii = 0; ii < size; ii++) fprintf(stdout, "xArr[%d] (a line)is %f\n",
                                                    ii+j*size+k*size*size,xArr[ii+j*size+k*size*size]);
          fprintf(stderr, "ERROR: lagrange interp at point %zd occurs xArr[%d] equals xArr[%d]\n",
                  iptr,i+j*size+k*size*size,m+j*size+k*size*size);
        }
       for(int n = 0;n<size ; n++)
        if (n!=j && yArr[i+j*size+k*size*size]==yArr[i+n*size+k*size*size])
        {
          for (int jj = 0; jj < size; jj++) fprintf(stdout, "yArr[%d] (a column)is %f\n",
                                                    i+jj*size+k*size*size,yArr[i+jj*size+k*size*size]);
          fprintf(stderr, "ERROR: lagrange interp at point %zd occurs yArr[%d] equals yArr[%d]\n",
                  iptr,i+j*size+k*size*size,i+n*size+k*size*size);
        }
       for(int mn = 0;mn<size ; mn++)
        if (mn!=k && zArr[i+j*size+k*size*size]==zArr[i+j*size+mn*size*size])
        {
          for (int kk = 0; kk < size; kk++) fprintf(stdout, "zArr[%d] is %f\n",
                                                    i+j*size+kk*size*size,yArr[i+j*size+kk*size*size]);
          fprintf(stderr, "ERROR: lagrange interp at point %zd occurs zArr[%d] equals zArr[%d]\n",
                  iptr,i+j*size+k*size*size,i+j*size+mn*size*size);
        }
      }
    } 
  }
  */
  float v = 0.0;
  for (int k = 0; k < size; k++) 
  {
    for (int j = 0; j < size; j++) 
    {
      for (int i = 0; i < size; i++)
      {
        float numerator = 1.0;
        float denominator = 1.0;
        //call Lij
        for (int m = 0; m < size; m++) 
        {         
            if (m != i) 
            {
                numerator *= (x - xArr[m + j*size + k*size*size]) ;
                denominator *= (xArr[i + j*size + k*size*size] - xArr[m + j*size + k*size*size]);
            }          
        }
        for (int n = 0; n < size; n++) 
        {         
            if (n != j) 
            {
                numerator *= (y - yArr[i + n*size + k*size*size]);
                denominator *= (yArr[i + j*size + k*size*size] - yArr[i + n*size + k*size*size]);
            }          
        } 
        for (int mn = 0; mn < size; mn++) 
        {         
            if (mn != k) 
            {
                numerator *= (z - zArr[i + j*size + mn*size*size]);
                denominator *= (zArr[i + j*size + k*size*size] - zArr[i + j*size + mn*size*size]);
            }          
        }
        v += value[i + j*size + k*size*size] * numerator / denominator;
      }
    }
  }
    return v;
}

int
PG_calcu(float *w_end, float *w_pre, gdinfo_t *gdinfo, float *PG, float *Dis_accu, float dt)
{
  //Dis_accu is displacement accumulation.
  int ni1 = gdinfo->ni1;
  int nj1 = gdinfo->nj1;
  int nk1 = gdinfo->nk1;
  int ni2 = gdinfo->ni2;
  int nj2 = gdinfo->nj2;
  int nk2 = gdinfo->nk2;
  int siz_line = gdinfo->siz_line;
  int siz_slice  = gdinfo->siz_slice;
  int siz_volume = gdinfo->siz_volume;
  // 0-2 Vx1,Vy1,Vz1  it+1 moment  V
  // 0-2 Vx0,Vy0,Vz0  it moment V
  float *Vx1 = w_end + 0*siz_volume;
  float *Vy1 = w_end + 1*siz_volume;
  float *Vz1 = w_end + 2*siz_volume;
  float *Vx0 = w_pre + 0*siz_volume;
  float *Vy0 = w_pre + 1*siz_volume;
  float *Vz0 = w_pre + 2*siz_volume;
  float *PGVx = PG + 0*siz_slice;
  float *PGVy = PG + 1*siz_slice;
  float *PGVz = PG + 2*siz_slice;
  float *PGAx = PG + 3*siz_slice;
  float *PGAy = PG + 4*siz_slice;
  float *PGAz = PG + 5*siz_slice;
  float *PGDx = PG + 6*siz_slice;
  float *PGDy = PG + 7*siz_slice;
  float *PGDz = PG + 8*siz_slice;
  float *D_x = Dis_accu + 0*siz_slice;
  float *D_y = Dis_accu + 1*siz_slice;
  float *D_z = Dis_accu + 2*siz_slice;
  int iptr,iptr1;
  for( int j = nj1; j<=nj2; j++){
    for( int i = ni1; i<=ni2; i++){
      iptr = i + j * siz_line + nk2 * siz_slice;//iptr at surface 
      iptr1 = i + j * siz_line;//pointer to save,3D->2D
      float Ax, Ay, Az;
      Ax = fabs((Vx1[iptr]-Vx0[iptr])/dt);
      Ay = fabs((Vy1[iptr]-Vy0[iptr])/dt);
      Az = fabs((Vz1[iptr]-Vz0[iptr])/dt);
      D_x[iptr1] += 0.5*(Vx1[iptr]+Vx0[iptr])*dt; 
      D_y[iptr1] += 0.5*(Vy1[iptr]+Vy0[iptr])*dt; 
      D_z[iptr1] += 0.5*(Vz1[iptr]+Vz0[iptr])*dt; 
      if(PGVx[iptr1]<fabs(Vx1[iptr])) PGVx[iptr1]=fabs(Vx1[iptr]);
      if(PGVy[iptr1]<fabs(Vy1[iptr])) PGVy[iptr1]=fabs(Vy1[iptr]);
      if(PGVz[iptr1]<fabs(Vz1[iptr])) PGVz[iptr1]=fabs(Vz1[iptr]);
      if(PGAx[iptr1]<Ax) PGAx[iptr1]=Ax;
      if(PGAy[iptr1]<Ay) PGAy[iptr1]=Ay;
      if(PGAz[iptr1]<Az) PGAz[iptr1]=Az;
      if(PGDx[iptr1]<fabs(D_x[iptr1])) PGDx[iptr1] = fabs(D_x[iptr1]);
      if(PGDy[iptr1]<fabs(D_y[iptr1])) PGDy[iptr1] = fabs(D_y[iptr1]);
      if(PGDz[iptr1]<fabs(D_z[iptr1])) PGDz[iptr1] = fabs(D_z[iptr1]);
      }
    }
return 0;
}
