/*********************************************************************
 * setup fd operators
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fdlib_mem.h"
#include "constants.h"
#include "gd_info.h"

//
// set grid size
//

int
gd_info_set(gdinfo_t *const gdinfo, gdinfo_t *const gdinfo_n, gdinfo_t *const gdinfo_car,
            const mympi_t *const mympi,
            const int number_of_total_grid_points_x,
            const int number_of_total_grid_points_y,
            const int number_of_total_grid_points_z,
            const int number_of_cartesian_grid_points,
            const int size_of_interp,
            const int fdx_nghosts,
            int const fdy_nghosts,
            const int fdz_nghosts,
            const int verbose)
{
  int ierr = 0;

  //// determine ni
  int nx_et = number_of_total_grid_points_x;

  int nx_avg  = nx_et / mympi->nprocx;
  int nx_left = nx_et % mympi->nprocx;

  if (nx_avg < 2 * fdx_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size in theta indx less than 2*ghost\n");// error
    exit(-1);
  }

  int ni = nx_avg;

  gdinfo->gni1 = mympi->topoid[0] * nx_avg;

  if (mympi->topoid[0] < nx_left) {
    ni++;
  }

  if (nx_left != 0) {
    gdinfo->gni1 += (mympi->topoid[0] < nx_left)? mympi->topoid[0] : nx_left;
  }

  //// determine nj
  int ny_et = number_of_total_grid_points_y;

  int ny_avg  = ny_et / mympi->nprocy;
  int ny_left = ny_et % mympi->nprocy;

  if (ny_avg < 2 * fdy_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size in fi indx less than 2*ghost\n");// error
    exit(-1);
  }
 
  int nj = ny_avg;

  gdinfo->gnj1 = mympi->topoid[1] * ny_avg;

  if (mympi->topoid[1] < ny_left) {
    nj++;
  }

  if (ny_left != 0) {
    gdinfo->gnj1 += (mympi->topoid[1] < ny_left)? mympi->topoid[1] : ny_left;
  }

  //// determine nk
  int nk = number_of_total_grid_points_z;
  gdinfo->gnk1 = 0;

  //// determine ni_n
  int nx_etn = number_of_total_grid_points_x;

  int nx_avgn  = nx_etn / mympi->nprocx;
  int nx_leftn = nx_etn % mympi->nprocx;

  if (nx_avgn < 2 * fdx_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size in theta indx less than 2*ghost\n");// error
    exit(-1);
  }

  int nin = nx_avgn;

  gdinfo_n->gni1 = mympi->topoid[0] * nx_avgn;

  if (mympi->topoid[0] < nx_leftn) {
    nin++;
  }

  if (nx_leftn != 0) {
    gdinfo_n->gni1 += (mympi->topoid[0] < nx_leftn)? mympi->topoid[0] : nx_leftn;
  }

  //// determine nj
  int ny_etn = number_of_total_grid_points_y;

  int ny_avgn  = ny_etn / mympi->nprocy;
  int ny_leftn = ny_etn % mympi->nprocy;

  if (ny_avgn < 2 * fdy_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size in fi indx less than 2*ghost\n");// error
    exit(-1);
  }
 
  int njn = ny_avgn;

  gdinfo_n->gnj1 = mympi->topoid[1] * ny_avgn;

  if (mympi->topoid[1] < ny_leftn) {
    njn++;
  }

  if (ny_leftn != 0) {
    gdinfo_n->gnj1 += (mympi->topoid[1] < ny_leftn)? mympi->topoid[1] : ny_leftn;
  }

  //// determine nk
  nk = number_of_total_grid_points_z;
  gdinfo_n->gnk1 = 0;

  //// determine nii
  int nx_car_et = number_of_cartesian_grid_points;

  int nx_car_avg  = nx_car_et / mympi->nprocx;
  int nx_car_left = nx_car_et % mympi->nprocx;

  if (nx_car_avg < 2 * fdx_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size in theta indx less than 2*ghost\n");// error
    exit(-1);
  }

  int nii = nx_car_avg;

  gdinfo_car->gni1 = mympi->topoid[0] * nx_car_avg;

  if (mympi->topoid[0] < nx_car_left) {
    nii++;
  }

  if (nx_car_left != 0) {
    gdinfo_car->gni1 += (mympi->topoid[0] < nx_car_left)? mympi->topoid[0] : nx_car_left;
  }

  //// determine njj
  int ny_car_et = number_of_cartesian_grid_points;

  int ny_car_avg  = ny_car_et / mympi->nprocy;
  int ny_car_left = ny_car_et % mympi->nprocy;

  if (ny_car_avg < 2 * fdy_nghosts) {
    fprintf(stdout,"!!!!!!!  error   !!!!! \n block size in fi indx less than 2*ghost\n");// error
    exit(-1);
  }
 
  int njj = ny_car_avg;

  gdinfo_car->gnj1 = mympi->topoid[1] * ny_car_avg;

  if (mympi->topoid[1] < ny_car_left) {
    njj++;
  }

  if (ny_car_left != 0) {
    gdinfo_car->gnj1 += (mympi->topoid[1] < ny_car_left)? mympi->topoid[1] : ny_car_left;
  }

  //// determine nkk
  int nkk = number_of_cartesian_grid_points;
  gdinfo_car->gnk1 = 0;
  
  // sphere yin grid
  int nx = ni + 2 * fdx_nghosts;
  int ny = nj + 2 * fdy_nghosts;
  int nz = nk + 2 * fdz_nghosts;

  gdinfo->ni = ni;
  gdinfo->nj = nj;
  gdinfo->nk = nk;

  gdinfo->nx = nx;
  gdinfo->ny = ny;
  gdinfo->nz = nz;

  gdinfo->ni1 = fdx_nghosts;
  gdinfo->ni2 = gdinfo->ni1 + ni - 1;

  gdinfo->nj1 = fdy_nghosts;
  gdinfo->nj2 = gdinfo->nj1 + nj - 1;

  gdinfo->nk1 = fdz_nghosts;
  gdinfo->nk2 = gdinfo->nk1 + nk - 1;

  gdinfo->gni2 = gdinfo->gni1 + gdinfo->ni - 1;
  gdinfo->gnj2 = gdinfo->gnj1 + gdinfo->nj - 1;
  gdinfo->gnk2 = gdinfo->gnk1 + gdinfo->nk - 1;

  gdinfo->ni1_to_glob_phys0 = gdinfo->gni1;
  gdinfo->ni2_to_glob_phys0 = gdinfo->gni2;
  gdinfo->nj1_to_glob_phys0 = gdinfo->gnj1;
  gdinfo->nj2_to_glob_phys0 = gdinfo->gnj2;
  gdinfo->nk1_to_glob_phys0 = gdinfo->gnk1;
  gdinfo->nk2_to_glob_phys0 = gdinfo->gnk2;

  // sphere yang grid
  int nxn = nin + 2 * fdx_nghosts;
  int nyn = njn + 2 * fdy_nghosts;
  int nzn = nk  + 2 * fdz_nghosts;

  gdinfo_n->ni = nin;
  gdinfo_n->nj = njn;
  gdinfo_n->nk = nk ;

  gdinfo_n->nx = nxn;
  gdinfo_n->ny = nyn;
  gdinfo_n->nz = nzn;

  gdinfo_n->ni1 = fdx_nghosts;
  gdinfo_n->ni2 = gdinfo_n->ni1 + nin - 1;

  gdinfo_n->nj1 = fdy_nghosts;
  gdinfo_n->nj2 = gdinfo_n->nj1 + njn - 1;

  gdinfo_n->nk1 = fdz_nghosts;
  gdinfo_n->nk2 = gdinfo_n->nk1 + nk - 1;

  gdinfo_n->gni2 = gdinfo_n->gni1 + gdinfo_n->ni - 1;
  gdinfo_n->gnj2 = gdinfo_n->gnj1 + gdinfo_n->nj - 1;
  gdinfo_n->gnk2 = gdinfo_n->gnk1 + gdinfo_n->nk - 1;

  gdinfo_n->ni1_to_glob_phys0 = gdinfo_n->gni1;
  gdinfo_n->ni2_to_glob_phys0 = gdinfo_n->gni2;
  gdinfo_n->nj1_to_glob_phys0 = gdinfo_n->gnj1;
  gdinfo_n->nj2_to_glob_phys0 = gdinfo_n->gnj2;
  gdinfo_n->nk1_to_glob_phys0 = gdinfo_n->gnk1;
  gdinfo_n->nk2_to_glob_phys0 = gdinfo_n->gnk2;

  // car grid
  int nxx = nii + 2 * fdx_nghosts;
  int nyy = njj + 2 * fdy_nghosts;
  int nzz = nkk + 2 * fdz_nghosts;

  gdinfo_car->ni = nii;
  gdinfo_car->nj = njj;
  gdinfo_car->nk = nkk;

  gdinfo_car->nx = nxx;
  gdinfo_car->ny = nyy;
  gdinfo_car->nz = nzz;

  gdinfo_car->ni1 = fdx_nghosts;
  gdinfo_car->ni2 = gdinfo_car->ni1 + nii - 1;

  gdinfo_car->nj1 = fdy_nghosts;
  gdinfo_car->nj2 = gdinfo_car->nj1 + njj - 1;

  gdinfo_car->nk1 = fdz_nghosts;
  gdinfo_car->nk2 = gdinfo_car->nk1 + nkk - 1;

  // global index end
  gdinfo_car->gni2 = gdinfo_car->gni1 + gdinfo_car->ni - 1;
  gdinfo_car->gnj2 = gdinfo_car->gnj1 + gdinfo_car->nj - 1;
  gdinfo_car->gnk2 = gdinfo_car->gnk1 + gdinfo_car->nk - 1;

  gdinfo_car->ni1_to_glob_phys0 = gdinfo_car->gni1;
  gdinfo_car->ni2_to_glob_phys0 = gdinfo_car->gni2;
  gdinfo_car->nj1_to_glob_phys0 = gdinfo_car->gnj1;
  gdinfo_car->nj2_to_glob_phys0 = gdinfo_car->gnj2;
  gdinfo_car->nk1_to_glob_phys0 = gdinfo_car->gnk1;
  gdinfo_car->nk2_to_glob_phys0 = gdinfo_car->gnk2;
  
  // x dimention varies first
  gdinfo->siz_line   = nx; 
  gdinfo->siz_slice  = nx * ny; 
  gdinfo->siz_volume = nx * ny * nz;

  gdinfo_n->siz_line   = nxn; 
  gdinfo_n->siz_slice  = nxn * nyn; 
  gdinfo_n->siz_volume = nxn * nyn * nzn;

  gdinfo_car->siz_line   = nxx; 
  gdinfo_car->siz_slice  = nxx * nyy; 
  gdinfo_car->siz_volume = nxx * nyy * nzz;

  // set npoint_ghosts according to fdz_nghosts
  gdinfo->npoint_ghosts = fdz_nghosts;
  gdinfo->fdx_nghosts = fdx_nghosts;
  gdinfo->fdy_nghosts = fdy_nghosts;
  gdinfo->fdz_nghosts = fdz_nghosts;
  gdinfo_n->npoint_ghosts = fdz_nghosts;
  gdinfo_n->fdx_nghosts = fdx_nghosts;
  gdinfo_n->fdy_nghosts = fdy_nghosts;
  gdinfo_n->fdz_nghosts = fdz_nghosts;
  gdinfo_car->npoint_ghosts = fdz_nghosts;
  gdinfo_car->fdx_nghosts = fdx_nghosts;
  gdinfo_car->fdy_nghosts = fdy_nghosts;
  gdinfo_car->fdz_nghosts = fdz_nghosts;

  gdinfo->num_total_grid_x = number_of_total_grid_points_x;
  gdinfo->num_total_grid_y = number_of_total_grid_points_y;
  gdinfo->num_total_grid_z = number_of_total_grid_points_z;
  gdinfo->size_of_interp   = size_of_interp;

  gdinfo_n->num_total_grid_x = number_of_total_grid_points_x;
  gdinfo_n->num_total_grid_y = number_of_total_grid_points_y;
  gdinfo_n->num_total_grid_z = number_of_total_grid_points_z;
  gdinfo_n->size_of_interp   = size_of_interp;
  
  gdinfo_car->num_total_grid_x = number_of_cartesian_grid_points;
  gdinfo_car->num_total_grid_y = number_of_cartesian_grid_points;
  gdinfo_car->num_total_grid_z = number_of_cartesian_grid_points;
  gdinfo_car->size_of_interp   = size_of_interp;

  gdinfo->index_name = fdlib_mem_malloc_2l_char(
                        CONST_NDIM, CONST_MAX_STRLEN, "gdinfo name");
  gdinfo_n->index_name = fdlib_mem_malloc_2l_char(
                        CONST_NDIM, CONST_MAX_STRLEN, "gdinfo name");
  gdinfo_car->index_name = fdlib_mem_malloc_2l_char(
                        CONST_NDIM, CONST_MAX_STRLEN, "gdinfo name");                                            

  // grid coord name
  sprintf(gdinfo->index_name[0],"%s","i");
  sprintf(gdinfo->index_name[1],"%s","j");
  sprintf(gdinfo->index_name[2],"%s","k");

  return ierr;
}

/*
 * give a local index ref, check if in this thread
 */

int
gd_info_lindx_is_inner(int i, int j, int k, gdinfo_t *gdinfo)
{
  int is_in = 0;

  if (   i >= gdinfo->ni1 && i <= gdinfo->ni2
      && j >= gdinfo->nj1 && j <= gdinfo->nj2
      && k >= gdinfo->nk1 && k <= gdinfo->nk2)
  {
    is_in = 1;
  }

  return is_in;
}  

int
gd_car_lindx_is_inner(int i, int j, int k, gdinfo_t *gdinfo)
{
  int is_in = 0;

  if (   i >= gdinfo->ni1 && i <= gdinfo->ni2
      && j >= gdinfo->nj1 && j <= gdinfo->nj2
      && k >= gdinfo->nk1 && k <= gdinfo->nk2)
  {
    is_in = 1;
  }

  return is_in;
}  

/*
 * give a global index ref to phys0, check if in this thread
 */

int
gd_info_gindx_is_inner(int gi, int gj, int gk, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gi >= gdinfo->ni1_to_glob_phys0 && gi <= gdinfo->ni2_to_glob_phys0 &&
       gj >= gdinfo->nj1_to_glob_phys0 && gj <= gdinfo->nj2_to_glob_phys0 &&
       gk >= gdinfo->nk1_to_glob_phys0 && gk <= gdinfo->nk2_to_glob_phys0 )
  {
    ishere = 1;
  }

  return ishere;
}

/*
 * glphyinx, glextind, gp,ge
 * lcphyind, lcextind
 * gl: global
 * lc: local
 * inx: index
 * phy: physical points only, do not count ghost
 * ext: include extended points, with ghots points
 */

int
gd_info_gindx_is_inner_i(int gi, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gi >= gdinfo->ni1_to_glob_phys0 && gi <= gdinfo->ni2_to_glob_phys0)
  {
    ishere = 1;
  }

  return ishere;
}

int
gd_info_gindx_is_inner_j(int gj, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gj >= gdinfo->nj1_to_glob_phys0 && gj <= gdinfo->nj2_to_glob_phys0)
  {
    ishere = 1;
  }

  return ishere;
}

int
gd_info_gindx_is_inner_k(int gk, gdinfo_t *gdinfo)
{
  int ishere = 0;

  if ( gk >= gdinfo->nk1_to_glob_phys0 && gk <= gdinfo->nk2_to_glob_phys0)
  {
    ishere = 1;
  }

  return ishere;
}

/*
 * convert global index to local
 */

int
gd_info_ind_glphy2lcext_i(int gi, gdinfo_t *gdinfo)
{
  return gi - gdinfo->ni1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_info_ind_glphy2lcext_j(int gj, gdinfo_t *gdinfo)
{
  return gj - gdinfo->nj1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_info_ind_glphy2lcext_k(int gk, gdinfo_t *gdinfo)
{
  return gk - gdinfo->nk1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_car_ind_glphy2lcext_i(int gi, gdinfo_t *gdinfo)
{
  return gi - gdinfo->ni1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_car_ind_glphy2lcext_j(int gj, gdinfo_t *gdinfo)
{
  return gj - gdinfo->nj1_to_glob_phys0 + gdinfo->npoint_ghosts;
}

int
gd_car_ind_glphy2lcext_k(int gk, gdinfo_t *gdinfo)
{
  return gk - gdinfo->nk1_to_glob_phys0 + gdinfo->npoint_ghosts;
}
/*
 * convert local index to global
 */

int
gd_info_ind_lcext2glphy_i(int i, gdinfo_t *gdinfo)
{
  return i - gdinfo->npoint_ghosts + gdinfo->ni1_to_glob_phys0;
}

int
gd_info_ind_lcext2glphy_j(int j, gdinfo_t *gdinfo)
{
  return j - gdinfo->npoint_ghosts + gdinfo->nj1_to_glob_phys0;
}

int
gd_info_ind_lcext2glphy_k(int k, gdinfo_t *gdinfo)
{
  return k - gdinfo->npoint_ghosts + gdinfo->nk1_to_glob_phys0;
}

/*
 * print for QC
 */

int
gd_info_print(gdinfo_t *gdinfo, gdinfo_t *gdinfo_n, gdinfo_t *gdinfo_car)
{    
  fprintf(stdout, "-------------------------------------------------------\n");
  fprintf(stdout, "--> grid info:\n");
  fprintf(stdout, "-------------------------------------------------------\n");
  fprintf(stdout, " nx    = %-10d\n", gdinfo->nx);
  fprintf(stdout, " ny    = %-10d\n", gdinfo->ny);
  fprintf(stdout, " nz    = %-10d\n", gdinfo->nz);
  fprintf(stdout, " ni    = %-10d\n", gdinfo->ni);
  fprintf(stdout, " nj    = %-10d\n", gdinfo->nj);
  fprintf(stdout, " nk    = %-10d\n", gdinfo->nk);

 /* fprintf(stdout, " ni1   = %-10d\n", gdinfo->ni1);
  fprintf(stdout, " ni2   = %-10d\n", gdinfo->ni2);
  fprintf(stdout, " nj1   = %-10d\n", gdinfo->nj1);
  fprintf(stdout, " nj2   = %-10d\n", gdinfo->nj2);
  fprintf(stdout, " nk1   = %-10d\n", gdinfo->nk1);
  fprintf(stdout, " nk2   = %-10d\n", gdinfo->nk2);*/

  fprintf(stdout, " nx_yang    = %-10d\n", gdinfo_n->nx);
  fprintf(stdout, " ny_yang    = %-10d\n", gdinfo_n->ny);
  fprintf(stdout, " nz_yang    = %-10d\n", gdinfo_n->nz);
  fprintf(stdout, " ni_yang    = %-10d\n", gdinfo_n->ni);
  fprintf(stdout, " nj_yang    = %-10d\n", gdinfo_n->nj);
  fprintf(stdout, " nk_yang    = %-10d\n", gdinfo_n->nk);

  fprintf(stdout, " nxx    = %-10d\n", gdinfo_car->nx);
  fprintf(stdout, " nyy    = %-10d\n", gdinfo_car->ny);
  fprintf(stdout, " nzz    = %-10d\n", gdinfo_car->nz);
  fprintf(stdout, " nii    = %-10d\n", gdinfo_car->ni);
  fprintf(stdout, " njj    = %-10d\n", gdinfo_car->nj);
  fprintf(stdout, " nkk    = %-10d\n", gdinfo_car->nk);

  /*fprintf(stdout, " nii1   = %-10d\n", gdinfo->nii1);
  fprintf(stdout, " nii2   = %-10d\n", gdinfo->nii2);
  fprintf(stdout, " njj1   = %-10d\n", gdinfo->njj1);
  fprintf(stdout, " njj2   = %-10d\n", gdinfo->njj2);
  fprintf(stdout, " nkk1   = %-10d\n", gdinfo->nkk1);
  fprintf(stdout, " nkk2   = %-10d\n", gdinfo->nkk2);*/

  fprintf(stdout, " ni1_to_glob_phys0   = %-10d\n", gdinfo->gni1);
  fprintf(stdout, " ni2_to_glob_phys0   = %-10d\n", gdinfo->gni2);
  fprintf(stdout, " nj1_to_glob_phys0   = %-10d\n", gdinfo->gnj1);
  fprintf(stdout, " nj2_to_glob_phys0   = %-10d\n", gdinfo->gnj2);

  return(0);
}
