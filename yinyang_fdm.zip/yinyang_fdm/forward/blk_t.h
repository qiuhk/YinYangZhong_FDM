#ifndef BLK_T_H
#define BLK_T_H

#include "constants.h"
#include "fd_t.h"
#include "gd_info.h"
#include "mympi_t.h"
#include "gd_t.h"
#include "md_t.h"
#include "wav_t.h"
#include "src_t.h"
#include "bdry_free.h"
#include "bdry_pml.h"
#include "io_funcs.h"

/*******************************************************************************
 * structure
 ******************************************************************************/

typedef struct
{
  // name for output file name
  char name[CONST_MAX_STRLEN];

  //// flag of medium
  //int medium_type;

  // fd
  fd_t    *fd;     // collocated grid fd
  fdstg_t *fdstg;  // staggered gridfd

  // mpi
  mympi_t *mympi;

  // grid index info
  gdinfo_t *gdinfo, *gdinfo_n, *gdinfo_car;
  
  // coordnate: x3d, y3d, z3d
  gd_t *gd, *gd_n, *gd_car;

  // grid metrics: jac, xi_x, etc
  gdcurv_metric_t *gdcurv_metric, *gdcurv_metric_n;

  // media: rho, lambda, mu etc
  md_t *md, *md_n, *md_car;

  // wavefield:
  wav_t *wav, *wav_n, *wav_car;
  
  // source term
  src_t *src;
  
  // free surface
  bdryfree_t *bdryfree,*bdryfree_n;
  
  // pml
  bdrypml_t *bdrypml;
  // exp
  //bdryexp_t *bdryexp;
  
  // io
  iorecv_t  *iorecv;
  ioline_t  *ioline;
  iosnap_t  *iosnap;
  ioslice_t *ioslice;

  // fname and dir
  char output_fname_part[CONST_MAX_STRLEN];
  // wavefield output
  char output_dir[CONST_MAX_STRLEN];
  // seperate grid output to save grid for repeat simulation
  char grid_export_dir[CONST_MAX_STRLEN];
  // seperate medium output to save medium for repeat simulation
  char media_export_dir[CONST_MAX_STRLEN];

  // exchange between blocks
  // point-to-point values
  int num_of_conn_points;
  int *conn_this_indx;
  int *conn_out_blk;
  int *conn_out_indx;
  // interp point
  int num_of_interp_points;
  int *interp_this_indx;
  int *interp_out_blk;
  int *interp_out_indx;
  float *interp_out_dxyz;

  // mem usage
  size_t number_of_float;
  size_t number_of_btye;
} blk_t;

/*******************************************************************************
 * function prototype
 ******************************************************************************/

int
blk_init(blk_t *blk,
         const int myid, const int verbose);

// set str
int
blk_set_output(blk_t *blk,
               mympi_t *mympi,
               char *output_dir,
               char *grid_export_dir,
               char *media_export_dir,
               const int verbose);

void
blk_colcent_mesg_init(mympi_t *mympi,
                int ni,
                int nj,
                int nk,
                int fdx_nghosts,
                int fdy_nghosts,
                int num_of_vars);

void
blk_colcent_pack_mesg(float *restrict w_cur,float *restrict sbuff,
                 int num_of_vars, gdinfo_t *gdinfo,
                 int   fdx_nghosts, int   fdy_nghosts);

void
blk_colcent_unpack_mesg(float *restrict rbuff,float *restrict w_cur,
                 int num_of_vars, gdinfo_t *gdinfo,
                 int   fdx_nghosts, int   fdy_nghosts);

void
blk_macdrp_mesg_init(mympi_t *mympi,
                fd_t *fd,
                int ni,
                int nj,
                int nk,
                int num_of_vars);

void
blk_macdrp_mesg_init_yang(mympi_t *mympi,
                fd_t *fd,
                int ni,
                int nj,
                int nk,
                int num_of_vars);

void
blk_macdrp_mesg_init_car(mympi_t *mympi,
                fd_t *fd,
                int ni,
                int nj,
                int nk,
                int num_of_vars);      

void
blk_macdrp_mesg_interp_init(mympi_t *mympi,
                gd_t *gd, gd_t *gd_n, gd_t *gd_car,
                int num_of_vars);                         

void
blk_macdrp_pack_mesg(float *restrict w_cur,
                 float *restrict sbuff,
                 int num_of_vars, gdinfo_t *gdinfo, mympi_t *mympi,
                 fd_op_t *fdx_op, fd_op_t *fdy_op);
               
void
blk_macdrp_pack_mesg_interp(float *restrict w_cur, float *restrict w_cur_n, float *restrict w_cur_car, 
                        float *restrict sbuff3, int num_of_vars, gd_t *gd, gdinfo_t *gdinfo,
                        gd_t *gd_n, gd_t *gd_car, gdinfo_t *gdinfo_car, mympi_t *mympi);

void
blk_macdrp_unpack_mesg_interp(float *restrict rbuff3, int num_of_vars, wav_t *wav, wav_t *wav_n, wav_t *wav_car, 
                              gd_t *gd, gdinfo_t *gdinfo,
                              gd_t *gd_n, gd_t *gd_car, gdinfo_t *gdinfo_car, mympi_t *mympi); 

void
blk_macdrp_unpack_mesg(float *restrict rbuff, 
                 float *restrict w_cur, 
                 int num_of_vars, gdinfo_t *gdinfo,mympi_t *mympi,
                 fd_op_t *fdx_op, fd_op_t *fdy_op,
                 size_t siz_x1, size_t siz_x2, size_t siz_y1,
                 int *neighid);

int
blk_print(blk_t *blk);

void
blk_stg_el1st_mesg_init(mympi_t *mympi,
                int ni,
                int nj,
                int nk,
                int fdx_nghosts,
                int fdy_nghosts);

void
blk_stg_el1st_pack_mesg_stress(fdstg_t *fd, 
            gdinfo_t *gdinfo, wav_t *wav, float *restrict sbuff);

void
blk_stg_el1st_unpack_mesg_stress(fdstg_t *fd,mympi_t *mympi, gdinfo_t *gdinfo, wav_t *wav,
    float *restrict rbuff, size_t siz_rbuff);

void
blk_stg_el1st_pack_mesg_vel(fdstg_t *fd, 
            gdinfo_t *gdinfo, wav_t *wav, float *restrict sbuff);

void
blk_stg_el1st_unpack_mesg_vel(fdstg_t *fd,mympi_t *mympi, gdinfo_t *gdinfo, wav_t *wav,
      float *restrict rbuff, size_t siz_rbuff);

void
blk_stg_ac_mesg_init(mympi_t *mympi,
                int ni,
                int nj,
                int nk,
                int fdx_nghosts,
                int fdy_nghosts);

void
blk_stg_ac1st_pack_mesg_pressure(fdstg_t *fd, gdinfo_t *gdinfo, wav_t *wav,
      float *restrict sbuff);

void
blk_stg_ac1st_unpack_mesg_pressure(fdstg_t *fd,mympi_t *mympi, gdinfo_t *gdinfo, wav_t *wav,
    float *restrict rbuff, size_t siz_rbuff);

void
blk_stg_ac1st_pack_mesg_vel(fdstg_t *fd, 
            gdinfo_t *gdinfo, wav_t *wav, float *restrict sbuff);

void
blk_stg_ac1st_unpack_mesg_vel(fdstg_t *fd,mympi_t *mympi, gdinfo_t *gdinfo, wav_t *wav,
      float *restrict rbuff, size_t siz_rbuff);
int
blk_dt_esti_curv(gdinfo_t *gdinfo,gdinfo_t *gdinfo_n, gdinfo_t *gdinfo_car, gd_t *gdcurv, gd_t *gdcurv_n,gd_t *gdcurv_car, 
    md_t *md, md_t *md_n, md_t *md_car,
    float CFL, float *dtmax, float *dtmaxVp, float *dtmaxL,
    int *dtmaxi, int *dtmaxj, int *dtmaxk, int  *whichregion);

int
blk_dt_esti_cart(gdinfo_t *gdinfo, gd_t *gdcart, md_t *md,
    float CFL, float *dtmax, float *dtmaxVp, float *dtmaxL,
    int *dtmaxi, int *dtmaxj, int *dtmaxk);

float
blk_keep_two_digi(float dt);

#endif
