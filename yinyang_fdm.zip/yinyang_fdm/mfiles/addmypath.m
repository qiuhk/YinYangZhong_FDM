 dirnm = '../mfiles'
 addpath(genpath(dirnm))