%%% surf yin-yang wavefield of surface with topo_surface
%%% only xyz component, no rcf component
%%% now only can plot Vx
clear all;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project_mars/test.json';
output_dir='../project_mars/output';

% which snapshot to plot
id{1}=1;
subs{1}=[1,1,177];      % start from index '1'
subc{1}=[-1,-1,1];     % '-1' to plot all points in this dimension
subt{1}=[4,2,1];


% variable and time to plot
varnm='Vz';
ns=10;
ne=25;% 30 is 1160s
nt=5;

% figure control parameters
flag_km     = 1;
flag_emlast = 1;
flag_print  = 0;
flag_light  = 1;
savegif = 1;
plot_surface_topo =1;%plot surface layer topo

scl_caxis=[-6*1e0 6*1e0];%e2
filename1 = [varnm,'_surface.gif'];
scl_daspect =[1 1 1];
clrmp = 'jetwr';  % ����jetwr���Զ��岨��ɫͼ
taut=0.5;
% ---------------------------------------------------------------------- %



% locate snapshot and load coordinate
for i=1:length(subs)
    
    % locate snapshot
    snapinfo{i}=locate_snap(parfnm,id{i},'start',subs{i},'count',subc{i},'stride',subt{i},'snapdir',output_dir);
    % get coordinate data
    [f{i},c{i},r{i}]=gather_coord(snapinfo{i},'coorddir',output_dir);
    [fn{i},cn{i},rn{i}]=gather_coord_yang(snapinfo{i},'coorddir',output_dir);
    
    [x{i},y{i},z{i}] = sph2cart(f{i},pi/2-c{i},r{i});
    [xn{i},yn{i},zn{i}] = sph2cart(fn{i},pi/2-cn{i},rn{i});
    
    % coordinate unit
    str_unit='m';
    if flag_km
        x{i}=x{i}/1e3;
        y{i}=y{i}/1e3;
        z{i}=z{i}/1e3;
        xn{i}=xn{i}/1e3;
        yn{i}=yn{i}/1e3;
        zn{i}=zn{i}/1e3;
        str_unit='km';
    end

end

% figure plot
hid=figure;
set(hid,'BackingStore','on');


% snapshot show
for nlayer=ns:nt:ne
    
    clf(gcf);  % �����һ֡������ͼ��
    ax = gca;  % ��ȡ��ǰ�����ᣬͳһ�ڸ����ϻ���
    hold(ax, 'on');  % ���������ᣬȷ�����κͲ�������
    
    if plot_surface_topo == 1
        rr = 3390000;
        topo_data = (squeeze(permute(r{1},[2 1 3])) - rr)./1000;
        topo_datan = (squeeze(permute(rn{1},[2 1 3])) - rr)./1000;
        % ��һ���������ݵ�[0,1]
        topo_min = min([topo_data(:); topo_datan(:)]);
        topo_max = max([topo_data(:); topo_datan(:)]);
        topo_norm = (topo_data - topo_min) / (topo_max - topo_min + 1e-10);
        topo_datan_norm = (topo_datan - topo_min) / (topo_max - topo_min + 1e-10);

        % ��copper colormap���ɵ���RGB��ɫ��������������ɫͼ��
        cmap_topo = copper(256);
        cmap_topo_bright = brighten(cmap_topo, 0.3);  %����
        topo_rgb = ind2rgb(round(topo_norm * 255) + 1, cmap_topo_bright);
        topo_datan_rgb = ind2rgb(round(topo_datan_norm * 255) + 1, cmap_topo_bright);
        
        % ���Ƶ��Σ��ڵ�ǰ������ax�ϣ�
        surf(ax, ...
             squeeze(permute(x{1},[2 1 3])), ...
             squeeze(permute(y{1},[2 1 3])), ...
             squeeze(permute(z{1},[2 1 3])), ...
             topo_rgb, ...  % ֱ����RGB��ɫ������������ɫͼ
             'FaceColor', 'interp', ...
             'EdgeColor', 'none');
        surf(ax, ...
             squeeze(permute(xn{1},[2 1 3])), ...
             squeeze(permute(yn{1},[2 1 3])), ...
             squeeze(permute(zn{1},[2 1 3])), ...
             topo_datan_rgb, ...
             'FaceColor', 'interp', ...
             'EdgeColor', 'none');
         
        shading(ax, 'interp');
        axis(ax, 'equal');
    end
    
    for i=1:length(subs)  % i=1���������ݴ���
         
        [vf{i},~]=gather_snap(snapinfo{i},nlayer,'Vf','snapdir',output_dir);
        [vc{i},~]=gather_snap(snapinfo{i},nlayer,'Vc','snapdir',output_dir);
        [vr{i},~]=gather_snap(snapinfo{i},nlayer,'Vr','snapdir',output_dir);
        [vfn{i},~]=gather_snap(snapinfo{i},nlayer,'Vfn','snapdir',output_dir);
        [vcn{i},~]=gather_snap(snapinfo{i},nlayer,'Vcn','snapdir',output_dir);
        [vrn{i},t]=gather_snap(snapinfo{i},nlayer,'Vrn','snapdir',output_dir);
        
        % ���㲨������
        vx{i} = sin(c{i}).*cos(f{i}).*vr{i} + cos(c{i}).*cos(f{i}).*vc{i} - sin(f{i}).*vf{i};
        vy{i} = sin(c{i}).*sin(f{i}).*vr{i} + cos(c{i}).*sin(f{i}).*vc{i} + cos(f{i}).*vf{i};
        vz{i} = cos(c{i}).*vr{i}            - sin(c{i}).*vc{i}                              ;
        vxn{i} = sin(cn{i}).*cos(fn{i}).*vrn{i} + cos(cn{i}).*cos(fn{i}).*vcn{i} - sin(fn{i}).*vfn{i};
        vyn{i} = sin(cn{i}).*sin(fn{i}).*vrn{i} + cos(cn{i}).*sin(fn{i}).*vcn{i} + cos(fn{i}).*vfn{i};
        vzn{i} = cos(cn{i}).*vrn{i}            - sin(cn{i}).*vcn{i}                              ;
        
        % ��ʾʱ����Ϣ
        if i==1
            disp([ '  draw ' num2str(nlayer) 'th time step (t=' num2str(t) ')']);
        end
        
        %%%%%  change alpha %%%%%%
        level = 0.5;%�������ֵlevel�����ϵ�alp��͸����
        alp = 0.7;
        wave_offset = 1.01;%z��ƫ����
        
        wave_yin = vx{i}(:);    % �����ֲ������ݣ��°���ȣ�
        wave_yang = vxn{i}(:);  % �����ֲ������ݣ��ϰ���ȣ�
        all_wave = [wave_yin; wave_yang];  % �ϲ����в�������
        global_max = max(abs(all_wave));  
        
        threshold = level * global_max;  

        alpha_yin = abs(vx{i}) / threshold ;  % ����ֵ��0~1+��
        alpha_yin(alpha_yin > 1) = 1;  % ������ֵ������͸����alpha=1��

        % ������ͬ��
        alpha_yang = abs(vxn{i}) / threshold;
        alpha_yang(alpha_yang > 1) = 1;
        
        alpha_yin = alpha_yin * alp;
        alpha_yang = alpha_yang * alp;
        
        % ���������ص������͸����Ϊ0
        nf = size(c{i},1);
        nc = size(c{i},2);
        for m = 1:nf
            for n = 1:nc
                if fn{i}(m,n)>min(min(f{i})) && fn{i}(m,n)<max(max(f{i})) && ...
                   cn{i}(m,n)>min(min(c{i})) && cn{i}(m,n)<max(max(c{i}))
                    
                   alpha_yang(m,n) = 0;
                end
            end
        end
        
        alpha_yin_adj = squeeze(permute(alpha_yin, [2 1 3]));
        alpha_yang_adj = squeeze(permute(alpha_yang, [2 1 3]));

        % �ڵ�ǰ������ax�ϻ��Ʋ���
        surf(ax, ...
            squeeze(permute(x{i},[2 1 3])) *wave_offset, ...
            squeeze(permute(y{i},[2 1 3])) *wave_offset, ...
            squeeze(permute(z{i},[2 1 3])) *wave_offset, ...
            squeeze(permute(vx{i},[2 1 3])), ...
            'EdgeColor', 'none', ...
            'AlphaData', alpha_yin_adj, ...  % ����͸���Ⱦ���
            'FaceAlpha', 'interp', ...  % �ؼ�����FaceColor='interp'ƥ�䣬ʹ�ò�ֵ͸����
            'FaceColor', 'interp');  % ��ʽָ����ɫ��ֵ����͸����ģʽͬ����
        surf(ax, ...
            squeeze(permute(xn{i},[2 1 3])) *wave_offset, ...
            squeeze(permute(yn{i},[2 1 3])) *wave_offset, ...
            squeeze(permute(zn{i},[2 1 3])) *wave_offset, ...
            squeeze(permute(vxn{i},[2 1 3])), ...
            'EdgeColor', 'none', ...
            'AlphaData', alpha_yang_adj, ...
            'FaceAlpha', 'interp', ...  % �ؼ�����FaceColor='interp'ƥ�䣬ʹ�ò�ֵ͸����
            'FaceColor', 'interp');  % ��ʽָ����ɫ��ֵ����͸����ģʽͬ����
    end
    
    % �����������ǩ
    xlabel(ax, ['X axis (' str_unit ')']);
    ylabel(ax, ['Y axis (' str_unit ')']);
    zlabel(ax, ['Z axis (' str_unit ')']);
    
    set(ax, 'Layer', 'top');
    set(gcf, 'Color', 'white', 'Renderer', 'painters');
    shading(ax, 'interp');
    if exist('scl_daspect')
        daspect(ax, scl_daspect);
    end

    % ����colorbar������ʾ��һ����
    if exist('clrmp', 'var')
        load seismic;
        colormap(ax, newColorMap);  % �󶨲���ɫͼ����ǰ��
        cb_wave = colorbar;  % ����colorbar
        cb_wave.Label.String = 'Wave Amplitude';
        if exist('scl_caxis', 'var')
            caxis(ax, scl_caxis);  % ���ò�����ɫ��Χ
        end
    end
    
    % ���պ��ӽ�����
    if flag_light
        view(ax, 60, 20);
%        set(ax, 'Box', 'off','Visible', 'off');
        camlight(ax, 10, 10, 'local');
        lighting(ax, 'phong');
        material(ax, 'dull'); 
    end
    ax.XAxis.Visible='off';
    ax.YAxis.Visible='off';
    ax.ZAxis.Visible='off';
    
    % ����
    titlestr = ['Snapshot of ' varnm ' at ' ...
        '{\fontsize{12}{\bf ' num2str(t, '%7.3f') '}}s'];
    title(ax, titlestr);
    
    drawnow;
    pause(taut);
    
    % ����GIF
    if savegif
        im = frame2im(getframe(gcf));
        [imind, map] = rgb2ind(im, 256);
        if nlayer == ns
            imwrite(imind, map, filename1, 'gif', 'LoopCount', Inf, 'DelayTime', 0.5);
        else
            imwrite(imind, map, filename1, 'gif', 'WriteMode', 'append', 'DelayTime', 0.5);
        end
    end
    
    % ����ͼƬ
    if flag_print == 1
        width = 500;
        height = 500;
        set(gcf, 'PaperPositionMode', 'manual');
        set(gcf, 'PaperUnits', 'points');
        set(gcf, 'PaperSize', [width, height]);
        set(gcf, 'PaperPosition', [0, 0, width, height]);
        fnm_out = [varnm '_surface_topo_', num2str(nlayer, '%5.5i')];
        print(gcf, [fnm_out '.png'], '-dpng');
    end
    
end