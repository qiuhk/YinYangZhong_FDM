%%% plot car and polar seismoline ,not support recvid,defaulted is x/z;
%%% must nrecv agrees
clear all;
close all;
clc;
addmypath;
%% set params
% file and path name
parfnm='../project_mars_notopo/test.json';
output_dir='../project_mars_notopo/output';

parfnm_car='../../CGFD3D-elastic/project/test.json';
output_dir_car='../../CGFD3D-elastic/project/output';

% which line to plot (start from index '1')
lineid = 1;
compare = 0;

% which variable to plot
varnm='Vx';

% figure control parameters
flag_print=1;

%% read data

%%% read polar
par=loadjson(parfnm);

fileID = fopen(par.in_source_file);
lineprefix = fgetl(fileID);
while(lineprefix(1) == "#")
    lineprefix = fgetl(fileID);
    if(lineprefix(1) ~= "#")

        break;
    end
end

% line name and receiver number
linenm=par.receiver_line{lineid}.name;
nrec=par.receiver_line{lineid}.grid_index_count;

% load data
for irec=0:nrec-1
    
    sacnm=[output_dir,'/',lineprefix,'.',linenm,'.','no',num2str(irec),'.',varnm,'.sac'];
    sacdata=rsac(sacnm);
    seismodata(irec+1,:)=sacdata(:,2);
    seismot(irec+1,:)=sacdata(:,1);
    
    sacnm=[output_dir,'/',lineprefix,'.',linenm,'.','no',num2str(irec),'.','Vx','.sac'];
    sacdata=rsac(sacnm);
    seismodata_vf(irec+1,:)=sacdata(:,2);
    
    sacnm=[output_dir,'/',lineprefix,'.',linenm,'.','no',num2str(irec),'.','Vy','.sac'];
    sacdata=rsac(sacnm);
    seismodata_vc(irec+1,:)=sacdata(:,2);
    
    sacnm=[output_dir,'/',lineprefix,'.',linenm,'.','no',num2str(irec),'.','Vz','.sac'];
    sacdata=rsac(sacnm);
    seismodata_vr(irec+1,:)=sacdata(:,2);
    
    [f(irec+1,1),c(irec+1,1),r(irec+1,1)] = lh(sacdata,'STLA','STLO','STEL');
    
    [x,y,z] = sph2cart(f(irec+1,1),pi/2-c(irec+1,1),r(irec+1,1));
    
    fprintf("f,c,r of NO.%d recv is %.3f, %.3f, %.3f; xyz is %.1f, %.1f, %.1f.\n",...
        irec+1,f(irec+1,1),c(irec+1,1),r(irec+1,1),x,y,z);
    
end

%%%% read car
if compare == 1
    par=loadjson(parfnm_car);

    fileID = fopen(par.in_source_file);
    lineprefix = fgetl(fileID);
    while(lineprefix(1) == "#")
        lineprefix = fgetl(fileID);
        if(lineprefix(1) ~= "#")

            break;
        end
    end

    % line name and receiver number
    linenm_car=par.receiver_line{lineid}.name;
    nrec=par.receiver_line{lineid}.grid_index_count;

    % load data
    for irec=0:nrec-1

        sacnm=[output_dir_car,'/',lineprefix,'.',linenm_car,'.','no',num2str(irec),'.',varnm,'.sac'];
        sacdata_car=rsac(sacnm);
        seismodata_car(irec+1,:)=sacdata_car(:,2);

    end
end
%% plot line
%read r/c_station
varnm_fig = varnm;

% increment of show for Y-axis ticklabel
ytickincre=5;  %no use
figure;

%convert rc to xz
if strcmp(varnm,'Vx')
 seismodata = sin(c).*cos(f).*seismodata_vr + cos(c).*cos(f).*seismodata_vc - sin(f).*seismodata_vf;
elseif strcmp(varnm,'Vy')
 seismodata = sin(c).*sin(f).*seismodata_vr + cos(c).*sin(f).*seismodata_vc + cos(f).*seismodata_vf;
elseif strcmp(varnm,'Vz')
 seismodata = cos(c).*seismodata_vr         - sin(c).*seismodata_vc;
end

scl=max(max(abs(seismodata)));
%scl_car=max(max(abs(seismodata_car)));
%polar is ( , ],so we abandon 0th of polar and car
for irec=0:nrec-1
    %plot(seismot(irec+1,:),seismodata(irec+1,:)+irec*(2*scl),'b');
%    diff = seismodata(nrec-irec,:)-seismodata_car(irec+1,:);
    
    plot(seismot(irec+1,:),seismodata(irec+1,:)+irec*(2*scl),'b','LineWidth',2);%reserve
    hold on;
%     %use data_car replace data_ploar
    if compare == 1
        plot(seismot(irec+1,:),seismodata_car(irec+1,:) +irec*(2*scl),'c','LineWidth',2);
        hold on;

        diff = seismodata(irec+1 ,:) - seismodata_car(irec+1,:);
        plot(seismot(irec+1,:),diff/4 +irec*(2*scl)-scl,'r','LineWidth',1);
        hold on;
  %     plot(seismot(irec+1,:),diff/2+(irec-0.5)*(2*scl),'c','LineWidth',2);
  %     hold on;
        %cal xcross
        r= corrcoef(seismodata(irec+1 ,:),seismodata_car(irec+1,:));
        R(irec+1) = r(1,2);
    end
end
if compare == 1
  hl = legend('sphere','cartesian','diff');  
else
  hl = legend('sphere');
end

set(hl,'FontName','Times New Roman','FontSize',11,'Box','off')

xlabel('t / s','FontName','Times New Roman','FontSize',11);

%ylabel('Receiver ID');
%title([varnm_fig,' at No.',num2str(lineid), ' Receiver Line ','(',linenm,')'],'interpreter','none');
set(gca,'ytick',[0:1:nrec-1]*(2*scl),'yticklabel',[1:1:nrec]);
set(gca,'ylim',[-2,nrec+1]*(2*scl));
set(gcf,'position',[0,0,400,800]);
set(gcf,'color','white','renderer','painters');

% save and print figure
if flag_print
    width= 400;
    height=800;
    set(gcf,'paperpositionmode','manual');
    set(gcf,'paperunits','points');
    set(gcf,'papersize',[width,height]);
    set(gcf,'paperposition',[0,0,width,height]);
    print(gcf,[varnm_fig,'_line_no',num2str(lineid),'.png'],'-dpng');
end

% if output waveform for comparing
output = 1;
if output == 1
    % write waveform
    fid = fopen('lon-120_notopo_vx.txt', 'w');
    for i = 1:length(seismot(1,:))
        fprintf(fid, '%.6f\t%.6f\n', seismot(1,i), seismodata(1,i));
    end
    fclose(fid);
end
    

