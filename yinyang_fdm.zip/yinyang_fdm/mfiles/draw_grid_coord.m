% Plot the grid
% Author:       Yuanhang Huo
% Email:        yhhuo@mail.ustc.edu.cn
% Affiliation:  University of Science and Technology of China
% Date:         2021.06.06
clc;
clear all;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project_check/test.json';
output_dir='../project_check/output';

% which grid profile to plot
subs=[1,1,1];     % start from index '1'
subc=[-1,-1,5];     % '-1' to plot all points in this dimension
subt=[10,10,10];

% figure control parameters
flag_km     = 1;
flag_emlast = 1;
flag_print  = 1;
flag_title  = 1;
scl_daspect = [1 1 1];
% ---------------------------------------------------------------------- %



% load grid coordinate
coordinfo=locate_coord(parfnm,'start',subs,'count',subc,'stride',subt,'coorddir',output_dir);
[f,c,r]=gather_coord_yang(coordinfo,'coorddir',output_dir);
nx=size(f,1);
ny=size(f,2);
nz=size(f,3);
[x,y,z] = sph2cart(f,pi/2-c,r);
% coordinate unit
str_unit='m';
if flag_km
   x=x/1e3;
   y=y/1e3;
   z=z/1e3;
   str_unit='km';
end

% plot
x=squeeze(x);
y=squeeze(y);
z=squeeze(z);
pltincre1=1; % incre
pltincre2=1;
figure;
if nx == 1
    plot(permute(y(1:pltincre1:end,1:pltincre2:end),[2,1]),...
         permute(z(1:pltincre1:end,1:pltincre2:end),[2,1]),...
        'k-');
    hold on;
    plot(y(1:pltincre1:end,1:pltincre2:end),...
         z(1:pltincre1:end,1:pltincre2:end),...
        'k-');
    xlabel(['Y axis (' str_unit ')']);
    ylabel(['Z axis (' str_unit ')']);
    
    figure;
    surf(x(1:pltincre1:end,1:pltincre2:end),y(1:pltincre1:end,1:pltincre2:end),...
         z(1:pltincre1:end,1:pltincre2:end),'edgecolor','none');
     
elseif ny == 1
    plot(permute(x(1:pltincre1:end,1:pltincre2:end),[2,1]),...
         permute(z(1:pltincre1:end,1:pltincre2:end),[2,1]),...
         'k-');
    hold on;
    plot(x(1:pltincre1:end,1:pltincre2:end),...
         z(1:pltincre1:end,1:pltincre2:end),...
         'k-');
    xlabel(['X axis (' str_unit ')']);
    ylabel(['Z axis (' str_unit ')']);
     
    figure;
    surf(x(1:pltincre1:end,1:pltincre2:end),y(1:pltincre1:end,1:pltincre2:end),...
         z(1:pltincre1:end,1:pltincre2:end),'edgecolor','none');
else
%     plot(permute(x(1:pltincre1:end,1:pltincre2:end),[2,1]),...
%          permute(y(1:pltincre1:end,1:pltincre2:end),[2,1]),...
%          'k-');
%     hold on;
%     plot(x(1:pltincre1:end,1:pltincre2:end),...
%          y(1:pltincre1:end,1:pltincre2:end),...
%          'k-');
%     xlabel(['X axis (' str_unit ')']);
%     ylabel(['Y axis (' str_unit ')']);
    surf(x(1:pltincre1:end,1:pltincre2:end),y(1:pltincre1:end,1:pltincre2:end),...
         z(1:pltincre1:end,1:pltincre2:end),'edgecolor','none');
end

set(gca,'layer','top');
set(gcf,'color','white','renderer','painters');

% axis daspect
if exist('scl_daspect')
    daspect(scl_daspect);
end
axis tight;

% title
if flag_title
    if nx == 1
        gridtitle='YOZ-Grid';
    elseif ny == 1
        gridtitle='XOZ-Grid';
    else
        gridtitle='XOY-Grid';
    end
    title(gridtitle);
end

% save and print figure
if flag_print
    width= 500;
    height=500;
    set(gcf,'paperpositionmode','manual');
    set(gcf,'paperunits','points');
    set(gcf,'papersize',[width,height]);
    set(gcf,'paperposition',[0,0,width,height]);
    print(gcf,[gridtitle '.png'],'-dpng');
end


