% Draw seismic wavefield snapshot on multi cross-sections by using surf style
% Author:       Yuanhang Huo
% Email:        yhhuo@mail.ustc.edu.cn
% Affiliation:  University of Science and Technology of China
% Date:         2021.06.09

clear all;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project_mars/test.json';
output_dir='../project_mars/output';

% which snapshot to plot
% profile 2
id{1}=1;
subs{1}=[752,1,1];      % start from index '1'
subc{1}=[1,-1,-1];     % '-1' to plot all points in this dimension
subt{1}=[1,1,1];
%profile 3
% id{2}=2;
% subs{2}=[1,252,1];      % start from index '1'
% subc{2}=[-1,1,-1];     % '-1' to plot all points in this dimension
% subt{2}=[1,1,1];

% profile 1
% id{3}=3;
% subs{3}=[1,1,3];      % start from index '1'
% subc{3}=[-1,-1,1];     % '-1' to plot all points in this dimension
% subt{3}=[1,1,1];

% variable and time to plot
varnm='Vf';
ns=2;
ne=30;%16
nt=2;

% figure control parameters
flag_km     = 1;
flag_emlast = 1;
flag_print  = 0;
flag_light  = 1;
savegif = 1;
scl_caxis=[-1*1e0 1*1e0];
% scl_caxis=[-1.0 1.0];
filename1 = ['Vz.gif'];
scl_daspect =[1 1 1];
clrmp = 'jetwr';
taut=0.5;
% ---------------------------------------------------------------------- %



% locate snapshot and load coordinate
for i=1:length(subs)
    
    % locate snapshot
    snapinfo{i}=locate_snap(parfnm,id{i},'start',subs{i},'count',subc{i},'stride',subt{i},'snapdir',output_dir);
    % get coordinate data
    [f{i},c{i},r{i}]=gather_coord(snapinfo{i},'coorddir',output_dir);
    [fn{i},cn{i},rn{i}]=gather_coord_yang(snapinfo{i},'coorddir',output_dir);
    nx{i}=size(f{i},1);
    ny{i}=size(f{i},2);
    nz{i}=size(f{i},3);
    [x{i},y{i},z{i}] = sph2cart(f{i},pi/2-c{i},r{i});
    [xn{i},yn{i},zn{i}] = sph2cart(fn{i},pi/2-cn{i},rn{i});
    % coordinate unit
    str_unit='m';
    if flag_km
        x{i}=x{i}/1e3;
        y{i}=y{i}/1e3;
        z{i}=z{i}/1e3;
        xn{i}=xn{i}/1e3;
        yn{i}=yn{i}/1e3;
        zn{i}=zn{i}/1e3;
        str_unit='km';
    end

end

% figure plot
hid=figure;
set(hid,'BackingStore','on');


% snapshot show
for nlayer=ns:nt:ne
    
    for i=1:length(subs)
        
        [v{i},~]=gather_snap(snapinfo{i},nlayer,varnm,'snapdir',output_dir);
        [vf{i},~]=gather_snap(snapinfo{i},nlayer,'Vf','snapdir',output_dir);
        [vc{i},~]=gather_snap(snapinfo{i},nlayer,'Vc','snapdir',output_dir);
        [vr{i},~]=gather_snap(snapinfo{i},nlayer,'Vr','snapdir',output_dir);
        [vfn{i},~]=gather_snap(snapinfo{i},nlayer,'Vfn','snapdir',output_dir);
        [vcn{i},~]=gather_snap(snapinfo{i},nlayer,'Vcn','snapdir',output_dir);
        [vrn{i},t]=gather_snap(snapinfo{i},nlayer,'Vrn','snapdir',output_dir);
        
        vx{i} = sin(c{i}).*cos(f{i}).*vr{i} + cos(c{i}).*cos(f{i}).*vc{i} - sin(f{i}).*vf{i};
        vy{i} = sin(c{i}).*sin(f{i}).*vr{i} + cos(c{i}).*sin(f{i}).*vc{i} + cos(f{i}).*vf{i};
        vz{i} = cos(c{i}).*vr{i}            - sin(c{i}).*vc{i}                              ;
        vxn{i} = sin(cn{i}).*cos(fn{i}).*vrn{i} + cos(cn{i}).*cos(fn{i}).*vcn{i} - sin(fn{i}).*vfn{i};
        vyn{i} = sin(cn{i}).*sin(fn{i}).*vrn{i} + cos(cn{i}).*sin(fn{i}).*vcn{i} + cos(fn{i}).*vfn{i};
        vzn{i} = cos(cn{i}).*vrn{i}            - sin(cn{i}).*vcn{i}                              ;
        
        % show time
        if i==1
            disp([ '  draw ' num2str(nlayer) 'th time step (t=' num2str(t) ')']);
        end
        
        
%         a=find(abs(vx{i})<1e-1);
%         vx{i}(a)=NaN;
%         a=find(abs(vxn{i})<1e-1);
%         vxn{i}(a)=NaN;
        
        
        % show snapshot
        if flag_emlast
            sid{i}=surf(squeeze(permute(x{i},[2 1 3])), ...
                squeeze(permute(y{i},[2 1 3])), ...
                squeeze(permute(z{i},[2 1 3])), ...
                squeeze(permute(vz{i},[2 1 3])));
            hold on;
            sid{i}=surf(squeeze(permute(xn{i},[2 1 3])), ...
                squeeze(permute(yn{i}+0,[2 1 3])), ...
                squeeze(permute(zn{i},[2 1 3])), ...
                squeeze(permute(vzn{i},[2 1 3])));
            
        else
            sid{i}=surf(flipdim(squeeze(permute(x{i},[2 1 3])),3), ...
                flipdim(squeeze(permute(y{i}-5,[2 1 3])),3), ...
                flipdim(squeeze(permute(z{i}-5,[2 1 3])),3), ...
                flipdim(squeeze(permute(v{i},[2 1 3])),3));
        end
        
        hold on;
%         view(45, 45);
    end
    
    hold off;
        
    xlabel(['X axis (' str_unit ')']);
    ylabel(['Y axis (' str_unit ')']);
    zlabel(['Z axis (' str_unit ')']);
    
    set(gca,'layer','top');
    set(gcf,'color','white','renderer','painters');
    
    % axis image
    % shading interp;
    shading flat;
    % colorbar range/scale
    if exist('scl_caxis')
        caxis(scl_caxis);
    end
    % axis daspect
    if exist('scl_daspect')
        daspect(scl_daspect);
    end
    % colormap and colorbar
    if exist('clrmp')
       load seismic;
       colormap(newColorMap);
      %   colormap(clrmp);
    end
    colorbar('vert');
    if flag_light
      %  view(-40,35);
     view(-45, 30); %yang center
     %  view(85, 30); %yin center
        set(gca,'box','off');
        camlight(0,10,'local');
        lighting phong;
    end
    
    % title
%     titlestr=['Snapshot of ' varnm ' at ' ...
      titlestr=['Snapshot of ' 'Vz' ' at ' ...
        '{\fontsize{12}{\bf ' ...
        num2str((t),'%7.3f') ...
        '}}s'];
    title(titlestr);
    
    drawnow;
    pause(taut);
    %save gif
    if savegif
      im=frame2im(getframe(gcf));
      [imind,map]=rgb2ind(im,256);
      if nlayer==ns
        imwrite(imind,map,filename1,'gif','LoopCount',Inf,'DelayTime',0.5);
      else
        imwrite(imind,map,filename1,'gif','WriteMode','append','DelayTime',0.5);
      end
    end
    % save and print figure
    if flag_print==1
        width= 500;
        height=500;
        set(gcf,'paperpositionmode','manual');
        set(gcf,'paperunits','points');
        set(gcf,'papersize',[width,height]);
        set(gcf,'paperposition',[0,0,width,height]);
        fnm_out=[varnm '_sphere_',num2str(nlayer,'%5.5i')];
        print(gcf,[fnm_out '.png'],'-dpng');
    end
    
end


