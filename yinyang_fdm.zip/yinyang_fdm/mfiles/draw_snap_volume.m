%%% vol_show wavefield of yin-yang wavefield
%%% only xyz component, no rcf component
%%% you should determine subt,subt_car,gridsize
clear all;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project_car3/test.json';
output_dir='../project_car3/output';

%%% parameter you should change
subt=[2,2,1];

subt_car=[5,5,5];

gridsize = 100; %grid point of sphere area,200 is max
volmax = 2; %vlo < volmax equals nan
% variable and time to plot
varnm='Vz';
ns=12;
ne=14;%30 is 1200s
nt=20;

% figure control parameters
flag_km     = 1;
flag_emlast = 1;
flag_print  = 0;
flag_light  = 1;
savegif = 1;

scl_caxis=[-.1*1e2 .1*1e2];%e2
% scl_caxis=[-1.0 1.0];
filename1 = [varnm,'_volume.gif'];
scl_daspect =[1 1 1];
clrmp = 'jetwr';
taut=0.5;
% ---------------------------------------------------------------------- %



% locate snapshot and load coordinate
% locate snapshot
snapinfo=locate_snap(parfnm,1,'start',[1,1,1],'count',[-1,-1,-1],'stride',subt,'snapdir',output_dir);
% get coordinate data
[f,c,r]=gather_coord(snapinfo,'coorddir',output_dir);
[fn,cn,rn]=gather_coord_yang(snapinfo,'coorddir',output_dir);

[x,y,z] = sph2cart(f,pi/2-c,r);
[xn,yn,zn] = sph2cart(fn,pi/2-cn,rn);

%%%%%  car
snapinfo_car=locate_snap_car(parfnm,1,'start',[1,1,1],'count',[-1,-1,-1],'stride',subt_car,'snapdir',output_dir);
% get coordinate data
[x1,y1,z1]=gather_coord_car(snapinfo_car,'coorddir',output_dir);

% coordinate unit
str_unit='m';
if flag_km
    x=x/1e3;
    y=y/1e3;
    z=z/1e3;
    xn=xn/1e3;
    yn=yn/1e3;
    zn=zn/1e3;
    x1=x1/1e3;
    y1=y1/1e3;
    z1=z1/1e3;
    str_unit='km';
end



% figure plot
hid=figure;
set(hid,'BackingStore','on');

% generate uniform grid
x_min = min(min(min(min(x))),min(min(min(xn))));
y_min = min(min(min(min(y))),min(min(min(yn))));
z_min = min(min(min(min(z))),min(min(min(zn))));
x_max = max(max(max(max(x))),max(max(max(xn))));
y_max = max(max(max(max(y))),max(max(max(yn))));
z_max = max(max(max(max(z))),max(max(max(zn))));

xrange = linspace(x_min, x_max, gridsize); 
yrange = linspace(y_min, y_max, gridsize); 
zrange = linspace(z_min, z_max, gridsize); 
[Xq, Yq, Zq] = meshgrid(xrange, yrange, zrange); 

alp = ones(gridsize,gridsize,gridsize);
alpn = ones(gridsize,gridsize,gridsize);

% snapshot show
disp('start time loop');
for nlayer=ns:nt:ne
    
        
    [v_car,~]=gather_snap(snapinfo_car,nlayer,varnm,'snapdir',output_dir);

    [vf,~]=gather_snap(snapinfo,nlayer,'Vf','snapdir',output_dir);
    [vc,~]=gather_snap(snapinfo,nlayer,'Vc','snapdir',output_dir);
    [vr,~]=gather_snap(snapinfo,nlayer,'Vr','snapdir',output_dir);
    [vfn,~]=gather_snap(snapinfo,nlayer,'Vfn','snapdir',output_dir);
    [vcn,~]=gather_snap(snapinfo,nlayer,'Vcn','snapdir',output_dir);
    [vrn,t]=gather_snap(snapinfo,nlayer,'Vrn','snapdir',output_dir);

    vx = sin(c).*cos(f).*vr + cos(c).*cos(f).*vc - sin(f).*vf;
    vy = sin(c).*sin(f).*vr + cos(c).*sin(f).*vc + cos(f).*vf;
    vz = cos(c).*vr         - sin(c).*vc                     ;
    vxn = sin(cn).*cos(fn).*vrn + cos(cn).*cos(fn).*vcn - sin(fn).*vfn;
    vyn = sin(cn).*sin(fn).*vrn + cos(cn).*sin(fn).*vcn + cos(fn).*vfn;
    vzn = cos(cn).*vrn          - sin(cn).*vcn                        ;

    %reshape sphere data  
    % interp to new grid 
    disp(' start to interp');
    
    if strcmp(varnm,'Vx') 
        vol = griddata(x, y, z, vx, Xq, Yq, Zq, 'linear');
        voln = griddata(xn, yn, zn, vxn, Xq, Yq, Zq, 'linear');
    elseif strcmp(varnm,'Vy') 
        vol = griddata(x, y, z, vy, Xq, Yq, Zq, 'linear');
        voln = griddata(xn, yn, zn, vyn, Xq, Yq, Zq, 'linear');
    else
        vol = griddata(x, y, z, vz, Xq, Yq, Zq, 'linear');
        voln = griddata(xn, yn, zn, vzn, Xq, Yq, Zq, 'linear');
    end
        
    vol(abs(vol)<volmax) = nan;
    voln(abs(voln)<volmax) = nan;

    
    alp(isnan(vol))=0;
    alpn(isnan(voln))=0;

    % show time
    disp([ ' draw ' num2str(nlayer) 'th time step (t=' num2str(t) ')']);

    % reshape data

    % show volume
    volume_view('cdata', vol, 'texture', '3D','alpha',alp);
    hold on;
    volume_view('cdata', voln, 'texture', '3D','alpha',alpn); 
    
    set(gca,'layer','top');
    set(gcf,'color','white','renderer','painters');
    
    % axis image

    shading flat;
    % colorbar range/scale
    if exist('scl_caxis')
        caxis(scl_caxis);
    end
    % axis daspect
    if exist('scl_daspect')
        daspect(scl_daspect);
    end
    % colormap and colorbar
    if exist('clrmp')
       load seismic;
       colormap(newColorMap);
     % colormap(clrmp);
    end
    colorbar('vert');
    
    if flag_light
        view(-145,-15);%volume
        %view(-45, 30); %yang center is -80,30
        %view(85, 30); %yin center
        light('Position',[-1 -1 1],'Style','local');
        set(gca,'box','off');
        lighting phong;
        material  dull;
    end
    
    set(gca,'xtick',[],'xticklabel',[]);
    set(gca,'ytick',[],'yticklabel',[]);
    set(gca,'ztick',[],'zticklabel',[]);

    % title
%     titlestr=['Snapshot of ' varnm ' at ' ...
      titlestr=['Snapshot of ' varnm ' at ' ...
        '{\fontsize{12}{\bf ' ...
        num2str((t),'%7.3f') ...
        '}}s'];
    title(titlestr);
    
    drawnow;
    pause(taut);
    %save gif
    if savegif
      im=frame2im(getframe(gcf));
      [imind,map]=rgb2ind(im,256);
      if nlayer==ns
        imwrite(imind,map,filename1,'gif','LoopCount',Inf,'DelayTime',0.5);
      else
        imwrite(imind,map,filename1,'gif','WriteMode','append','DelayTime',0.5);
      end
    end
    % save and print figure
    if flag_print==1
        width= 500;
        height=500;
        set(gcf,'paperpositionmode','manual');
        set(gcf,'paperunits','points');
        set(gcf,'papersize',[width,height]);
        set(gcf,'paperposition',[0,0,width,height]);
        fnm_out=[varnm '_3grid_',num2str(nlayer,'%5.5i')];
        print(gcf,[fnm_out '.png'],'-dpng');
    end
    
end


