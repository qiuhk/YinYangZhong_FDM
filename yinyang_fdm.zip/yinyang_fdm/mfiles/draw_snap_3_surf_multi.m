%%% surf all yin-yang-zhong wavefield
%%% only xyz component, no rcf component
%%% num id of sphere should equals num of car
clear all;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project_mars/test.json';
output_dir='../project_mars/output';

% which snapshot to plot
% profile 2
id{1}=1;
subs{1}=[272,1,1];      % start from index '1'
subc{1}=[1,-1,-1];     % '-1' to plot all points in this dimension
subt{1}=[1,2,2];
%profile 3
id{2}=2;
subs{2}=[1,92,1];      % start from index '1'
subc{2}=[-1,1,-1];     % '-1' to plot all points in this dimension
subt{2}=[2,1,2];
% profile 1
% id{1}=1;
% subs{1}=[1,1,177];      % start from index '1'
% subc{1}=[-1,-1,1];     % '-1' to plot all points in this dimension
% subt{1}=[20,10,1];

id_car{1}=1;
subs_car{1}=[1,1,69];      % start from index '1'
subc_car{1}=[-1,-1,1];     % '-1' to plot all points in this dimension
subt_car{1}=[2,2,1];

id_car{2}=2;
subs_car{2}=[1,69,1];      % start from index '1'
subc_car{2}=[-1,1,-1];     % '-1' to plot all points in this dimension
subt_car{2}=[2,1,2];

if (length(subs) ~= length(subs_car))
    error('num_id of sphere should equals num_id of car');
end


% variable and time to plot
varnm='Vz';
ns=6;
ne=10;% 1 is 40s
nt=1;

% figure control parameters
flag_km     = 1;
flag_emlast = 1;
flag_print  = 0;
flag_light  = 1;
savegif = 1;
boundary = 0;%plot boundary line of car

scl_caxis=[-2*1e0 2*1e0];%e2
% scl_caxis=[-1.0 1.0];
filename1 = [varnm,'_all.gif'];
scl_daspect =[1 1 1];
clrmp = 'jetwr';
taut=0.5;
% ---------------------------------------------------------------------- %



% locate snapshot and load coordinate
for i=1:length(subs)
    
    % locate snapshot
    snapinfo{i}=locate_snap(parfnm,id{i},'start',subs{i},'count',subc{i},'stride',subt{i},'snapdir',output_dir);
    % get coordinate data
    [f{i},c{i},r{i}]=gather_coord(snapinfo{i},'coorddir',output_dir);
    [fn{i},cn{i},rn{i}]=gather_coord_yang(snapinfo{i},'coorddir',output_dir);
    
    [x{i},y{i},z{i}] = sph2cart(f{i},pi/2-c{i},r{i});
    [xn{i},yn{i},zn{i}] = sph2cart(fn{i},pi/2-cn{i},rn{i});
    
    %%%%%  car
    snapinfo_car{i}=locate_snap_car(parfnm,id_car{i},'start',subs_car{i},'count',subc_car{i},'stride',subt_car{i},'snapdir',output_dir);
    % get coordinate data
    [x1{i},y1{i},z1{i}]=gather_coord_car(snapinfo_car{i},'coorddir',output_dir);
    
    % coordinate unit
    str_unit='m';
    if flag_km
        x{i}=x{i}/1e3;
        y{i}=y{i}/1e3;
        z{i}=z{i}/1e3;
        xn{i}=xn{i}/1e3;
        yn{i}=yn{i}/1e3;
        zn{i}=zn{i}/1e3;
        x1{i}=x1{i}/1e3;
        y1{i}=y1{i}/1e3;
        z1{i}=z1{i}/1e3;
        str_unit='km';
    end

end

% figure plot
hid=figure;
set(hid,'BackingStore','on');

% snapshot show
for nlayer=ns:nt:ne
    
    for i=1:length(subs)
        
        [v_car{i},~]=gather_snap(snapinfo_car{i},nlayer,varnm,'snapdir',output_dir);
        
        [vf{i},~]=gather_snap(snapinfo{i},nlayer,'Vf','snapdir',output_dir);
        [vc{i},~]=gather_snap(snapinfo{i},nlayer,'Vc','snapdir',output_dir);
        [vr{i},~]=gather_snap(snapinfo{i},nlayer,'Vr','snapdir',output_dir);
        [vfn{i},~]=gather_snap(snapinfo{i},nlayer,'Vfn','snapdir',output_dir);
        [vcn{i},~]=gather_snap(snapinfo{i},nlayer,'Vcn','snapdir',output_dir);
        [vrn{i},t]=gather_snap(snapinfo{i},nlayer,'Vrn','snapdir',output_dir);
        
        vx{i} = sin(c{i}).*cos(f{i}).*vr{i} + cos(c{i}).*cos(f{i}).*vc{i} - sin(f{i}).*vf{i};
        vy{i} = sin(c{i}).*sin(f{i}).*vr{i} + cos(c{i}).*sin(f{i}).*vc{i} + cos(f{i}).*vf{i};
        vz{i} = cos(c{i}).*vr{i}            - sin(c{i}).*vc{i}                              ;
        vxn{i} = sin(cn{i}).*cos(fn{i}).*vrn{i} + cos(cn{i}).*cos(fn{i}).*vcn{i} - sin(fn{i}).*vfn{i};
        vyn{i} = sin(cn{i}).*sin(fn{i}).*vrn{i} + cos(cn{i}).*sin(fn{i}).*vcn{i} + cos(fn{i}).*vfn{i};
        vzn{i} = cos(cn{i}).*vrn{i}            - sin(cn{i}).*vcn{i}                              ;
        
        % show time
        if i==1
            disp([ '  draw ' num2str(nlayer) 'th time step (t=' num2str(t) ')']);
        end
        
        if boundary == 1
            x2{i} = squeeze(x1{i});
            y2{i} = squeeze(y1{i});
            z2{i} = squeeze(z1{i});
            plot3(x2{i}(1,:),y2{i}(1,:),z2{i}(1,:),'-c','linewidth',2);
            hold on;
            plot3(x2{i}(size(x2{i},1),:),y2{i}(size(x2{i},1),:),...
                z2{i}(size(x2{i},1),:),'-c','linewidth',2);
            hold on;
            plot3(x2{i}(:,1),y2{i}(:,1),z2{i}(:,1),'-c','linewidth',2);
            hold on;
            plot3(x2{i}(:,size(x2{i},2)),y2{i}(:,size(x2{i},2)),...
                z2{i}(:,size(x2{i},2)),'-c','linewidth',2);
            hold on;
        end
        
        % show snapshot
        
        if flag_emlast
            Alp = 1;
            if strcmp(varnm,'Vx')
                sid{i}=surf(squeeze(permute(x{i},[2 1 3])), ...
                    squeeze(permute(y{i},[2 1 3])), ...
                    squeeze(permute(z{i},[2 1 3])), ...
                    squeeze(permute(vx{i},[2 1 3])),'FaceAlpha', Alp, 'EdgeColor', 'none');
                hold on;
                sid{i}=surf(squeeze(permute(xn{i},[2 1 3])), ...
                    squeeze(permute(yn{i},[2 1 3])), ...
                    squeeze(permute(zn{i},[2 1 3])), ...
                    squeeze(permute(vxn{i},[2 1 3])),'FaceAlpha', Alp, 'EdgeColor', 'none');
            elseif strcmp(varnm,'Vy')
                    sid{i}=surf(squeeze(permute(x{i},[2 1 3])), ...
                    squeeze(permute(y{i},[2 1 3])), ...
                    squeeze(permute(z{i},[2 1 3])), ...
                    squeeze(permute(vy{i},[2 1 3])),'FaceAlpha', Alp, 'EdgeColor', 'none');
                hold on;
                sid{i}=surf(squeeze(permute(xn{i},[2 1 3])), ...
                    squeeze(permute(yn{i},[2 1 3])), ...
                    squeeze(permute(zn{i},[2 1 3])), ...
                    squeeze(permute(vyn{i},[2 1 3])),'FaceAlpha', Alp, 'EdgeColor', 'none');
                
            elseif strcmp(varnm,'Vz')
                    sid{i}=surf(squeeze(permute(x{i},[2 1 3])), ...
                    squeeze(permute(y{i},[2 1 3])), ...
                    squeeze(permute(z{i},[2 1 3])), ...
                    squeeze(permute(vz{i},[2 1 3])),'FaceAlpha', Alp, 'EdgeColor', 'none');
                hold on;
                sid{i}=surf(squeeze(permute(xn{i},[2 1 3])), ...
                    squeeze(permute(yn{i}+0,[2 1 3])), ...
                    squeeze(permute(zn{i},[2 1 3])), ...
                    squeeze(permute(vzn{i},[2 1 3])),'FaceAlpha', Alp, 'EdgeColor', 'none');
            end
            
            hold on;
            
            surf(squeeze(permute(x1{i},[2 1 3])), ...
                squeeze(permute(y1{i}+0,[2 1 3])), ...
                squeeze(permute(z1{i},[2 1 3])), ...
                squeeze(permute(v_car{i},[2 1 3])),'FaceAlpha', Alp);
            
        else
            surf(flipdim(squeeze(permute(x{i},[2 1 3])),3), ...
                flipdim(squeeze(permute(y{i}-5,[2 1 3])),3), ...
                flipdim(squeeze(permute(z{i}-5,[2 1 3])),3), ...
                flipdim(squeeze(permute(v{i},[2 1 3])),3));
        end
        
        hold on;
    end
    
    hold off;   
    xlabel(['X axis (' str_unit ')']);
    ylabel(['Y axis (' str_unit ')']);
    zlabel(['Z axis (' str_unit ')']);
    
    set(gca,'layer','top');
    set(gcf,'color','white','renderer','painters');
    
    % axis image
    % shading interp;
    shading flat;
    % colorbar range/scale
    if exist('scl_caxis')
        caxis(scl_caxis);
    end
    % axis daspect
    if exist('scl_daspect')
        daspect(scl_daspect);
    end
    % colormap and colorbar
    if exist('clrmp')
       load seismic;
       colormap(newColorMap);
         % colormap(clrmp);
    end
    colorbar('vert');
    if flag_light
      %  view(-40,35);
     view(45,30); %yang center is -80,30
     %  view(85, 30); %yin center
        set(gca,'box','off');
        camlight(0,10,'local');
        lighting phong;
    end
    
    % title
%     titlestr=['Snapshot of ' varnm ' at ' ...
      titlestr=['Snapshot of ' varnm ' at ' ...
        '{\fontsize{12}{\bf ' ...
        num2str((t),'%7.3f') ...
        '}}s'];
    title(titlestr);
    
    drawnow;
    pause(taut);
    %save gif
    if savegif
      im=frame2im(getframe(gcf));
      [imind,map]=rgb2ind(im,256);
      if nlayer==ns
        imwrite(imind,map,filename1,'gif','LoopCount',Inf,'DelayTime',0.5);
      else
        imwrite(imind,map,filename1,'gif','WriteMode','append','DelayTime',0.5);
      end
    end
    % save and print figure
    if flag_print==1
        width= 500;
        height=500;
        set(gcf,'paperpositionmode','manual');
        set(gcf,'paperunits','points');
        set(gcf,'papersize',[width,height]);
        set(gcf,'paperposition',[0,0,width,height]);
        fnm_out=[varnm '_3grid_',num2str(nlayer,'%5.5i')];
        print(gcf,[fnm_out '.png'],'-dpng');
    end
    
end


