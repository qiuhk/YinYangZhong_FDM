%%% show isosurface of yin-yang wavefield
%%% only xyz component, no rcf component
%%% you should determine subt,subt_car,isovals
clear all;
addmypath
% -------------------------- parameters input -------------------------- %
% file and path name
parfnm='../project/test.json';
output_dir='../project/output';

%%% parameter you should change
subt=[2,2,1];

subt_car=[2,2,2];

isovals = [-100,100];%determine which surface to show

% variable and time to plot
varnm='Vx';
ns=8;
ne=16;%30 is 1200s
nt=2;%jiange 10 is the same

% figure control parameters
flag_km     = 1;
flag_emlast = 1;
flag_print  = 0;
flag_light  = 1;
savegif = 1;

scl_caxis=[-1.5*1e2 1.5*1e2];%e2
% scl_caxis=[-1.0 1.0];
filename1 = [varnm,'_isosurface.gif'];
scl_daspect =[1 1 1];
clrmp = 'jetwr';
taut=0.5;
% ---------------------------------------------------------------------- %



% locate snapshot and load coordinate
% locate snapshot
snapinfo=locate_snap(parfnm,1,'start',[1,1,1],'count',[-1,-1,-1],'stride',subt,'snapdir',output_dir);
% get coordinate data
[f,c,r]=gather_coord(snapinfo,'coorddir',output_dir);
[fn,cn,rn]=gather_coord_yang(snapinfo,'coorddir',output_dir);

[x,y,z] = sph2cart(f,pi/2-c,r);
[xn,yn,zn] = sph2cart(fn,pi/2-cn,rn);

%%%%%  car
snapinfo_car=locate_snap_car(parfnm,1,'start',[1,1,1],'count',[-1,-1,-1],'stride',subt_car,'snapdir',output_dir);
% get coordinate data
[x1,y1,z1]=gather_coord_car(snapinfo_car,'coorddir',output_dir);

% coordinate unit
str_unit='m';
if flag_km
    x=x/1e3;
    y=y/1e3;
    z=z/1e3;
    xn=xn/1e3;
    yn=yn/1e3;
    zn=zn/1e3;
    x1=x1/1e3;
    y1=y1/1e3;
    z1=z1/1e3;
    str_unit='km';
end



% figure plot
hid=figure;
set(hid,'BackingStore','on');

plot_whole_sphere = 1;
if plot_whole_sphere == 1
    [X, Y, Z] = sphere(50);
    radius = 4;  % ��λ��ǧ�ף��������ᵥλһ�£�
    X = radius * X;
    Y = radius * Y;
    Z = radius * Z;

    % ����͸������
    figure;
    surf(X, Y, Z, 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'FaceColor', [0.8 0.8 0.8]);
    grid off;

    % ͳһ����������������ӽ�
    set(gca,'box','off');
    % ���ӹ��պͲ���
    material dull;
    hold on;   
end

if flag_light
    view(5,0);%volume
    %view(-45, 30); %yang center is -80,30
    %view(85, 30); %yin center
    camlight(-135,10);
    camlight(0,10);
end

    
% snapshot show
disp('start time loop');
for nlayer=ns:nt:ne
    
    % �����һʱ�䲽�ĵ�ֵ�棨patch���󣩣������������壨surface����
    delete(findobj(gca, 'Type', 'patch'));  % �ؼ���ɾ������patch����
    
        
    [v_car,~]=gather_snap(snapinfo_car,nlayer,varnm,'snapdir',output_dir);

    [vf,~]=gather_snap(snapinfo,nlayer,'Vf','snapdir',output_dir);
    [vc,~]=gather_snap(snapinfo,nlayer,'Vc','snapdir',output_dir);
    [vr,~]=gather_snap(snapinfo,nlayer,'Vr','snapdir',output_dir);
    [vfn,~]=gather_snap(snapinfo,nlayer,'Vfn','snapdir',output_dir);
    [vcn,~]=gather_snap(snapinfo,nlayer,'Vcn','snapdir',output_dir);
    [vrn,t]=gather_snap(snapinfo,nlayer,'Vrn','snapdir',output_dir);

    vx = sin(c).*cos(f).*vr + cos(c).*cos(f).*vc - sin(f).*vf;
    vy = sin(c).*sin(f).*vr + cos(c).*sin(f).*vc + cos(f).*vf;
    vz = cos(c).*vr         - sin(c).*vc                     ;
    vxn = sin(cn).*cos(fn).*vrn + cos(cn).*cos(fn).*vcn - sin(fn).*vfn;
    vyn = sin(cn).*sin(fn).*vrn + cos(cn).*sin(fn).*vcn + cos(fn).*vfn;
    vzn = cos(cn).*vrn          - sin(cn).*vcn                        ;

    %reshape sphere data  
    % interp to new grid 
    
    if strcmp(varnm,'Vx') 
        vol = vx;
        voln = vxn;
    elseif strcmp(varnm,'Vy') 
        vol = vy;
        voln = vyn;
    else
        vol = vz;
        voln = vzn;
    end
        

    % show time
    disp([ ' draw ' num2str(nlayer) 'th time step (t=' num2str(t) ')']);

    % show surface
    for i = 1:length(isovals)     
        isoval = isovals(i);    
        [ff, vv] = isosurface(x,y,z,vol, isoval);  
        [ff1, vv1] = isosurface(xn, yn, zn, voln, isoval);

        if ~isempty(ff)                 
            p = patch('Faces', ff, 'Vertices', vv);   
            hold on;
            p1 = patch('Faces', ff1, 'Vertices', vv1); 
            
            alpha(p, 1);
            alpha(p1, 1);
            
            nFaces = size(ff, 1);         
            cdata = repmat(isoval, nFaces, 1);
            % color of surface             
            set(p, 'FaceVertexCData', cdata, ...
                'FaceColor', 'flat', ...                   
                'EdgeColor', 'none');
            nFaces1 = size(ff1, 1);         
            cdata1 = repmat(isoval, nFaces1, 1);                 
            set(p1, 'FaceVertexCData', cdata1, ...
                'FaceColor', 'flat', ...                   
                'EdgeColor', 'none'); %nFaces1 not equals nFaces
        end
    end
    
    set(gca,'layer','top');
    set(gcf,'color','white','renderer','painters');
    
    % axis image

    shading flat;
    % colorbar range/scale
    if exist('scl_caxis')
        caxis(scl_caxis);
    end
    % axis daspect
    if exist('scl_daspect')
        daspect(scl_daspect);
    end
    % colormap and colorbar
    if exist('clrmp')
       load seismic;
       colormap(newColorMap);
     % colormap(clrmp);
    end
%     colorbar('vert');
    
    ax=gca;
    ax.XAxis.Visible='off';
    ax.YAxis.Visible='off';
    ax.ZAxis.Visible='off';
    
    set(gca,'box','off');
    lighting phong;
    material  dull;

    % title
%     titlestr=['Snapshot of ' varnm ' at ' ...
%       titlestr=['Snapshot of ' varnm ' at ' ...
%         '{\fontsize{12}{\bf ' ...
%         num2str((t),'%7.3f') ...
%         '}}s'];
%     title(titlestr);
    
    drawnow;
    pause(taut);
    %save gif
    if savegif
      im=frame2im(getframe(gcf));
      [imind,map]=rgb2ind(im,256);
      if nlayer==ns
        imwrite(imind,map,filename1,'gif','LoopCount',Inf,'DelayTime',0.5);
      else
        imwrite(imind,map,filename1,'gif','WriteMode','append','DelayTime',0.5);
      end
    end
    % save and print figure
    if flag_print==1
        width= 500;
        height=500;
        set(gcf,'paperpositionmode','manual');
        set(gcf,'paperunits','points');
        set(gcf,'papersize',[width,height]);
        set(gcf,'paperposition',[0,0,width,height]);
        fnm_out=[varnm '_3grid_surface_',num2str(nlayer,'%5.5i')];
        print(gcf,[fnm_out '.png'],'-dpng');
    end
    
end


