function gdlay_export_car(gdlay_file,xx,yy,zz)

fid=fopen(gdlay_file,'w'); % Output file name 

%-- last:cartesian grid xx and yy and zz
for i = 1 : size(xx,1)
    fprintf(fid,'%12.6f %12.6f %12.6f\n', ...
        xx(i,1), yy(i,1), zz(i,1));
end

fclose(fid);

end % function
