%------------------------------------------------------------------------------
%-- Example of generating the interface file 
%------------------------------------------------------------------------------

clear;
clc;

%% -----------------------------------------------------------------------------
%-- generate Yin and Yang grid  (only need to change dc and nghost)
%------------------------------------------------------------------------------

%-- generate Yin grid 

dc = 1/2/180*pi; %1/180*pi is 200m
nghost = 4; %must >=3,had better >=4.4 is definitely ok for lag_2

nc = .5*pi/dc+ 2*nghost +1;
c0 = 45/180*pi;
c1d = [0 : nc-1] * dc + c0 - nghost * dc;

%default theta equals fi
df = dc;
nf = 1.5*pi/df+ 2*nghost +1;
f0 = -135/180*pi;
f1d = [0 : nf-1] * df + f0 - nghost * df;

%-- generate Yang grid
[c2d_e,f2d_e] = meshgrid(c1d,f1d);
[x_e,y_e,z_e] = sph2cart(f2d_e,pi/2-c2d_e,1);%theta is elevation,sph2cart func indx is f,c,r
x_n = -x_e;
y_n = z_e;
z_n = y_e;
[f2d_n,c2d_n,r_n] = cart2sph(x_n,y_n,z_n);%theta is elevation,sph2cart func indx is f,c,r
c2d_n = pi/2-c2d_n;

if (fix(nc)~=nc || fix(nf)~=nf)
    error('please ensure ntheta and nfi is an integer');
end

flag_figure_simple = 0; %only plot one layer
flag_figure = 1;

%% ------------------------------------------------------------------------------
%-- generate topography and plot sphere
%------------------------------------------------------------------------------
% topo had better be func of theta or fi
topo_n = zeros(nf,nc);
topo_e = zeros(nf,nc);
h = 0;%1000;
for i=1:nf
    for j=1:nc
      topo_n(i,j) = h*sin(8*c2d_n(i,j))  ;
      topo_e(i,j) = h*sin(8*c2d_e(i,j))  ;
    end
end


if flag_figure_simple == 1  
  figure
  mesh(x_e,y_e,z_e+topo_e);
  hold on;
  mesh(x_n,y_n,z_n+topo_n);
  xlabel('x-axis');
  ylabel('y-axis');
  zlabel('z-axis');
  daspect([1,1,1]);
  camlight; %set a light
  title('generated topography');
  print(gcf,'-dpng','topography.png');
end

topo_max = max(max(max(topo_e)) , max(max(topo_n)) );
topo_min = min(min(min(topo_e)) , min(min(topo_n)) );
fprintf("max of topo is %f and min of topo is %f .\n",...
         topo_max, topo_min);
%% ------------------------------------------------------------------------------
%-- generate grid interfaces(c3d,f3d,r3d)
%-- <only need to change r_of_interfaces(2)> 
%------------------------------------------------------------------------------
%-- note: from bottom to top
num_of_interfaces = 2; 

r_of_interfaces(num_of_interfaces) = 10000;%surface

% bottom interface is determined by min_topo
r_of_interfaces(1) = (r_of_interfaces(num_of_interfaces)+topo_min)/2.2;

df_max = r_of_interfaces(2)*dc;
df_min = r_of_interfaces(1)/sqrt(2)*df;

% 1 less than num_of_interfaces, total cell should be nghost more than FD points
dr_is_equal_of_layer  = [ 1 ]; % 1:The grid spacing is equal; 0: Is not.
dgrid_max       = [ df_max ]; %car also use this
num_of_cell_per_layer = [ round((r_of_interfaces(num_of_interfaces)-r_of_interfaces(1)+topo_max)...
                         /df_max) ];
     
dr_min = (r_of_interfaces(num_of_interfaces)-r_of_interfaces(1)+topo_min) /num_of_cell_per_layer(1);
dr_max = df_max;

fprintf("\npoint distance in (fi,theta) axis ranges [%f , %f]\n",...
         df_min , df_max );%min is in fi axis in certain layer
     
fprintf("point distance in r axis ranges [%f , %f] \n",...
        dr_min, dr_max);

fprintf("point distance in sphere ranges[%f , %f]\n\n", ...
         min(df_min,dr_min) ,max(df_max, dr_max));

%-- construct grid interfaces from free_topo and z_of_interfaces
c3d_e = zeros(nf,nc,num_of_interfaces);
f3d_e = zeros(nf,nc,num_of_interfaces);
r3d_e = zeros(nf,nc,num_of_interfaces);
c3d_n = zeros(nf,nc,num_of_interfaces);
f3d_n = zeros(nf,nc,num_of_interfaces);
r3d_n = zeros(nf,nc,num_of_interfaces);

%-- set c3d and f3d
for n = 1 : num_of_interfaces
  c3d_e(:,:,n) = c2d_e(:,:);
  c3d_n(:,:,n) = c2d_n(:,:);
  f3d_e(:,:,n) = f2d_e(:,:);
  f3d_n(:,:,n) = f2d_n(:,:);
end

%- first same to free surface
r3d_e(:,:,num_of_interfaces) = r_of_interfaces(num_of_interfaces) + topo_e(:,:);
r3d_n(:,:,num_of_interfaces) = r_of_interfaces(num_of_interfaces) + topo_n(:,:);

for ilay = num_of_interfaces-1 : -1 : 1
  r3d_e(:,:,ilay) =  r_of_interfaces(ilay);
  r3d_n(:,:,ilay) =  r_of_interfaces(ilay);
end


%% =============================================================================
%--strcture cartesian grid  (car grid generated automaticlly)
%==============================================================================
nchange = 3; %3 is enough usually
nghost_car = 3;
dh = round(dgrid_max*0.8);%dh of cartesian
dr = round(r_of_interfaces(1));
nxy = 2 * round(dr/ dh) +1 + 2* ( nghost_car +nchange);%contains ghost points
xx = -( (nxy-1)/2 *dh) : dh : ((nxy-1)/2 *dh);
yy = xx;
zz = xx;
% [x,y]=meshgrid(xx,yy);
if (xx((nxy+1)/2) ~= 0)
    error('middle point of car not = 0');
end

if (xx(nxy)+xx(1) ~= 0)
    error('car is not symmetrical');
end

if (xx(nxy)*sqrt(3) > (r_of_interfaces(num_of_interfaces)+topo_min) )
    error('car %f has beyong sphere space %f',xx(nxy)*sqrt(3),...
        r_of_interfaces(num_of_interfaces)+topo_min);
end

%% ------------------------------------------------------------------------------
%-- plot grid surface
%------------------------------------------------------------------------------
seperate =0;
if flag_figure == 1
  termnl0 = 2;
  termnl  = 2;
  figure;
  if seperate ==1
      len = (dr + (nchange+3)*dgrid_max)/2;
      [XX,YY,ZZ] = ndgrid(-1:.1:1,-1:.1:1,-1:.1:1);
      XX=XX*len;
      YY=YY*len;
      ZZ=ZZ*len;
      mesh(XX(1:termnl0:end,1:termnl0:end),YY(1:termnl0:end,1:termnl0:end),ZZ(1:termnl0:end,1:termnl0:end));
      hold on;
  end
  for ilay = 1 : num_of_interfaces
    [x_e,y_e,z_e] = sph2cart(f3d_e(:,:,ilay),pi/2-c3d_e(:,:,ilay),r3d_e(:,:,ilay));
    [x_n,y_n,z_n] = sph2cart(f3d_n(:,:,ilay),pi/2-c3d_n(:,:,ilay),r3d_n(:,:,ilay));
    %surf(x, y, z);
    if seperate ==1
      x_e = x_e + r_of_interfaces(2)*2;
      x_n = x_n - r_of_interfaces(2)*2;
    end
    mesh(x_e(1:termnl:end,1:termnl:end),y_e(1:termnl:end,1:termnl:end),z_e(1:termnl:end,1:termnl:end),'EdgeColor', 'g');
    mesh(x_n(1:termnl:end,1:termnl:end),y_n(1:termnl:end,1:termnl:end),z_n(1:termnl:end,1:termnl:end),'EdgeColor', 'b');
    hold on
  end
  xlabel('x-axis');
  ylabel('y-axis');
  zlabel('z-axis');
  %shading flat
  colorbar
  camlight
  %daspect([8,10,110e3*8/5]);
  daspect([1,1,1]);
  title('layers in gdlay');
  print(gcf,'-dpng','gdlay_layers.png');

end

%% ==============================================================================
%-- write .gdlay file
%==============================================================================
gdlay_file = 'random_topo_single.gdlay';
gdlay_file_yang = 'random_topo_single_yang.gdlay';
gdlay_file_car = 'random_topo_single_car.gdlay';

xx = xx';
yy = yy';
zz = zz';
gdlay_export(gdlay_file, ...
             num_of_interfaces, nf, nc, ...
             num_of_cell_per_layer, ...
             dr_is_equal_of_layer, ...
             f3d_e, c3d_e, r3d_e);
         
gdlay_export(gdlay_file_yang, ...
             num_of_interfaces, nf, nc, ...
             num_of_cell_per_layer, ...
             dr_is_equal_of_layer, ...
             f3d_n, c3d_n, r3d_n);
         
gdlay_export_car(gdlay_file_car, ...
             xx,yy,zz);
 
fprintf("in sh file,nf = %d and nc = %d and nz = %d, nxy = %d\n",...
         nf-6, nc-6,num_of_cell_per_layer+1, nxy-6);
         
         
         
         
         
         

