#!/bin/bash

#set -x
set -e

date

#-- program related dir
EXEC_WAVE=`pwd`/../main_curv_col_el_3d
echo "EXEC_WAVE=$EXEC_WAVE"

#-- input dir
CUR_DIR=`pwd`

#-- output and conf
PROJDIR=`pwd`/../project_check
PAR_FILE=${PROJDIR}/test.json
GRID_DIR=${PROJDIR}/output
MEDIA_DIR=${PROJDIR}/output
SOURCE_DIR=${PROJDIR}/output
OUTPUT_DIR=${PROJDIR}/output

RUN_SCRIPT_FILE=${PROJDIR}/runscript.lsf
echo "RUN_SCRIPT_FILE  = ${RUN_SCRIPT_FILE}"

rm -rf $PROJDIR

#-- create dir
mkdir -p $PROJDIR
mkdir -p $OUTPUT_DIR
mkdir -p $GRID_DIR
mkdir -p $MEDIA_DIR

EVTNM=sphere



NX=543
NY=183
NZ=64
NXYZ=137

NPROCS_X=8
NPROCS_Y=5

NPROCS=$(( NPROCS_X*NPROCS_Y ))

#----------------------------------------------------------------------
#-- create main conf
#----------------------------------------------------------------------
cat << ieof > $PAR_FILE
{
  "number_of_total_grid_points_theta" : $NY,
  "number_of_total_grid_points_fi" : $NX,
  "number_of_total_grid_points_rho" : $NZ,
  "number_of_cartesian_grid_points": $NXYZ,
  "size_of_interp": 2,
  "number_of_mpiprocs_theta" : $NPROCS_Y,
  "number_of_mpiprocs_fi" : $NPROCS_X,

  "size_of_time_step" : 0.008,
  "number_of_time_steps" :2500,
  "#time_window_length" : 4,
  "check_stability" : 1,
  "is_absorb" : 0,

  "boundary_r_top" : {
      "free" : "timg"
      },

  "grid_generation_method" : {
      "#import" : "$GRID_DIR",
      "#cartesian" : {
         "origin"  : [0.0, -29900.0 ],
         "inteval" : [ 100.0, 100.0 ]
      },
      "layer_interp" : {
        "in_grid_layer_file" : "$CUR_DIR/prep_grid/random_topo_single.gdlay",
        "in_grid_layer_file_yang" : "$CUR_DIR/prep_grid/random_topo_single_yang.gdlay",
        "in_grid_layer_file_car" : "$CUR_DIR/prep_grid/random_topo_single_car.gdlay",
        "refine_factor" : [ 1, 1, 1 ],
        "horizontal_start_index" : [3, 3],
        "vertical_last_to_top" : 0
      }
  },
  "is_export_grid" : 1,
  "grid_export_dir"   : "$GRID_DIR",

  "metric_calculation_method" : {
      "#import" : "$GRID_DIR",
      "calculate" : 1
  },
  "is_export_metric" : 1,

  "medium" : {
      "type" : "elastic_iso",
      "#input_way" : "infile_layer",
      "#input_way" : "binfile",
      "input_way" : "code",
      "#binfile" : {
        "size"    : [1101, 1447, 1252],
        "spacing" : [-10, 10, 10],
        "origin"  : [0.0,0.0,0.0],
        "dim1" : "z",
        "dim2" : "x",
        "dim3" : "y",
        "Vp" : "$CUR_DIR/prep_medium/seam_Vp.bin",
        "Vs" : "$CUR_DIR/prep_medium/seam_Vs.bin",
        "rho" : "$CUR_DIR/prep_medium/seam_rho.bin"
      },
      "code" : "func_name_here",
      "#import" : "$MEDIA_DIR",
      "#infile_layer" : "$CUR_DIR/prep_medium/basin_el_iso.md3lay",
      "#infile_grid" : "$CUR_DIR/prep_medium/topolay_el_iso.md3grd",
      "#equivalent_medium_method" : "loc",
      "#equivalent_medium_method" : "har"
  },

  "is_export_media" : 1,
  "media_export_dir"  : "$MEDIA_DIR",

  "#visco_config" : {
      "type" : "gmb",
      "Qs_freq" : 2.0,
      "number_of_maxwell" : 3,
      "max_freq" : 10.0,
      "min_freq" : 0.1,
      "refer_freq" : 1.0
  },

  "in_source_file" : "$CUR_DIR/prep_source/test_source.src",
  "source_region": 2,
  "source_rcf":0,
  "is_export_source" : 1,
  "source_export_dir"  : "$SOURCE_DIR",

  "output_dir" : "$OUTPUT_DIR",

  "in_station_file" : "$CUR_DIR/prep_station/station.list",

  "receiver_line" : [
    {
      "name" : "surface_hori",
      "grid_index_start"    : [  106, 46, $[NZ-1]],
      "grid_index_incre"    : [  10,  0,  0 ],
      "grid_index_count"    : 7
    },
    {
      "name" : "interface",
      "grid_index_start"    : [  106, 46, 0 ],
      "grid_index_incre"    : [  10,  0,  0 ],
      "grid_index_count"    : 7
    },
    {
       "name" : "line_r",
       "grid_index_start"    : [  271, 91, 43 ],
       "grid_index_incre"    : [  0,  0,  5 ],
       "grid_index_count"    : 5
    }
  ],
  
  "slice" : {
      "x_index" : [ 50],
      "y_index" : [ 50],
      "z_index" : [ 5]
  },

  "snapshot" : [
    {
      "name" : "volume_vel",
      "grid_index_start" : [ 0,   0,  0 ],
      "grid_index_count" : [ $NX, $NY, $NZ],
      "grid_index_incre" : [  1,  1,  1 ],
      "time_index_start" : 0,
      "time_index_incre" : 20,
      "save_velocity" : 1,
      "save_stress"   : 0,
      "save_strain"   : 0
    }
  ],

  "check_nan_every_nummber_of_steps" :1,
  "output_all" : 0 
}
ieof

echo "+ created $PAR_FILE"

#-------------------------------------------------------------------------------
#-- generate run script
#-------------------------------------------------------------------------------
#
create_script_lsf()
{
cat << ieof > ${RUN_SCRIPT_FILE}
#!/bin/bash

#BSUB -J ${EVTNM}
#BSUB -q short
##BSUB -n 4
#BSUB -n ${NPROCS}
#BSUB -R "span[ptile=40]"
##BSUB -e %J.err
#BSUB -o %J.out

MPI_CMD="mpirun -np ${NPROCS} ${EXEC_WAVE} ${PAR_FILE} 100"
#MPI_CMD="mpirun -np ${NPROCS} valgrind --tool=massif ${EXEC_WAVE} ${PAR_FILE} 100"
#MPI_CMD="mpirun -np ${NPROCS} valgrind --tool=memcheck  --log-file=valgrind.txt --leak-check=full ${EXEC_WAVE} ${PAR_FILE} 100"
printf "%s\n\n" "\${MPI_CMD}";

time \${MPI_CMD} 2>&1 | tee log;
if [ \$? -ne 0 ]; then
    printf "\nSimulation fail! stop!\n"
    exit 1
fi
ieof

}

#-------------------------------------------------------------------------------
#-- start run
#-------------------------------------------------------------------------------
echo "submit to lsf ..."
create_script_lsf;
bsub < ${RUN_SCRIPT_FILE}

date

# vim:ft=conf:ts=4:sw=4:nu:et:ai:
